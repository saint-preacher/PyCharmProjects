﻿using FiringCSWin.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace FiringCSWinTests
{
    [TestClass]
    public class ParametersTest
    {
        private const string INTPARAM = "INTPARAM";
        private const string WORDPARAM = "WORDPARAM";
        private const string BYTEPARAM = "BYTEPARAM";
        private const string FLOATPARAM = "FLOATPARAM";

        private Mock<IErrorService> ErrorServiceMock = new Mock<IErrorService>();

        [TestMethod]
        public void GetNonStringParamTest()
        {
            int intParam = 540000;
            ushort wordParam = 2390;
            byte byteParam = 78;
            float floatParam = 45.6f;

            var pars = new Parameters(ErrorServiceMock.Object);

            pars.Add(INTPARAM, intParam.ToString());
            pars.Add(WORDPARAM, wordParam.ToString());
            pars.Add(BYTEPARAM, byteParam.ToString());
            pars.Add(FLOATPARAM, floatParam.ToString());

            Assert.AreEqual(intParam, pars.GetNonStringParam<int>(INTPARAM, 0, 1));
            Assert.AreEqual(wordParam, pars.GetNonStringParam<ushort>(WORDPARAM, 0, 2));
            Assert.AreEqual(byteParam, pars.GetNonStringParam<byte>(BYTEPARAM, 0, 3));
            Assert.AreEqual(floatParam, pars.GetNonStringParam<float>(FLOATPARAM, 0.0f, 4));
        }
    }
}