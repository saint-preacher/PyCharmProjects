﻿using FiringCSWin.BaseServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;

namespace FiringCSWin.Services.Tests
{
    [TestClass()]
    public class ErrorNotifierServiceTests
    {
        private List<ErrorObject> Errors = new List<ErrorObject>();
        private Mock<IBaseDialogService> DialogServiceMock = new Mock<IBaseDialogService>();

        [TestInitialize()]
        public void BeforeEachTest()
        {
            // создадим несколько экземпляров разных ошибок
            Errors.Add(new ErrorObject(1, "Видимо что-то случилось", ErrorNotifierService.E_LEVEL.Information, 10000));
            Errors.Add(new ErrorObject(2, "Кажется всё-таки да", ErrorNotifierService.E_LEVEL.Warning, 20000));
            Errors.Add(new ErrorObject(3, "Оп-па такого мы не ожидали", ErrorNotifierService.E_LEVEL.Error, 30000));
            Errors.Add(new ErrorObject(4, "Всё, капец", ErrorNotifierService.E_LEVEL.Fatal, 40000));
            Errors.Add(new ErrorObject(5, "Одна лишняя", ErrorNotifierService.E_LEVEL.Information, 0));
        }

        /// <summary>
        /// Код для проверки открытия окон сообщений где нужно
        /// </summary>
        public void AlertMessageBoxesTest()
        {
            // проверка вызова окна сообщений
            DialogServiceMock.Verify(ds => ds.ShowMsgBox(Errors[3].Message, "Фатальная ошибка", MessageBoxButton.OK, MessageBoxImage.Error));
            DialogServiceMock.Verify(ds => ds.ShowMsgBox(Errors[2].Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error));
        }

        /// <summary>
        /// Код для тестов Report для разных уровней логирования
        /// </summary>
        /// <param name="level">Уровень логирования</param>
        /// <returns>Строки из лога</returns>
        private List<string> ReportTestStub(ErrorNotifierService.E_LEVEL level)
        {
            var service = new ErrorNotifierService(DialogServiceMock.Object, ErrorsService.UnknownError) { LogLevel = level };
            foreach (var error in Errors) service.Register(error);

            foreach (var error in Errors) service.Report(error.Number);

            // читаем поток обратно
            var stream = new MemoryStream();
            service.LogStream.Seek(0, SeekOrigin.Begin);
            service.LogStream.CopyTo(stream);

            var strings = new List<string>();
            stream.Seek(0, SeekOrigin.Begin);
            using (var reader = new StreamReader(stream))
            {
                while (!reader.EndOfStream) strings.Add(reader.ReadLine());
            }

            AlertMessageBoxesTest();

            return strings;
        }

        [TestMethod()]
        public void ReportLogLevelInformationTest()
        {
            var strings = ReportTestStub(ErrorNotifierService.E_LEVEL.Information);
            Assert.AreEqual(Errors.Count, strings.Count, "На данном уровне должны быть логированы все ошибки");
        }

        [TestMethod()]
        public void ReportLogLevelWarningTest()
        {
            var strings = ReportTestStub(ErrorNotifierService.E_LEVEL.Warning);
            Assert.AreEqual(3, strings.Count, "На данном уровне должны быть логированы все ошибки уровнем выше Warning");
        }

        [TestMethod()]
        public void ReportLogLevelErrorTest()
        {
            var strings = ReportTestStub(ErrorNotifierService.E_LEVEL.Error);
            Assert.AreEqual(2, strings.Count, "На данном уровне должны быть логированы все ошибки уровнем выше Error");
        }

        [TestMethod()]
        public void ReportLogLevelFatalTest()
        {
            var strings = ReportTestStub(ErrorNotifierService.E_LEVEL.Fatal);
            Assert.AreEqual(1, strings.Count, "На данном уровне должны быть логированы только ошибки уровнем Fatal");
        }

        [TestMethod()]
        // Проверяем что логируется строка с датой
        public void LogTest()
        {
            var rightString = "[05.08.1998 13:21:34] Ошибка!";
            using (var stream = new MemoryStream())
            {
                var dateTime = new DateTime(1998, 8, 5, 13, 21, 34);
                var testObject = new ErrorNotifierService(DialogServiceMock.Object, ErrorsService.UnknownError);
                testObject.Log("Ошибка!", stream, dateTime);

                stream.Seek(0, SeekOrigin.Begin);
                var reader = new StreamReader(stream);
                var actualLine = reader.ReadLine();

                Assert.AreEqual(rightString, actualLine);
            }
        }
    }
}