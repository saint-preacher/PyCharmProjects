﻿using FiringCSWin.BaseServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FiringCSWin.Services.Tests
{
    [TestClass]
    public class ConfigServiceTests
    {
        private ConfigService Service;
        private Dictionary<string, (string, string)> TestDict;
        private MemoryStream FakeFileStream;

        [TestInitialize]
        public void BeforeTests()
        {
            Service = new ConfigService();

            TestDict = new Dictionary<string, (string, string)>
            {
                {"aaa = 11", ("","")},
                {"[ComPortName] = \"/dev/ttyUSB0\"", ("ComPortName","/dev/ttyUSB0")},
                {"[Baudrate] = \"57600\"", ("Baudrate","57600")},
                {"[ComPortName]=\"/dev/ttyUSB0\"", ("ComPortName","/dev/ttyUSB0")},
                {"[Baudrate]=\"57600\"", ("Baudrate","57600")},
                {"[ ComPortName ] = \"/dev/ttyUSB0\"", ("ComPortName","/dev/ttyUSB0")},
                {"[ Baudrate ] = \"57600\"", ("Baudrate","57600")},
                {"[....",("....","")}
            };

            var FakeFileInsides = "[ComPortName] = \"/dev/ttyUSB0\"\n" +
                "[Baudrate] = \"57600\"\n";

            FakeFileStream = new MemoryStream();
            FakeFileStream.Write(Encoding.ASCII.GetBytes(FakeFileInsides), 0, FakeFileInsides.Length);
            FakeFileStream.Seek(0, SeekOrigin.Begin);
        }

        [TestMethod]
        public void LoadEntriesFromStreamTest()
        {
            using (var reader = new StreamReader(FakeFileStream))
            {
                Service.LoadEntriesFromStream(reader);
                Assert.AreEqual(Service["ComPortName"], "/dev/ttyUSB0");
                Assert.AreEqual(Service["Baudrate"], "57600");
            }
        }

        [TestMethod]
        public void ParseLineTest()
        {
            foreach (var pair in TestDict)
            {
                var key = string.Empty;
                var value = string.Empty;
                int mode = 0;

                for (int i = 0; i < pair.Key.Length; i++)
                {
                    ConfigService.ParseCharacter(pair.Key, i, ref mode, ref key, ref value);
                }

                Assert.AreEqual(pair.Value.Item1, key);
                Assert.AreEqual(pair.Value.Item2, value);
            }
        }

        [TestMethod]
        public void SaveToStreamTest()
        {
            var initValues = new Dictionary<string, string>()
            {
                { "ComPortValue", "COM4" },
                { "Baudrate", "19200" }
            };

            // список со строками для проверки
            var strings = new List<string>()
            {
                "[ComPortValue] = \"COM4\"",
                "[Baudrate] = \"19200\""
            };

            Service.Initialize(initValues);

            using (var stream = new MemoryStream())
            {
                Service.SaveToStream(stream);

                // проверка что данные в поток сохранены верно
                stream.Seek(0, SeekOrigin.Begin);
                var reader = new StreamReader(stream);

                for (int i = 0; i < strings.Count; i++)
                {
                    var line = reader.ReadLine();
                    Assert.AreEqual(strings[i], line);
                }
            }
        }
    }
}