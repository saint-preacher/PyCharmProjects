﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FiringCSWin.UIElements
{
    /// <summary>
    /// Логика взаимодействия для LimitParamControl.xaml
    /// </summary>
    public partial class LimitParamControl : UserControl
    {
        public LimitParamControl()
        {
            InitializeComponent();
        }

        #region("LimitsString")
        public static readonly DependencyProperty LimitsStringProperty = DependencyProperty.Register(
              nameof(LimitsString),
              typeof(string),
              typeof(RemoverControlBlock),
              new PropertyMetadata(string.Empty)
            );

        public string LimitsString
        {
            get => (string)GetValue(LimitsStringProperty);
            set => SetValue(LimitsStringProperty, value);
        }
        #endregion

        #region("MinLimitString")
        public static readonly DependencyProperty MinLimitStringProperty = DependencyProperty.Register(
              nameof(MinLimitString),
              typeof(string),
              typeof(RemoverControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Минимальное значение хорошего объекта
        /// </summary>
        public string MinLimitString
        {
            get => (string)GetValue(MinLimitStringProperty);
            set => SetValue(MinLimitStringProperty, value);
        }
        #endregion

        #region("MaxLimitString")
        public static readonly DependencyProperty MaxLimitStringProperty = DependencyProperty.Register(
              nameof(MaxLimitString),
              typeof(string),
              typeof(RemoverControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Максимальное значение хорошего объекта
        /// </summary>
        public string MaxLimitString
        {
            get => (string)GetValue(MaxLimitStringProperty);
            set => SetValue(MaxLimitStringProperty, value);
        }
        #endregion
    }
}
