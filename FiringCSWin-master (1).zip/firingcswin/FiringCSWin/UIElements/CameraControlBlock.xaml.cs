﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace FiringCSWin.UIElements
{
    /// <summary>
    /// Логика взаимодействия для CameraControlBlock.xaml
    /// </summary>
    public partial class CameraControlBlock : UserControl
    {
        public CameraControlBlock()
        {
            InitializeComponent();
        }

        #region("LoadFileFrameCommand")
        public static readonly DependencyProperty LoadFileFrameCommandProperty = DependencyProperty.Register(
              nameof(LoadFileFrameCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда, выполняемая по нажатию на "Загрузить кадр из файла"
        /// </summary>
        public ICommand LoadFileFrameCommand
        {
            get => (ICommand)GetValue(LoadFileFrameCommandProperty);
            set => SetValue(LoadFileFrameCommandProperty, value);
        }
        #endregion

        #region("DiscAndTransMoving")
        public static readonly DependencyProperty DiscAndTransMovingProperty = DependencyProperty.Register(
              nameof(DiscAndTransMoving),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Флажок для состояния кнопки "ДСК"
        /// </summary>
        public bool DiscAndTransMoving
        {
            get => (bool)GetValue(DiscAndTransMovingProperty);
            set => SetValue(DiscAndTransMovingProperty, value);
        }
        #endregion
        
        #region("ExpositionEnterCommand")
        public static readonly DependencyProperty ExpositionEnterCommandProperty = DependencyProperty.Register(
              nameof(ExpositionEnterCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при вводе времени экспозиции
        /// </summary>
        public ICommand ExpositionEnterCommand
        {
            get => (ICommand)GetValue(ExpositionEnterCommandProperty);
            set => SetValue(ExpositionEnterCommandProperty, value);
        }
        #endregion
        
        #region("LoadFromFrameEnabled")
        public static readonly DependencyProperty LoadFromFrameEnabledProperty = DependencyProperty.Register(
              nameof(LoadFromFrameEnabled),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(true)
            );

        /// <summary>
        /// Разрешение на доступ к кнопке "Загрузить кадр из файла"
        /// </summary>
        public bool LoadFromFrameEnabled
        {
            get => (bool)GetValue(LoadFromFrameEnabledProperty);
            set => SetValue(LoadFromFrameEnabledProperty, value);
        }
        #endregion

        #region("DscAndTrnCheckedCommand")
        public static readonly DependencyProperty DscAndTrnCheckedCommandProperty = DependencyProperty.Register(
              nameof(DscAndTrnCheckedCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда по toggle кнопки "ДСК И ТРН"
        /// </summary>
        public ICommand DscAndTrnCheckedCommand
        {
            get => (ICommand)GetValue(DscAndTrnCheckedCommandProperty);
            set => SetValue(DscAndTrnCheckedCommandProperty, value);
        }
        #endregion

        #region("DscAndTrnUncheckedCommand")
        public static readonly DependencyProperty DscAndTrnUncheckedCommandProperty = DependencyProperty.Register(
              nameof(DscAndTrnUncheckedCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда по untoggle кнопки "ДСК И ТРН"
        /// </summary>
        public ICommand DscAndTrnUncheckedCommand
        {
            get => (ICommand)GetValue(DscAndTrnUncheckedCommandProperty);
            set => SetValue(DscAndTrnUncheckedCommandProperty, value);
        }
        #endregion

        #region("CassCheckedCommand")
        public static readonly DependencyProperty CassCheckedCommandProperty = DependencyProperty.Register(
              nameof(CassCheckedCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда по toggle кнопки КАСС
        /// </summary>
        public ICommand CassCheckedCommand
        {
            get => (ICommand)GetValue(CassCheckedCommandProperty);
            set => SetValue(CassCheckedCommandProperty, value);
        }
        #endregion

        #region("CassUncheckedCommand")
        public static readonly DependencyProperty CassUncheckedCommandProperty = DependencyProperty.Register(
              nameof(CassUncheckedCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда по untoggle кнопки КАСС
        /// </summary>
        public ICommand CassUncheckedCommand
        {
            get => (ICommand)GetValue(CassUncheckedCommandProperty);
            set => SetValue(CassUncheckedCommandProperty, value);
        }
        #endregion

        #region("GasCheckedCommand")
        public static readonly DependencyProperty GasCheckedCommandProperty = DependencyProperty.Register(
              nameof(GasCheckedCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда по toggle кнопки ГАЗ
        /// </summary>
        public ICommand GasCheckedCommand
        {
            get => (ICommand)GetValue(GasCheckedCommandProperty);
            set => SetValue(GasCheckedCommandProperty, value);
        }
        #endregion

        #region("GasUncheckedCommand")
        public static readonly DependencyProperty GasUncheckedCommandProperty = DependencyProperty.Register(
              nameof(GasUncheckedCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда по untoggle кнопки ГАЗ
        /// </summary>
        public ICommand GasUncheckedCommand
        {
            get => (ICommand)GetValue(GasUncheckedCommandProperty);
            set => SetValue(GasUncheckedCommandProperty, value);
        }
        #endregion

        #region("SelectedCamera")
        public static readonly DependencyProperty SelectedCameraProperty = DependencyProperty.Register(
              nameof(SelectedCamera),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Имя выбранной камеры для ComboBox
        /// </summary>
        public string SelectedCamera
        {
            get => (string)GetValue(SelectedCameraProperty);
            set => SetValue(SelectedCameraProperty, value);
        }
        #endregion

        #region("ComboboxEnabled")
        public static readonly DependencyProperty ComboboxEnabledProperty = DependencyProperty.Register(
              nameof(ComboboxEnabled),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Доступ к выбору камеры
        /// </summary>
        public bool ComboboxEnabled
        {
            get => (bool)GetValue(ComboboxEnabledProperty);
            set => SetValue(ComboboxEnabledProperty, value);
        }
        #endregion

        #region("CamerasList")
        public static readonly DependencyProperty CamerasListProperty = DependencyProperty.Register(
              nameof(CamerasList),
              typeof(List<string>),
              typeof(CameraControlBlock),
              new PropertyMetadata(new List<string>())
            );

        public List<string> CamerasList
        {
            get => (List<string>)GetValue(CamerasListProperty);
            set => SetValue(CamerasListProperty, value);
        }
        #endregion

        #region("OpenButtonEnabled")
        public static readonly DependencyProperty OpenButtonEnabledProperty = DependencyProperty.Register(
              nameof(OpenButtonEnabled),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(true)
            );

        /// <summary>
        /// Доступ к кнопке "открыть соединение с камерой"
        /// </summary>
        public bool OpenButtonEnabled
        {
            get => (bool)GetValue(OpenButtonEnabledProperty);
            set => SetValue(OpenButtonEnabledProperty, value);
        }
        #endregion

        #region("OpenButtonCommand")
        public static readonly DependencyProperty OpenButtonCommandProperty = DependencyProperty.Register(
              nameof(OpenButtonCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при нажатии кнопки "открыть соединение с камерой"
        /// </summary>
        public ICommand OpenButtonCommand
        {
            get => (ICommand)GetValue(OpenButtonCommandProperty);
            set => SetValue(OpenButtonCommandProperty, value);
        }
        #endregion

        #region("StartAcqButtonEnabled")
        public static readonly DependencyProperty StartAcqButtonEnabledProperty = DependencyProperty.Register(
              nameof(StartAcqButtonEnabled),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Доступ к кнопке "запуск сбора кадров с камеры"
        /// </summary>
        public bool StartAcqButtonEnabled
        {
            get => (bool)GetValue(StartAcqButtonEnabledProperty);
            set => SetValue(StartAcqButtonEnabledProperty, value);
        }
        #endregion

        #region("StartAcqButtonCommand")
        public static readonly DependencyProperty StartAcqButtonCommandProperty = DependencyProperty.Register(
              nameof(StartAcqButtonCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при нажатии кнопки "запуск сбора кадров с камеры"
        /// </summary>
        public ICommand StartAcqButtonCommand
        {
            get => (ICommand)GetValue(StartAcqButtonCommandProperty);
            set => SetValue(StartAcqButtonCommandProperty, value);
        }
        #endregion

        #region("StopAcqButtonEnabled")
        public static readonly DependencyProperty StopAcqButtonEnabledProperty = DependencyProperty.Register(
              nameof(StopAcqButtonEnabled),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Доступ к кнопке "остановить сбор кадров с камеры"
        /// </summary>
        public bool StopAcqButtonEnabled
        {
            get => (bool)GetValue(StopAcqButtonEnabledProperty);
            set => SetValue(StopAcqButtonEnabledProperty, value);
        }
        #endregion

        #region("StopAcqButtonCommand")
        public static readonly DependencyProperty StopAcqButtonCommandProperty = DependencyProperty.Register(
              nameof(StopAcqButtonCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при нажатии кнопки "остановить сбор кадров с камеры"
        /// </summary>
        public ICommand StopAcqButtonCommand
        {
            get => (ICommand)GetValue(StopAcqButtonCommandProperty);
            set => SetValue(StopAcqButtonCommandProperty, value);
        }
        #endregion

        #region("CloseButtonEnabled")
        public static readonly DependencyProperty CloseButtonEnabledProperty = DependencyProperty.Register(
              nameof(CloseButtonEnabled),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Доступ к кнопке "закрыть соединение с камерой"
        /// </summary>
        public bool CloseButtonEnabled
        {
            get => (bool)GetValue(CloseButtonEnabledProperty);
            set => SetValue(CloseButtonEnabledProperty, value);
        }
        #endregion

        #region("CloseButtonCommand")
        public static readonly DependencyProperty CloseButtonCommandProperty = DependencyProperty.Register(
              nameof(CloseButtonCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при нажатии кнопки "закрыть соединение с камерой"
        /// </summary>
        public ICommand CloseButtonCommand
        {
            get => (ICommand)GetValue(CloseButtonCommandProperty);
            set => SetValue(CloseButtonCommandProperty, value);
        }
        #endregion

        #region("CameraStateString")
        public static readonly DependencyProperty CameraStateStringProperty = DependencyProperty.Register(
              nameof(CameraStateString),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata("CLOSED")
            );

        /// <summary>
        /// Строка состояния соединения с камерой
        /// </summary>
        public string CameraStateString
        {
            get => (string)GetValue(CameraStateStringProperty);
            set => SetValue(CameraStateStringProperty, value);
        }
        #endregion

        #region("CameraStateBrush")
        public static readonly DependencyProperty CameraStateBrushProperty = DependencyProperty.Register(
              nameof(CameraStateBrush),
              typeof(Brush),
              typeof(CameraControlBlock),
              new PropertyMetadata(Brushes.White)
            );

        /// <summary>
        /// Цвет фона строки состояния соединения с камерой
        /// </summary>
        public Brush CameraStateBrush
        {
            get => (Brush)GetValue(CameraStateBrushProperty);
            set => SetValue(CameraStateBrushProperty, value);
        }
        #endregion

        #region("DebugChecked")
        public static readonly DependencyProperty DebugCheckedProperty = DependencyProperty.Register(
              nameof(DebugChecked),
              typeof(bool),
              typeof(CameraControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Состояние чекбокса "Отладка"
        /// </summary>
        public bool DebugChecked
        {
            get => (bool)GetValue(DebugCheckedProperty);
            set => SetValue(DebugCheckedProperty, value);
        }
        #endregion

        #region("ExposureString")
        public static readonly DependencyProperty ExposureStringProperty = DependencyProperty.Register(
              nameof(ExposureString),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Строка с величиной экспозиции
        /// </summary>
        public string ExposureString
        {
            get => (string)GetValue(ExposureStringProperty);
            set => SetValue(ExposureStringProperty, value);
        }
        #endregion
        
        #region("ROITopString")
        public static readonly DependencyProperty ROITopStringProperty = DependencyProperty.Register(
              nameof(ROITopString),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Строка с ординатой верхнего края ROI 
        /// </summary>
        public string ROITopString
        {
            get => (string)GetValue(ROITopStringProperty);
            set => SetValue(ROITopStringProperty, value);
        }
        #endregion

        #region("ROIBottomString")
        public static readonly DependencyProperty ROIBottomStringProperty = DependencyProperty.Register(
              nameof(ROIBottomString),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Строка с ординатой нижнего края ROI
        /// </summary>
        public string ROIBottomString
        {
            get => (string)GetValue(ROIBottomStringProperty);
            set => SetValue(ROIBottomStringProperty, value);
        }
        #endregion
        
        #region("RefMillimetersString")
        public static readonly DependencyProperty RefMillimetersStringProperty = DependencyProperty.Register(
              nameof(RefMillimetersString),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Строка с величиной коэффициента пересчёта в миллиметры
        /// </summary>
        public string RefMillimetersString
        {
            get => (string)GetValue(RefMillimetersStringProperty);
            set => SetValue(RefMillimetersStringProperty, value);
        }
        #endregion

        #region("SaveFrameCommand")
        public static readonly DependencyProperty SaveFrameCommandProperty = DependencyProperty.Register(
              nameof(SaveFrameCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при нажатии кнопки "Сохранить кадр"
        /// </summary>
        public ICommand SaveFrameCommand
        {
            get => (ICommand)GetValue(SaveFrameCommandProperty);
            set => SetValue(SaveFrameCommandProperty, value);
        }
        #endregion

        #region("SaveNFramesCommand")
        public static readonly DependencyProperty SaveNFramesCommandProperty = DependencyProperty.Register(
              nameof(SaveNFramesCommand),
              typeof(ICommand),
              typeof(CameraControlBlock),
              new PropertyMetadata()
            );

        /// <summary>
        /// Команда при нажатии кнопки "Сохранить N кадров"
        /// </summary>
        public ICommand SaveNFramesCommand
        {
            get => (ICommand)GetValue(SaveNFramesCommandProperty);
            set => SetValue(SaveNFramesCommandProperty, value);
        }
        #endregion

        #region("NFramesString")
        public static readonly DependencyProperty NFramesStringProperty = DependencyProperty.Register(
              nameof(NFramesString),
              typeof(string),
              typeof(CameraControlBlock),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Строка с величиной количества сохранённых кадров
        /// </summary>
        public string NFramesString
        {
            get => (string)GetValue(NFramesStringProperty);
            set => SetValue(NFramesStringProperty, value);
        }
        #endregion

        #region("SaveFramesCount")
        public static readonly DependencyProperty SaveFramesCountProperty = DependencyProperty.Register(
              nameof(SaveFramesCount),
              typeof(int),
              typeof(CameraControlBlock),
              new PropertyMetadata(0)
            );

        /// <summary>
        /// Количество кадров для сохранения
        /// </summary>
        public int SaveFramesCount
        {
            get => (int)GetValue(SaveFramesCountProperty);
            set => SetValue(SaveFramesCountProperty, value);
        }
        #endregion
    }
}
