﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace FiringCSWin.Converters
{
    [ValueConversion(typeof(Enum), typeof(bool))]
    public class EnumToCheckedConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((value == null) || (parameter == null)) return false;

            var compareValue = value.ToString();
            var targetValue = (string)parameter;

            return compareValue.Equals(targetValue, StringComparison.InvariantCultureIgnoreCase);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter == null) return Binding.DoNothing;

            var checkedBool = (bool)value;
            var targetValue = (string)parameter;

            if (checkedBool)  return Enum.Parse(targetType, targetValue);

            return Binding.DoNothing;
        }
    }
}
