﻿using FiringCSWin.BaseServices;
using FiringCSWin.MVVMBase;

namespace FiringCSWin.Models
{
    public interface IValvesModel
    {
        // команды для включения и отключения клапанов
        string Valve1EnableCommand { get; set; }

        string Valve1DisableCommand { get; set; }
        string Valve2EnableCommand { get; set; }
        string Valve2DisableCommand { get; set; }
        string Valve3EnableCommand { get; set; }
        string Valve3DisableCommand { get; set; }
        string Valve4EnableCommand { get; set; }
        string Valve4DisableCommand { get; set; }
        string Valve5EnableCommand { get; set; }
        string Valve5DisableCommand { get; set; }

        // методы для включения и отключения клапанов
        void Valve1On();

        void Valve1Off();

        void Valve2On();

        void Valve2Off();

        void Valve3On();

        void Valve3Off();

        void Valve4On();

        void Valve4Off();

        void Valve5On();

        void Valve5Off();
    }

    public class ValvesModel : ModelBase, IValvesModel
    {
        private ICommService commService;

        public string Valve1EnableCommand { get; set; }
        public string Valve1DisableCommand { get; set; }
        public string Valve2EnableCommand { get; set; }
        public string Valve2DisableCommand { get; set; }
        public string Valve3EnableCommand { get; set; }
        public string Valve3DisableCommand { get; set; }
        public string Valve4EnableCommand { get; set; }
        public string Valve4DisableCommand { get; set; }
        public string Valve5EnableCommand { get; set; }
        public string Valve5DisableCommand { get; set; }

        public ValvesModel(ICommService comm)
        {
            commService = comm;
        }

        public void Valve1On() => commService.SendCommand(Valve1EnableCommand);

        public void Valve1Off() => commService.SendCommand(Valve1DisableCommand);

        public void Valve2On() => commService.SendCommand(Valve2EnableCommand);

        public void Valve2Off() => commService.SendCommand(Valve2DisableCommand);

        public void Valve3On() => commService.SendCommand(Valve3EnableCommand);

        public void Valve3Off() => commService.SendCommand(Valve3DisableCommand);

        public void Valve4On() => commService.SendCommand(Valve4EnableCommand);

        public void Valve4Off() => commService.SendCommand(Valve4DisableCommand);

        public void Valve5On() => commService.SendCommand(Valve5EnableCommand);

        public void Valve5Off() => commService.SendCommand(Valve5DisableCommand);
    }
}