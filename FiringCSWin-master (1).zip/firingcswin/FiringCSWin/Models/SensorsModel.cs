﻿using FiringCSWin.BaseServices;
using FiringCSWin.MVVMBase;
using System.Threading;

namespace FiringCSWin.Models
{
    public interface ISensorsModel
    {
        bool RowSensor { get; set; }
        bool TubeSensor { get; set; }
        bool Valve1Sensor { get; set; }
        bool Valve2Sensor { get; set; }
        bool Valve3Sensor { get; set; }
        bool Valve4Sensor { get; set; }
        bool Valve5Sensor { get; set; }
        bool CasetteReversing { get; set; }
        bool RowLimit { get; set; }
        bool PushLimit { get; set; }
        bool AutomaticCasetting { get; set; }
        bool ReservedLimit { get; set; }
        bool FullCasette { get; set; }
        bool CasetteTopLimit { get; set; }
        bool CasetteBottomLimit { get; set; }
        bool EmptyCasette { get; set; }

        ushort CurrentTransporterSpeed { get; set; }
        ushort CurrentDiscSpeed { get; set; }
        ushort CurrentCasetteSpeed { get; set; }
        ushort CasetteStepsPerRow { get; set; }
        ushort CasetteFirstStepsPerRow { get; set; }
        ushort CurrentRowCount { get; set; }
        ushort PushIntoCasetteDelay { get; set; }
        ushort RowCount { get; set; }
        ushort BeforePushIntoCasetteDelay { get; set; }
        uint CasettePosition { get; set; }
        ushort AlarmCode { get; set; }

        event AlarmCodeEventHandler AlarmCodeChanged;
    }

    /// <summary>
    /// Модель для работы с датчиками
    /// </summary>
    public class SensorsModel : ModelBase, ISensorsModel
    {
        private bool _rowSensor;
        private bool _tubeSensor;
        private bool _valve1Sensor;
        private bool _valve2Sensor;
        private bool _valve3Sensor;
        private bool _valve4Sensor;
        private bool _valve5Sensor;
        private bool _casetteReversing;
        private bool _rowLimit;
        private bool _pushLimit;
        private bool _autoCasetting;
        private bool _reservedLimit;
        private bool _fullCasette;
        private bool _casetteTopLimit;
        private bool _casetteBottomLimit;
        private bool _emptyCasette;
        private ushort _currTranspSpeed;
        private ushort _currDiscSpeed;
        private ushort _currCasetteSpeed;
        private ushort _casetteStepsPerRow;
        private ushort _casetteFirstStepsPerRow;
        private ushort _currentRowCount;
        private ushort _pushInDelay;
        private ushort _rowCount;
        private ushort _beforePushInDelay;
        private uint _casettePosition;
        private ushort _alarmCode;

        /// <summary>
        /// Датчик ряда
        /// </summary>
        public bool RowSensor
        {
            get => _rowSensor;
            set
            {
                _rowSensor = value;
                RaisePropertyChanged(nameof(RowSensor));
            }
        }

        /// <summary>
        /// Датчик трубки
        /// </summary>
        public bool TubeSensor
        {
            get => _tubeSensor;
            set
            {
                _tubeSensor = value;
                RaisePropertyChanged(nameof(TubeSensor));
            }
        }

        /// <summary>
        /// Датчик выхода(подтверждение) на пневмоцилиндр №1
        /// </summary>
        public bool Valve1Sensor
        {
            get => _valve1Sensor;
            set
            {
                _valve1Sensor = value;
                RaisePropertyChanged(nameof(Valve1Sensor));
            }
        }

        /// <summary>
        /// Датчик выхода(подтверждение) на пневмоцилиндр №2
        /// </summary>
        public bool Valve2Sensor
        {
            get => _valve2Sensor;
            set
            {
                _valve2Sensor = value;
                RaisePropertyChanged(nameof(Valve2Sensor));
            }
        }

        /// <summary>
        /// Датчик выхода(подтверждение) на пневмоцилиндр №3
        /// </summary>
        public bool Valve3Sensor
        {
            get => _valve3Sensor;
            set
            {
                _valve3Sensor = value;
                RaisePropertyChanged(nameof(Valve3Sensor));
            }
        }

        /// <summary>
        /// Датчик выхода(подтверждение) на пневмоцилиндр №4
        /// </summary>
        public bool Valve4Sensor
        {
            get => _valve4Sensor;
            set
            {
                _valve4Sensor = value;
                RaisePropertyChanged(nameof(Valve4Sensor));
            }
        }

        /// <summary>
        /// Датчик выхода(подтверждение) на пневмоцилиндр №5
        /// </summary>
        public bool Valve5Sensor
        {
            get => _valve5Sensor;
            set
            {
                _valve5Sensor = value;
                RaisePropertyChanged(nameof(Valve5Sensor));
            }
        }

        /// <summary>
        /// Направление движения кассеты
        /// </summary>
        public bool CasetteReversing
        {
            get => _casetteReversing;
            set
            {
                _casetteReversing = value;
                RaisePropertyChanged(nameof(CasetteReversing));
            }
        }

        /// <summary>
        /// Концевик ряда трубок (сигнал к запуску загрузки в кассету)
        /// </summary>
        public bool RowLimit
        {
            get => _rowLimit;
            set
            {
                _rowLimit = value;
                RaisePropertyChanged(nameof(RowLimit));
            }
        }

        /// <summary>
        /// Концевик пневмоцилиндра для смены кассеты (со стороны кассеты)
        /// </summary>
        public bool PushLimit
        {
            get => _pushLimit;
            set
            {
                _pushLimit = value;
                RaisePropertyChanged(nameof(PushLimit));
            }
        }

        /// <summary>
        /// Индикатор работы программы автоматического кассетирования
        /// </summary>
        public bool AutomaticCasetting
        {
            get => _autoCasetting;
            set
            {
                _autoCasetting = value;
                RaisePropertyChanged(nameof(AutomaticCasetting));
            }
        }

        /// <summary>
        /// Текущая скорость транспортёра
        /// </summary>
        public ushort CurrentTransporterSpeed
        {
            get => _currTranspSpeed;
            set
            {
                _currTranspSpeed = value;
                RaisePropertyChanged(nameof(CurrentTransporterSpeed));
            }
        }

        /// <summary>
        /// Текущая скорость вращения диска оплавки
        /// </summary>
        public ushort CurrentDiscSpeed
        {
            get => _currDiscSpeed;
            set
            {
                _currDiscSpeed = value;
                RaisePropertyChanged(nameof(CurrentDiscSpeed));
            }
        }

        /// <summary>
        /// Текущая скорость движения кассеты
        /// </summary>
        public ushort CurrentCasetteSpeed
        {
            get => _currCasetteSpeed;
            set
            {
                _currCasetteSpeed = value;
                RaisePropertyChanged(nameof(CurrentTransporterSpeed));
            }
        }

        /// <summary>
        /// Заданное количество шагов кассеты на один ряд
        /// </summary>
        public ushort CasetteStepsPerRow
        {
            get => _casetteStepsPerRow;
            set
            {
                _casetteStepsPerRow = value;
                RaisePropertyChanged(nameof(CasetteStepsPerRow));
            }
        }

        /// <summary>
        /// Заданное количество шагов кассеты на первый ряд
        /// </summary>
        public ushort CasetteFirstStepsPerRow
        {
            get => _casetteFirstStepsPerRow;
            set
            {
                _casetteFirstStepsPerRow = value;
                RaisePropertyChanged(nameof(CasetteFirstStepsPerRow));
            }
        }

        /// <summary>
        /// Текущее количество рядов в кассете
        /// </summary>
        public ushort CurrentRowCount
        {
            get => _currentRowCount;
            set
            {
                _currentRowCount = value;
                RaisePropertyChanged(nameof(CurrentRowCount));
            }
        }

        /// <summary>
        /// Задержка при работе пневмоцилиндра загрузки ряда в кассету
        /// </summary>
        public ushort PushIntoCasetteDelay
        {
            get => _pushInDelay;
            set
            {
                _pushInDelay = value;
                RaisePropertyChanged(nameof(PushIntoCasetteDelay));
            }
        }

        /// <summary>
        /// Количество рядов трубок в одной кассете
        /// </summary>
        public ushort RowCount
        {
            get => _rowCount;
            set
            {
                _rowCount = value;
                RaisePropertyChanged(nameof(RowCount));
            }
        }

        /// <summary>
        /// Задержка перед работой пневмоцилиндра загрузки ряда в кассету
        /// </summary>
        public ushort BeforePushIntoCasetteDelay
        {
            get => _beforePushInDelay;
            set
            {
                _beforePushInDelay = value;
                RaisePropertyChanged(nameof(BeforePushIntoCasetteDelay));
            }
        }

        /// <summary>
        /// Текущая позиция кассеты (количество шагов от начала движения)
        /// </summary>
        public uint CasettePosition
        {
            get => _casettePosition;
            set
            {
                _casettePosition = value;
                RaisePropertyChanged(nameof(CasettePosition));
            }
        }

        /// <summary>
        /// Резервное место под концевик
        /// </summary>
        public bool ReservedLimit
        {
            get => _reservedLimit;
            set
            {
                _reservedLimit = value;
                RaisePropertyChanged(nameof(ReservedLimit));
            }
        }

        /// <summary>
        /// Отсутствие полной кассеты (True - отсутствует)
        /// </summary>
        public bool FullCasette
        {
            get => _fullCasette;
            set
            {
                _fullCasette = value;
                RaisePropertyChanged(nameof(FullCasette));
            }
        }

        /// <summary>
        /// Верхний концевик кассеты
        /// </summary>
        public bool CasetteTopLimit
        {
            get => _casetteTopLimit;
            set
            {
                _casetteTopLimit = value;
                RaisePropertyChanged(nameof(CasetteTopLimit));
            }
        }

        /// <summary>
        /// Нижний концевик кассеты
        /// </summary>
        public bool CasetteBottomLimit
        {
            get => _casetteBottomLimit;
            set
            {
                _casetteBottomLimit = value;
                RaisePropertyChanged(nameof(CasetteBottomLimit));
            }
        }

        /// <summary>
        /// Отсутствие пустой кассеты (True - отсутствует)
        /// </summary>
        public bool EmptyCasette
        {
            get => _emptyCasette;
            set
            {
                _emptyCasette = value;
                RaisePropertyChanged(nameof(EmptyCasette));
            }
        }

        /// <summary>
        /// Код аварии. 0 = нет аварии
        /// </summary>
        public ushort AlarmCode
        {
            get => _alarmCode;
            set
            {
                var prevCode = _alarmCode;
                _alarmCode = value;
                if ((_alarmCode > 0) && (prevCode != _alarmCode)) GuiContext.Post(o => AlarmCodeChanged?.Invoke(_alarmCode), null);
                RaisePropertyChanged(nameof(AlarmCode));
            }
        }

        /// <summary>
        /// Событие, которое отражает действие "Произошла авария"
        /// </summary>
        public event AlarmCodeEventHandler AlarmCodeChanged;

        public override bool Equals(object compareObject)
        {
            if (compareObject == null) return false;

            // если ссылки в памяти совпадают объект 100% одинаковые
            if (ReferenceEquals(this, compareObject)) return true;

            return Equals(compareObject as SensorsModel);
        }

        public bool Equals(SensorsModel compareObject)
        {
            if (compareObject == null) return false;

            var result = true;

            result &= AutomaticCasetting == compareObject.AutomaticCasetting;
            result &= BeforePushIntoCasetteDelay == compareObject.BeforePushIntoCasetteDelay;
            result &= CasetteFirstStepsPerRow == compareObject.CasetteFirstStepsPerRow;
            result &= CasettePosition == compareObject.CasettePosition;
            result &= CasetteReversing == compareObject.CasetteReversing;
            result &= CasetteStepsPerRow == compareObject.CasetteStepsPerRow;
            result &= CurrentCasetteSpeed == compareObject.CurrentCasetteSpeed;
            result &= CurrentDiscSpeed == compareObject.CurrentDiscSpeed;
            result &= CurrentRowCount == compareObject.CurrentRowCount;
            result &= CurrentTransporterSpeed == compareObject.CurrentTransporterSpeed;
            result &= PushIntoCasetteDelay == compareObject.PushIntoCasetteDelay;
            result &= PushLimit == compareObject.PushLimit;
            result &= RowCount == compareObject.RowCount;
            result &= RowLimit == compareObject.RowLimit;
            result &= RowSensor == compareObject.RowSensor;
            result &= TubeSensor == compareObject.TubeSensor;
            result &= Valve1Sensor == compareObject.Valve1Sensor;
            result &= Valve2Sensor == compareObject.Valve2Sensor;
            result &= Valve3Sensor == compareObject.Valve3Sensor;
            result &= Valve4Sensor == compareObject.Valve4Sensor;
            result &= Valve5Sensor == compareObject.Valve5Sensor;
            result &= ReservedLimit == compareObject.ReservedLimit;
            result &= FullCasette == compareObject.FullCasette;
            result &= EmptyCasette == compareObject.EmptyCasette;
            result &= CasetteBottomLimit == compareObject.CasetteBottomLimit;
            result &= CasetteTopLimit == compareObject.CasetteTopLimit;
            result &= AlarmCode == compareObject.AlarmCode;

            return result;
        }
    }
}