﻿using FiringCSWin.BaseServices;
using FiringCSWin.MVVMBase;
using System;
using System.Threading.Tasks;

namespace FiringCSWin.Models
{
    public interface ICasettingAlgModel
    {
        Func<ushort, string> StepsPerRowCommand { get; set; }
        Func<ushort, string> PushInCasetteDelayCommand { get; set; }
        Func<ushort, string> RowCountCommand { get; set; }
        Func<ushort, string> FirstStepsPerRowCommand { get; set; }
        Func<ushort, string> BeforePushInDelayCommand { get; set; }

        ushort StepsPerRow { get; set; }
        ushort PushInDelay { get; set; }
        ushort BeforePushInDelay { get; set; }
        ushort RowCount { get; set; }
        ushort FirstStepsPerRow { get; set; }

        string StartCasettingCommand { get; set; }
        string StopCasettingCommand { get; set; }
        string StartRowMoveCommand { get; set; }
        string StartPushInCommand { get; set; }
        string StartNextRowCommand { get; set; }
        string StartChangeCasetteCommand { get; set; }
        string ZeroCounterCommand { get; set; }

        void StartCasetting();

        void StopCasetting();

        void StartRowMove();

        void StartPushIn();

        void StartNextRow();

        void StartChangeCasette();

        void ZeroCounter();
    }

    /// <summary>
    /// Модель для управления кассетированием
    /// </summary>
    public class CasettingAlgModel : ModelBase, ICasettingAlgModel
    {
        private ICommService commService;
        private ushort _stepsPerRow;
        private ushort _firstStepsPerRow;
        private ushort _beforePushInDelay;
        private ushort _rowCount;
        private ushort _pushInDelay;

        /// <summary>
        /// Создание объекта модели управления кассетированием
        /// </summary>
        /// <param name="comm"></param>
        public CasettingAlgModel(ICommService comm) => commService = comm;

        /// <summary>
        /// Команда установки количества шагов для смены ряда кассеты
        /// </summary>
        public Func<ushort, string> StepsPerRowCommand { get; set; }

        /// <summary>
        /// Команда установки количества шагов для смены первого ряда кассеты
        /// </summary>
        public Func<ushort, string> FirstStepsPerRowCommand { get; set; }

        /// <summary>
        /// Команда установки задержки перед работой пневмоцилиндра загрузки в кассету
        /// </summary>
        public Func<ushort, string> BeforePushInDelayCommand { get; set; }

        /// <summary>
        /// Команда установки задержки при работе пневмоцилиндра загрузки в кассету
        /// </summary>
        public Func<ushort, string> PushInCasetteDelayCommand { get; set; }

        /// <summary>
        /// Команда установки количества рядов в кассете
        /// </summary>
        public Func<ushort, string> RowCountCommand { get; set; }

        /// <summary>
        /// Количество шагов на ряд
        /// </summary>
        public ushort StepsPerRow
        {
            get => _stepsPerRow;
            set
            {
                _stepsPerRow = value;
                Task.Run(() => commService.SendCommand(StepsPerRowCommand(value)));
                RaisePropertyChanged(nameof(StepsPerRow));
            }
        }

        /// <summary>
        /// Количество шагов в первом ряду
        /// </summary>
        public ushort FirstStepsPerRow
        {
            get => _firstStepsPerRow;
            set
            {
                _firstStepsPerRow = value;
                Task.Run(() => commService.SendCommand(FirstStepsPerRowCommand(value)));
                RaisePropertyChanged(nameof(FirstStepsPerRow));
            }
        }

        /// <summary>
        /// Задержка перед вталкиванием ряда в кассету
        /// </summary>
        public ushort BeforePushInDelay
        {
            get => _beforePushInDelay;
            set
            {
                _beforePushInDelay = value;
                Task.Run(() => commService.SendCommand(BeforePushInDelayCommand(value)));
                RaisePropertyChanged(nameof(BeforePushInDelay));
            }
        }

        /// <summary>
        /// Задержка вталкивания ряда в кассету
        /// </summary>
        public ushort PushInDelay
        {
            get => _pushInDelay;
            set
            {
                _pushInDelay = value;
                Task.Run(() => commService.SendCommand(PushInCasetteDelayCommand(value)));
                RaisePropertyChanged(nameof(PushInDelay));
            }
        }

        /// <summary>
        /// Количество рядов в одной кассете
        /// </summary>
        public ushort RowCount
        {
            get => _rowCount;
            set
            {
                _rowCount = value;
                Task.Run(() => commService.SendCommand(RowCountCommand(value)));
                RaisePropertyChanged(nameof(RowCount));
            }
        }

        public string StartCasettingCommand { get; set; }
        public string StopCasettingCommand { get; set; }
        public string StartRowMoveCommand { get; set; }
        public string StartPushInCommand { get; set; }
        public string StartNextRowCommand { get; set; }
        public string StartChangeCasetteCommand { get; set; }
        public string ZeroCounterCommand { get; set; }

        /// <summary>
        ///  Запуск автоматического касcетирования
        /// </summary>
        public void StartCasetting() => Task.Run(() => commService.SendCommand(StartCasettingCommand));

        /// <summary>
        /// Запуск подпрограммы "Смена кассеты" отдельно
        /// </summary>
        public void StartChangeCasette() => Task.Run(() => commService.SendCommand(StartChangeCasetteCommand));

        /// <summary>
        /// Запуск подпрограммы "Смена ряда" отдельно
        /// </summary>
        public void StartNextRow() => Task.Run(() => commService.SendCommand(StartNextRowCommand));

        /// <summary>
        /// Запуск подпрограммы "Загрузка в кассету"
        /// </summary>
        public void StartPushIn() => Task.Run(() => commService.SendCommand(StartPushInCommand));

        /// <summary>
        /// Запуск подпрограммы "Перемещение ряда изделий"
        /// </summary>
        public void StartRowMove() => Task.Run(() => commService.SendCommand(StartRowMoveCommand));

        /// <summary>
        /// Остановка любых подпрограмм автоматического кассетирования и остановка этого процесса в целом
        /// </summary>
        public void StopCasetting() => Task.Run(() => commService.SendCommand(StopCasettingCommand));

        /// <summary>
        /// Очистка счётчика рядов в кассете
        /// </summary>
        public void ZeroCounter() => Task.Run(() => commService.SendCommand(ZeroCounterCommand));
    }
}