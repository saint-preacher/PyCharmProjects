﻿using FiringCSWin.BaseServices;
using FiringCSWin.MVVMBase;
using System;
using System.Threading.Tasks;

namespace FiringCSWin.Models
{
    public interface IAxisModel
    {
        Func<ushort, string> SpeedCommand { get; set; }
        Func<ushort, string> ReverseSpeedCommand { get; set; }
        Func<ushort, string> AccelCommand { get; set; }
        Func<ushort, string> DecelCommand { get; set; }
        Func<ushort, string> MoveCommand { get; set; }
        string SetStraightDirectionCommand { get; set; }
        string SetReverseDirectionCommand { get; set; }
        string StartDriveCommand { get; set; }
        string StopDriveCommand { get; set; }
        ushort Speed { get; set; }
        ushort ReverseSpeed { get; set; }
        ushort Accel { get; set; }
        ushort Decel { get; set; }
        ushort MoveSteps { get; set; }

        void Start();

        void Stop();

        void SetStraightDirection();

        void SetReverseDirection();

        void MoveBy();
    }

    public class AxisModel : ModelBase, IAxisModel
    {
        private ICommService commService;
        private ushort _speed;
        private ushort _reverseSpeed;
        private ushort _accel;
        private ushort _decel;
        private ushort _moveSteps;

        // Команды для связи с платой
        public Func<ushort, string> SpeedCommand { get; set; }
        public Func<ushort, string> ReverseSpeedCommand { get; set; }
        public Func<ushort, string> AccelCommand { get; set; }
        public Func<ushort, string> DecelCommand { get; set; }
        public Func<ushort, string> MoveCommand { get; set; }

        public string SetStraightDirectionCommand { get; set; }
        public string SetReverseDirectionCommand { get; set; }
        public string StartDriveCommand { get; set; }
        public string StopDriveCommand { get; set; }

        /// <summary>
        /// Создание объекта модели шагового двигателя
        /// </summary>
        /// <param name="comm">Служба связи с платой управления</param>
        public AxisModel(ICommService comm)
        {
            commService = comm;
        }

        /// <summary>
        /// Скорость
        /// </summary>
        public ushort Speed
        {
            get => _speed;
            set
            {
                _speed = value;
                Task.Run(() => commService.SendCommand(SpeedCommand(value)));
                RaisePropertyChanged(nameof(Speed));
            }
        }

        /// <summary>
        /// Скорость в обратную сторону
        /// </summary>
        public ushort ReverseSpeed
        {
            get => _reverseSpeed;
            set
            {
                _reverseSpeed = value;
                Task.Run(() => commService.SendCommand(ReverseSpeedCommand(value)));
                RaisePropertyChanged(nameof(ReverseSpeed));
            }
        }

        /// <summary>
        /// Ускорение
        /// </summary>
        public ushort Accel
        {
            get => _accel;
            set
            {
                _accel = value;
                Task.Run(() => commService.SendCommand(AccelCommand(value)));
                RaisePropertyChanged(nameof(Accel));
            }
        }

        /// <summary>
        /// Торможение
        /// </summary>
        public ushort Decel
        {
            get => _decel;
            set
            {
                _decel = value;
                Task.Run(() => commService.SendCommand(DecelCommand(value)));
                RaisePropertyChanged(nameof(Decel));
            }
        }

        /// <summary>
        /// Количество шагов для движения на конкретное расстояние
        /// </summary>
        public ushort MoveSteps
        {
            get => _moveSteps;
            set
            {
                _moveSteps = value;
                RaisePropertyChanged(nameof(MoveSteps));
            }
        }

        /// <summary>
        /// Запуск движения
        /// </summary>
        public void Start() => Task.Run(() => commService.SendCommand(StartDriveCommand));

        /// <summary>
        /// Остановка движения
        /// </summary>
        public void Stop() => Task.Run(() => commService.SendCommand(StopDriveCommand));

        /// <summary>
        /// Прямое движение
        /// </summary>
        public void SetStraightDirection() => Task.Run(() => commService.SendCommand(SetStraightDirectionCommand));

        /// <summary>
        /// Движение в обратную сторону
        /// </summary>
        public void SetReverseDirection() => Task.Run(() => commService.SendCommand(SetReverseDirectionCommand));

        /// <summary>
        /// Движение на конкретное расстояние
        /// </summary>
        public void MoveBy()
        {
            if (MoveCommand != null) Task.Run(() => commService.SendCommand(MoveCommand(MoveSteps)));
        }
    }
}