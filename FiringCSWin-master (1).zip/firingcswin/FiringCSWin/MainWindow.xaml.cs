﻿using FiringCSWin.BaseServices;
using FiringCSWin.Services;
using FiringCSWin.ViewModels;
using System.Windows;

namespace FiringCSWin
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var app = (App)Application.Current;

            var fsProvider = new NETFSProvider();

            var headUpProcessing = new HeadUpImageProcessing(fsProvider);
            var side1Processing = new SideImageProcessing(fsProvider);
            var side2Processing = new SideImageProcessing(fsProvider);

            DataContext = new MainWindowViewModel(app.CameraLocator, app.ErrorService, headUpProcessing, side1Processing, side2Processing,
                app.DialogService, app.ParametersService, app.TubeManager, app.CommService, app.AxisModels, app.CasetteAlgModel, app.ValvesModel,
                app.RemoverModels, app.SensorsModel, app.HeadUpCameraModel, app.Side1CameraModel, app.Side2CameraModel);
        }
    }
}