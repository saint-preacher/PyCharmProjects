﻿using FiringCSWin.BaseServices;
using FiringCSWin.Helpers;
using FiringCSWin.Models;
using FiringCSWin.Services;
using System;
using System.Windows;

namespace FiringCSWin
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public Parameters ParametersService;
        public ErrorsService ErrorService;
        public DialogService DialogService;
        public CommService<ISensorsModel> CommService;
        public AlarmService AlarmService;
        public GxCamLocator CameraLocator;
        public TubeManager TubeManager;

        public (IAxisModel, IAxisModel, IAxisModel) AxisModels;
        public ISensorsModel SensorsModel;
        public IValvesModel ValvesModel;
        public ICasettingAlgModel CasetteAlgModel;
        public (IRemoverModel, IRemoverModel, IRemoverModel) RemoverModels;

        public ICameraModel HeadUpCameraModel;
        public ISideCameraModel Side1CameraModel;
        public ISideCameraModel Side2CameraModel;

        private void Application_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show(e.Exception.Message, "Фатальная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            Current.Shutdown();
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            // загрузка параметров из файла
            DialogService = new DialogService();
            ErrorService = new ErrorsService(DialogService);
            ParametersService = new Parameters(ErrorService);
            ParametersService.LoadParameters();
            AlarmService = new AlarmService();
            CameraLocator = new GxCamLocator(ErrorService);
            TubeManager = new TubeManager();

            // создание службы работы с последовательным портом
            CommService = new CommService<ISensorsModel>(ParametersService.ComPortName, ParametersService.Baudrate);
            CommService.PollCommandCode = CommProtocol.PollCommand;
            CommService.CreatePort();
            CommService.OpenPort();

            CommService.CommFatalErrorOccuredEvent += CommService_CommFatalErrorOccuredEvent;
            CommService.CommErrorOccuredEvent += CommService_CommErrorOccuredEvent;

            CreateModels();

            SensorsModel.AlarmCodeChanged += SensorsModel_AlarmCodeChanged;
            AlarmService.AlarmEvent += AlarmService_AlarmEvent;

            // запуск опроса
            CommService.StartPoll();
        }

        private void AlarmService_AlarmEvent(string desc)
        {
            DialogService.SpawnAlarmWindow(desc, () => { CasetteAlgModel.StopCasetting(); });
        }

        private void SensorsModel_AlarmCodeChanged(int code) => AlarmService.Alarm(code);

        private void CreateModels()
        {
            // создание моделей
            AxisModels = (new AxisModel(CommService), new AxisModel(CommService), new AxisModel(CommService));
            SensorsModel = new SensorsModel();
            ValvesModel = new ValvesModel(CommService);
            CasetteAlgModel = new CasettingAlgModel(CommService);
            RemoverModels = (new RemoverModel(CommService), new RemoverModel(CommService), new RemoverModel(CommService));

            HeadUpCameraModel = new CameraModel();
            Side1CameraModel = new SideCameraModel();
            Side2CameraModel = new SideCameraModel();

            CommService.PollData = SensorsModel;

            ProtocolChoose.ChooseCommProtocol(AxisModels, SensorsModel, ValvesModel, CasetteAlgModel, RemoverModels);
        }

        /// <summary>
        /// Обработчик возникшей ошибки при работе с последовательным портом
        /// </summary>
        /// <param name="sender">Отправитель события</param>
        /// <param name="e">Параметры события</param>
        private void CommService_CommFatalErrorOccuredEvent(object sender, EventArgs e)
        {
            ErrorService.Report(CommService.LastError, ErrorNotifierService.E_LEVEL.Error);
        }

        private void CommService_CommErrorOccuredEvent(object sender, EventArgs e)
        {
            ErrorService.Report(CommService.LastError, ErrorNotifierService.E_LEVEL.Warning);
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            CommService.StopPoll();
            CameraLocator.Deinit();
        }
    }
}