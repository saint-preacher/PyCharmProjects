﻿using System;
using System.IO.Ports;
using System.Threading;

namespace FiringCSWin.BaseServices
{
    public interface ICommService
    {
        string LastError { get; }

        bool SendCommand(string cmd);
        
        void StartPoll();

        void StopPoll();

        event EventHandler CommFatalErrorOccuredEvent;

        event EventHandler CommErrorOccuredEvent;
    }

    public interface ICommPollableService<T> : ICommService
    {
        Action<SerialPort, T> PollCommandCode { get; set; }
        T PollData { get; set; }
    }

    /// <summary>
    /// Служба для связи через СОМ-порт с контроллером
    /// </summary>
    public class CommService<T> : ICommPollableService<T>
    {
        private const int DELAY_BETWEEN_POLLING_COMMANDS = 300;
        private SerialPort ComPort;
        private Thread CommThread;
        private bool IsCommThread;
        private AutoResetEvent CommThreadEnd = new AutoResetEvent(false);
        private Mutex CommMutex = new Mutex();
        private string PortName;
        private int Baudrate;
        private bool FatalPortFailFlag = true;

        /// <summary>
        /// Ссылка на объект данных модели для опроса
        /// </summary>
        public T PollData { get; set; }

        public CommService(string portName, int baudrate)
        {
            PortName = portName;
            Baudrate = baudrate;
        }

        public string LastError { get; private set; }

        public event EventHandler CommFatalErrorOccuredEvent;

        public event EventHandler CommErrorOccuredEvent;

        /// <summary>
        /// Команда опроса
        /// </summary>
        public Action<SerialPort, T> PollCommandCode { get; set; }
        
        /// <summary>
        /// Отправить команду у которой есть подтверждение 
        /// </summary>
        /// <param name="cmd">Строка команды</param>
        /// <returns>Подтверждение</returns>
        public bool SendCommand(string cmd)
        {
            if (FatalPortFailFlag) return false;

            try
            {
                if (string.IsNullOrEmpty(cmd)) throw new ArgumentException("Попытка отправить пустую строку!");
                if (CommMutex.WaitOne(5000))
                {
                    ComPort.DiscardInBuffer();
                    ComPort.DiscardOutBuffer();

                    System.Diagnostics.Debug.WriteLine($"SendCmdWithAck : {cmd}");
                    ComPort.Write(cmd);

                    var line = string.Empty;

                    Thread.Sleep(50);

                    // тут нужно читать подтверждение
                    line = ComPort.ReadLine();
                    System.Diagnostics.Debug.WriteLine($"ACK : {line}");

                    Thread.Sleep(25);
                    CommMutex.ReleaseMutex();

                    return line.Equals("OK");
                }
                else throw new TimeoutException("Слишком длительное ожидание свободного окна для отправки команды!");
            }
            catch (Exception e)
            {
                LastError = e.Message;
                CommErrorOccuredEvent?.Invoke(this, new EventArgs());
            }

            return false;
        }

        /// <summary>
        /// Создание объекта порта
        /// </summary>
        public void CreatePort()
        {
            ComPort = new SerialPort(PortName,
                Baudrate,
                Parity.None,
                8,
                StopBits.One);
            ComPort.NewLine = "\r";
            ComPort.DtrEnable = true;
            ComPort.ReadTimeout = 1000;
            ComPort.WriteTimeout = 500;
        }

        /// <summary>
        /// Запуск общения программы с контроллером
        /// </summary>
        public void StartPoll()
        {
            CommThread = new Thread(CommProcedure);
            CommThread.Start();
        }

        /// <summary>
        /// Остановка общения программы с контроллером
        /// </summary>
        public void StopPoll()
        {
            IsCommThread = false;
            if (!CommThreadEnd.WaitOne(5000))
            {
                LastError = "Поток не отвечает на попытки остановки, он будет уничтожен.";
                CommFatalErrorOccuredEvent?.Invoke(this, new EventArgs());
                CommThread?.Abort();
            }
        }

        /// <summary>
        /// Процедура опроса
        /// </summary>
        private void CommProcedure()
        {
            if (ComPort == null)
            {
                LastError = "Объекта последовательного порта не существует.";
                CommFatalErrorOccuredEvent?.Invoke(this, new EventArgs());
                return;
            }

            if (!CheckAlreadyStarted())
            {
                LastError = "Процедура опроса платы уже запущена.";
                CommFatalErrorOccuredEvent?.Invoke(this, new EventArgs());
                return;
            }

            if (!ComPort.IsOpen)
            {
                LastError = "Необходимый для работы последовательный порт не открыт.";
                CommFatalErrorOccuredEvent?.Invoke(this, new EventArgs());
                return;
            }

            IsCommThread = true;
            FatalPortFailFlag = false;

            while (IsCommThread)
            {
                PollCommand();
                Thread.Sleep(DELAY_BETWEEN_POLLING_COMMANDS);
            }

            CommThreadEnd.Set();
        }

        /// <summary>
        /// Проверка уже запущенного потока
        /// </summary>
        private bool CheckAlreadyStarted()
        {
            if (IsCommThread)
            {
                LastError = "Экземпляр процесса уже запущен.";
                CommFatalErrorOccuredEvent?.Invoke(this, new EventArgs());
                return false;
            }
            return true;
        }

        /// <summary>
        /// Открытие последовательного порта
        /// </summary>
        public bool OpenPort()
        {
            if (!ComPort.IsOpen)
            {
                try
                {
                    ComPort.Open();

                    // контроллер перезагружается. даём ему некоторое время
                    Thread.Sleep(1000);
                }
                catch (Exception e)
                {
                    LastError = e.Message;
                    CommFatalErrorOccuredEvent?.Invoke(this, new EventArgs());
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Код опросной команды
        /// </summary>
        private void PollCommand()
        {
            if (FatalPortFailFlag) return;

            try
            {
                if (CommMutex.WaitOne(5000))
                {
                    PollCommandCode?.Invoke(ComPort, PollData);
                    CommMutex.ReleaseMutex();
                } else throw new TimeoutException("Слишком длительное ожидание окна для общения с контроллером!");
            }
            catch (Exception e)
            {
                LastError = e.Message;
                CommErrorOccuredEvent?.Invoke(this, new EventArgs());
            }
        }
    }
}