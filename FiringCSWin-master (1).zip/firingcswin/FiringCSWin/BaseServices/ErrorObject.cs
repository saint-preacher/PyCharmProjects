﻿using static FiringCSWin.BaseServices.ErrorNotifierService;

namespace FiringCSWin.BaseServices
{
    public class ErrorObject
    {
        public string Message { get; }

        public E_LEVEL LogLevel { get; }

        public uint Number { get; }

        /// <summary>
        /// TickCount последнего упоминания
        /// </summary>
        public int LastSignaled { get; set; }

        /// <summary>
        /// Регулярность отображения в миллисекундах
        /// </summary>
        public int Regularity { get; set; }

        /// <summary>
        /// Создание объекта ошибки
        /// </summary>
        /// <param name="number">Номер ошибки</param>
        /// <param name="message">Текст сообщения</param>
        /// <param name="level">Уровень угрозы</param>
        public ErrorObject(uint number, string message, E_LEVEL level, int regularity)
        {
            Number = number;
            Message = message;
            LogLevel = level;
            Regularity = regularity;
        }
    }
}