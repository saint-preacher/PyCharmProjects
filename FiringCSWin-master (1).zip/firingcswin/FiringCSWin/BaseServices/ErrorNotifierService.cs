﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows;

namespace FiringCSWin.BaseServices
{
    public class ErrorNotifierService
    {
        private IBaseDialogService dialogService;

        public const uint ERROR_UNKNOWN = uint.MaxValue;

        /// <summary>
        /// Уровень возникшей ошибки: Информация, Предупреждение, Серьёзная, Фатальная
        /// </summary>
        public enum E_LEVEL { Information, Warning, Error, Fatal };

        /// <summary>
        /// Уровень лога необходимый для записи в лог
        /// </summary>
        public E_LEVEL LogLevel { get; set; } = E_LEVEL.Error;

        /// <summary>
        /// Словарь с ошибками. Ключ = номеру ошибки, значение = объект ошибки
        /// </summary>
        protected Dictionary<uint, ErrorObject> ErrorDictionary = new Dictionary<uint, ErrorObject>();

        /// <summary>
        /// Поток для сохранения лога
        /// </summary>
        public Stream LogStream { get; set; }

        /// <summary>
        /// Блокировка открытия диалоговых окон, если уже открыто окно
        /// </summary>
        private Mutex MessageBoxMutex = new Mutex();

        /// <summary>
        /// Блокировка одновременной записи в файл
        /// </summary>
        private Mutex LogFileMutex = new Mutex();

        /// <summary>
        /// Создание объекта службы регистратора ошибок
        /// </summary>
        /// <param name="dlgService">Сервис вызова диалоговых окон</param>
        /// <param name="UnknownErrorObject">Объект неизвестной ошибки для предварительной регистрации</param>
        public ErrorNotifierService(IBaseDialogService dlgService, ErrorObject UnknownErrorObject)
        {
            dialogService = dlgService;
            LogStream = new MemoryStream();
            Register(UnknownErrorObject);
        }

        ~ErrorNotifierService()
        {
            LogStream.Close();
        }

        /// <summary>
        /// Сообщение о событии
        /// </summary>
        /// <param name="message">Текст сообщения</param>
        public void Report(uint number)
        {
            // поиск ошибки по номеру в словаре
            if (ErrorDictionary.ContainsKey(number))
            {
                var errObject = ErrorDictionary[number];

                if ((Environment.TickCount - errObject.LastSignaled) > errObject.Regularity)
                {
                    // запись в лог файл по уровню LogLevel
                    if ((LogStream != null) && (errObject.LogLevel >= LogLevel))
                    {
                        Log(errObject.Message, LogStream, DateTime.Now);
                    }

                    // в случае ошибки уровнем равным или выше Error открыть мессаджбокс
                    if (errObject.LogLevel >= E_LEVEL.Error) AlertMessageBox(errObject);

                    errObject.LastSignaled = Environment.TickCount;
                }
            }
            else Report(ERROR_UNKNOWN);
        }

        /// <summary>
        /// Сохранение строки в файл лога
        /// </summary>
        /// <param name="message">Сообщение для записи</param>
        /// <param name="writeableStream">Поток для записи</param>
        /// <param name="dateTime">Дата и время произошедшей ошибки</param>
        public void Log(string message, Stream writeableStream, DateTime dateTime)
        {
            var DateTimeString = dateTime.ToString("[dd.MM.yyyy HH:mm:ss]");
            if (LogFileMutex.WaitOne(2500))
            {
                var logFile = new StreamWriter(writeableStream);
                logFile.WriteLine($"{DateTimeString} {message}");
                logFile.Flush();
                LogFileMutex.ReleaseMutex();
            }
        }

        /// <summary>
        /// Показываем сообщение об ошибке, но только если у нас уже не выведено одно из
        /// </summary>
        /// <param name="errObject">Объект ошибки</param>
        protected void AlertMessageBox(ErrorObject errObject)
        {
            if (MessageBoxMutex.WaitOne(1000))
            {
                string Caption = "Ошибка";
                MessageBoxImage Image = MessageBoxImage.Error;
                switch (errObject.LogLevel)
                {
                    case E_LEVEL.Information:
                        Caption = "Сообщение";
                        Image = MessageBoxImage.Information;
                        break;

                    case E_LEVEL.Warning:
                        Caption = "Внимание";
                        Image = MessageBoxImage.Warning;
                        break;

                    case E_LEVEL.Error:
                        Caption = "Ошибка";
                        Image = MessageBoxImage.Error;
                        break;

                    case E_LEVEL.Fatal:
                        Caption = "Фатальная ошибка";
                        Image = MessageBoxImage.Error;
                        break;
                }
                dialogService.ShowMsgBox(errObject.Message, Caption, MessageBoxButton.OK, Image);
                MessageBoxMutex.ReleaseMutex();
            }
        }

        /// <summary>
        /// Поиск в словаре ошибок по тексту сообщения
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="number">Номер найденного или 0 в противном случае</param>
        /// <returns></returns>
        protected bool ErrorDictionaryContainsMessage(string msg, out uint number)
        {
            foreach (var pair in ErrorDictionary)
            {
                var error = pair.Value;
                if (error.Message.Equals(msg))
                {
                    number = pair.Key;
                    return true;
                }
            }

            number = 0;
            return false;
        }

        /// <summary>
        /// Найти неиспользуемый номер для ошибки
        /// </summary>
        /// <returns>Номер</returns>
        public uint UnoccupiedNumber()
        {
            uint i;
            for (i = 1; i < uint.MaxValue; i++)
            {
                if (!ErrorDictionary.ContainsKey(i)) break;
            }

            return i;
        }

        /// <summary>
        /// Регистрация ошибки в системе
        /// </summary>
        /// <param name="Error">Объект ошибки</param>
        public void Register(ErrorObject Error)
        {
            if (Error.Number != ERROR_UNKNOWN) ErrorDictionary.Add(Error.Number, Error);
        }
    }
}