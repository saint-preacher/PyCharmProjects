﻿using FiringCSWin.MVVMBase;
using System;
using System.Windows.Input;

namespace FiringCSWin.ViewModels
{
    public class UshortInputCalcViewModel : InputCalcViewModel<ushort>
    {
        /// <summary>
        /// Создаём ViewModel для окна ввода (Калькулятор)
        /// </summary>
        /// <param name="title">Заголовок окна</param>
        public UshortInputCalcViewModel(string title) : base(title)
        {
            DisableDotButton();
            CurrentValue = 0;
        }

        /// <summary>
        /// Команда ввода цифры
        /// </summary>
        public override ICommand InputCommand =>
            _inputCommand ?? (_inputCommand = new RelayCommand<ushort>((digit) =>
            {
                try
                {
                    checked
                    {
                        var v = (ushort)(CurrentValue * 10);
                        v += digit;
                        CurrentValue = v;
                    }
                }
                catch (OverflowException) { }
            }));

        /// <summary>
        /// Команда очистки значения
        /// </summary>
        public override ICommand ClearCommand =>
            _clearCommand ?? (_clearCommand = new RelayCommand<object>((o) =>
            {
                CurrentValue = 0;
            }));

        /// <summary>
        /// Команда отмены ввода цифры
        /// </summary>
        public override ICommand DeleteCommand =>
            _deleteCommand ?? (_deleteCommand = new RelayCommand<object>((o) =>
            {
                var v = (ushort)(CurrentValue / 10);
                CurrentValue = v;
            }));
    }
}