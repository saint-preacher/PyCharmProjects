﻿using FiringCSWin.MVVMBase;
using FiringCSWin.Services;
using System.Collections.Generic;
using System.Windows.Input;

namespace FiringCSWin.ViewModels
{
    public class SettingsViewModel : ModelBase
    {
        private RelayCommand<object> _saveCfgCommand;
        private RelayCommand<object> _cancelCommand;
        private bool _closeTrigger;
        private string _comPortName;
        private List<int> _baudratesList;
        private int _baudrate;
        private IParameters ParamsService;

        /// <summary>
        /// Создание объекта ViewModel для окна настройки параметров
        /// </summary>
        /// <param name="paramService">Сервис настроек</param>
        public SettingsViewModel(IParameters paramService)
        {
            ParamsService = paramService;
            BaudratesList = new List<int>() { 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200 };

            // загрузка параметров из файла
            COMPortName = ParamsService.ComPortName;
            Baudrate = ParamsService.Baudrate;
        }

        /// <summary>
        /// Список выбираемых скоростей опроса
        /// </summary>
        public List<int> BaudratesList
        {
            get => _baudratesList;
            set
            {
                _baudratesList = value;
                RaisePropertyChanged(nameof(BaudratesList));
            }
        }

        /// <summary>
        /// Символическое имя последовательного порта для связи с платой
        /// </summary>
        public string COMPortName
        {
            get => _comPortName;
            set
            {
                _comPortName = value;
                RaisePropertyChanged(nameof(COMPortName));
            }
        }

        /// <summary>
        /// Скорость опроса (бод/сек)
        /// </summary>
        public int Baudrate
        {
            get => _baudrate;
            set
            {
                _baudrate = value;
                RaisePropertyChanged(nameof(Baudrate));
            }
        }

        /// <summary>
        /// Триггер закрытия окна
        /// </summary>
        public bool CloseTrigger
        {
            get => _closeTrigger;
            set
            {
                _closeTrigger = value;
                RaisePropertyChanged(nameof(CloseTrigger));
            }
        }

        /// <summary>
        /// Команда для сохранения настроек
        /// </summary>
        public ICommand SaveConfigCommand =>
            _saveCfgCommand ?? (_saveCfgCommand = new RelayCommand<object>((o) =>
            {
                // записываем в параметры новые значения
                ParamsService.ComPortName = COMPortName;
                ParamsService.Baudrate = Baudrate;

                // вызываем сохранение файла настроек
                ParamsService.SaveParameters();

                CloseTrigger = true;
            }));

        /// <summary>
        /// Команда отмены изменения параметров
        /// </summary>
        public ICommand CancelCommand => _cancelCommand ?? (_cancelCommand = new RelayCommand<object>((o) => { CloseTrigger = true; }));
    }
}