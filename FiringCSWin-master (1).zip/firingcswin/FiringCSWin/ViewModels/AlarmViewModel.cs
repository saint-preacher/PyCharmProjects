﻿using FiringCSWin.MVVMBase;
using System;
using System.Windows.Input;

namespace FiringCSWin.ViewModels
{
    public class AlarmViewModel : ModelBase
    {
        private RelayCommand<object> _viewClosedCommand;
        private string _alarmText;
        private Action OnAlarmCloseAction;

        public AlarmViewModel(Action onAlarmCloseAction)
        {
            OnAlarmCloseAction = onAlarmCloseAction;
        }

        /// <summary>
        /// Текст описывающий причины аварии
        /// </summary>
        public string AlarmText
        {
            get => _alarmText;
            set
            {
                _alarmText = value;
                RaisePropertyChanged(nameof(AlarmText));
            }
        }

        /// <summary>
        /// Остановка процесса автокассетирования, вследствие возникшей ошибки
        /// </summary>
        public ICommand ViewClosedCommand =>
            _viewClosedCommand ?? (_viewClosedCommand = new RelayCommand<object>((o) =>
            {
                OnAlarmCloseAction?.Invoke();
            }));
    }
}