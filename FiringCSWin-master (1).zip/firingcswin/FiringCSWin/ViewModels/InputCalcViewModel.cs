﻿using FiringCSWin.MVVMBase;
using System;
using System.Windows.Input;

namespace FiringCSWin.ViewModels
{
    public class InputCalcViewModel<T> : ModelBase
    {
        protected RelayCommand<T> _inputCommand;
        protected RelayCommand<object> _saveValueCommand;
        protected RelayCommand<object> _cancelCommand;
        protected RelayCommand<object> _deleteCommand;
        protected RelayCommand<object> _clearCommand;
        protected RelayCommand<object> _dotCommand;
        protected T _currentValue;
        protected string _viewTitle;
        protected bool _disableDotButton;
        protected bool _closeTrigger;
        protected Action<T> _saveAction;

        protected InputCalcViewModel(string title)
        {
            ViewTitle = title;
        }

        /// <summary>
        /// Триггер закрытия окна
        /// </summary>
        public bool CloseTrigger
        {
            get => _closeTrigger;
            set
            {
                _closeTrigger = value;
                RaisePropertyChanged(nameof(CloseTrigger));
            }
        }

        /// <summary>
        /// Действие при нажатии кнопки сохранения (ОК)
        /// </summary>
        public Action<T> ApplyAction
        {
            get => _saveAction;
            set
            {
                _saveAction = value;
                RaisePropertyChanged(nameof(ApplyAction));
            }
        }

        /// <summary>
        /// Текущее набранное значение
        /// </summary>
        public T CurrentValue
        {
            get => _currentValue;
            set
            {
                _currentValue = value;
                RaisePropertyChanged(nameof(CurrentValue));
            }
        }

        /// <summary>
        /// Заголовок окна
        /// </summary>
        public string ViewTitle
        {
            get => _viewTitle;
            set
            {
                _viewTitle = value;
                RaisePropertyChanged(nameof(ViewTitle));
            }
        }

        /// <summary>
        /// Отключить кнопку десятичного разделителя
        /// </summary>
        public void DisableDotButton()
        {
            _disableDotButton = true;
            RaisePropertyChanged(nameof(DotButtonIsEnabled));
        }

        /// <summary>
        /// Включить кнопку десятичного разделителя
        /// </summary>
        public void EnableDotButton()
        {
            _disableDotButton = false;
            RaisePropertyChanged(nameof(DotButtonIsEnabled));
        }

        /// <summary>
        /// Определяет показывать ли кнопку десятичного разделителя
        /// </summary>
        public bool DotButtonIsEnabled => _disableDotButton;

        /// <summary>
        /// Команда ввода символа
        /// </summary>
        public virtual ICommand InputCommand => _inputCommand ?? (_inputCommand = new RelayCommand<T>((d) => { }));

        /// <summary>
        /// Команда удаления одного символа
        /// </summary>
        public virtual ICommand DeleteCommand => _deleteCommand ?? (_deleteCommand = new RelayCommand<object>((d) => { }));

        /// <summary>
        /// Команда очистки значения
        /// </summary>
        public virtual ICommand ClearCommand => _clearCommand ?? (_clearCommand = new RelayCommand<object>((d) => { }));

        /// <summary>
        /// Команда ввода десятичного разделителя
        /// </summary>
        public virtual ICommand DotCommand => _dotCommand ?? (_dotCommand = new RelayCommand<object>((d) => { }));

        /// <summary>
        /// Команда утверждения введённого значения
        /// </summary>
        public virtual ICommand SaveCommand => _saveValueCommand ?? (_saveValueCommand = new RelayCommand<object>((o) =>
        {
            ApplyAction?.Invoke(CurrentValue);
            CloseTrigger = true;
        }));

        /// <summary>
        /// Команда отмены ввода значения
        /// </summary>
        public virtual ICommand CancelCommand => _cancelCommand ?? (_cancelCommand = new RelayCommand<object>((o) => { CloseTrigger = true; }));
    }
}