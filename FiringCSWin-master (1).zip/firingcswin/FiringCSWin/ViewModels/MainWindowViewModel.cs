﻿using FiringCSWin.BaseServices;
using FiringCSWin.Models;
using FiringCSWin.MVVMBase;
using FiringCSWin.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace FiringCSWin.ViewModels
{
    public class MainWindowViewModel : CommAvailViewModel
    {
        private RelayCommand<CancelEventArgs> _endUpCommand;
        private RelayCommand<object> _activateManualModeCommand;
        private RelayCommand<object> _activateSettingsCommand;

        private RelayCommand<object> _openConnHeadUpCommand;
        private RelayCommand<object> _startAcqHeadUpCommand;
        private RelayCommand<object> _stopAcqHeadUpCommand;
        private RelayCommand<object> _closeConnHeadUpCommand;

        private RelayCommand<object> _openConnSide1Command;
        private RelayCommand<object> _startAcqSide1Command;
        private RelayCommand<object> _stopAcqSide1Command;
        private RelayCommand<object> _closeConnSide1Command;

        private RelayCommand<object> _openConnSide2Command;
        private RelayCommand<object> _startAcqSide2Command;
        private RelayCommand<object> _stopAcqSide2Command;
        private RelayCommand<object> _closeConnSide2Command;

        private RelayCommand<object> _saveFrameHeadUpCommand;
        private RelayCommand<object> _saveNFramesHeadUpCommand;
        private RelayCommand<object> _loadFileHeadUpFrameCommand;

        private RelayCommand<object> _saveFrameSide1Command;
        private RelayCommand<object> _saveNFramesSide1Command;
        private RelayCommand<object> _loadFileSide1FrameCommand;

        private RelayCommand<object> _saveFrameSide2Command;
        private RelayCommand<object> _saveNFramesSide2Command;
        private RelayCommand<object> _loadFileSide2FrameCommand;

        private RelayCommand<object> _headUpExpTimeChangedCommand;
        private RelayCommand<object> _side1ExpTimeChangedCommand;
        private RelayCommand<object> _side2ExpTimeChangedCommand;

        private RelayCommand<object> _initBackgroundSubstractorCommand;
        private RelayCommand<object> _clearListsCommand;
                
        private GxSingleCam HeadUpCamera; // TODO может запихнуть всё это в модель
        private GxSingleCam Side1Camera;
        private GxSingleCam Side2Camera;

        public ICameraModel HeadUpModel { get; protected set; }
        public ISideCameraModel Side1Model { get; protected set; }
        public ISideCameraModel Side2Model { get; protected set; }
        
        private IGxCamLocator CameraLocator;
        private DispatcherTimer LocatorUpdate;
        private IHeadUpImageProcessing HeadUpProcessingService;
        private ISideImageProcessing Side1ProcessingService;
        private ISideImageProcessing Side2ProcessingService;
        private ITubeManager TubeManager;
        private ImageSource _headUpFrameSource;
        private ImageSource _side1FrameSource;
        private ImageSource _side2FrameSource;
        private List<string> _camerasList;
        private IErrorService ErrorService;

        public MainWindowViewModel(IGxCamLocator camLocator, IErrorService errorService, IHeadUpImageProcessing headUpProcessingService, ISideImageProcessing side1ProcessingService, ISideImageProcessing side2ProcessingService,
            IDialogService dlgService, IParameters paramService, ITubeManager tubeManager, ICommPollableService<ISensorsModel> commService, (IAxisModel td, IAxisModel dd, IAxisModel cd) axisModels,
            ICasettingAlgModel cassAlgModel, IValvesModel valvesModel, (IRemoverModel,IRemoverModel,IRemoverModel) removerModels, ISensorsModel sensors, ICameraModel headUpCamModel, ISideCameraModel side1CamModel,
            ISideCameraModel side2CamModel)
        {
            DialogService = dlgService;
            ErrorService = errorService;
            ParamsService = paramService;
            HeadUpProcessingService = headUpProcessingService;
            Side1ProcessingService = side1ProcessingService;
            Side2ProcessingService = side2ProcessingService;

            HeadUpModel = headUpCamModel;
            Side1Model = side1CamModel;
            Side2Model = side2CamModel;

            CameraLocator = camLocator;
            LocatorUpdate = new DispatcherTimer() { Interval = new TimeSpan(0, 0, 20) };
            TubeManager = tubeManager;
            UpdateLocator();

            Sensors = sensors;
            CasetteAlg = cassAlgModel;
            TransporterDrive = axisModels.td;
            DiscDrive = axisModels.dd;
            CasetteDrive = axisModels.cd;
            Valves = valvesModel;

            Remover1 = removerModels.Item1;
            Remover2 = removerModels.Item2;
            Remover3 = removerModels.Item3;

            CommService = commService;

            InitParams();

            LocatorUpdate.Tick += (sender, args) => UpdateLocator();
            LocatorUpdate.Start();

            LoadHeadUpModelParameters();
            LoadSide1ModelParameters();
            LoadSide2ModelParameters();

            BadTubes.CollectionChanged += (sender, args) => RaisePropertyChanged(nameof(BadTubesCount));
            GoodTubes.CollectionChanged += (sender, args) => RaisePropertyChanged(nameof(GoodTubesCount));

            TubeManager.BadTubeAdded += TubeManager_BadTubeAdded;
            TubeManager.GoodTubeAdded += TubeManager_GoodTubeAdded;
        }

        /// <summary>
        /// Проверить на доступность камеру по серийному номеру
        /// </summary>
        /// <param name="serialNumber">Серийный номер</param>
        private bool CheckCameraBySN(string serialNumber) => !string.IsNullOrEmpty(serialNumber) && CamerasList.Contains(serialNumber);

        /// <summary>
        /// Загрузка сохранённых параметров для камеры сверху
        /// </summary>
        private void LoadHeadUpModelParameters()
        {            
            if (CheckCameraBySN(ParamsService.LastCameraSNHeadUp)) HeadUpModel.SelectedCamera = ParamsService.LastCameraSNHeadUp;

            HeadUpModel.ExposureString = ParamsService.LastExposureHeadUp.ToString("F1");
            HeadUpModel.NFramesString = ParamsService.LastNSaveFramesHeadUp.ToString();
            HeadUpModel.ThresholdString = ParamsService.LastThreshold.ToString();
            HeadUpModel.ROITopString = ParamsService.LastROITopHeadUp.ToString();
            HeadUpModel.ROIBottomString = ParamsService.LastROIBottomHeadUp.ToString();
            HeadUpModel.RefMillimetersString = ParamsService.RefMillimetersHeadUp.ToString("F7");
            HeadUpModel.MaxGoodParamString = ParamsService.MaxTubeLength.ToString("F3");
            HeadUpModel.MinGoodParamString = ParamsService.MinTubeLength.ToString("F3");
            HeadUpModel.ROILeftString = ParamsService.BeltLeftPointX.ToString();
            HeadUpModel.ROIRightString = ParamsService.BeltRightPointX.ToString();
        }

        /// <summary>
        /// Загрузка сохранённых параметров для камеры сбоку 1
        /// </summary>
        private void LoadSide1ModelParameters()
        {
            if (CheckCameraBySN(ParamsService.LastCameraSNSide1)) Side1Model.SelectedCamera = ParamsService.LastCameraSNSide1;

            Side1Model.ExposureString = ParamsService.LastExposureSide1.ToString("F1");
            Side1Model.NFramesString = ParamsService.LastNSaveFramesSide1.ToString();
            Side1Model.ROITopString = ParamsService.LastROITopSide1.ToString();
            Side1Model.ROIBottomString = ParamsService.LastROIBottomSide1.ToString();
            Side1Model.RefMillimetersString = ParamsService.RefMillimetersSide1.ToString("F7");

            Side1Model.ThresholdString = ParamsService.LastSide1Threshold.ToString();
            Side1Model.AreaCalcThresholdString = ParamsService.LastAreaCalcThresholdSide1.ToString();
            Side1Model.AreaCalcCorrectionString = ParamsService.LastAreaCalcCorrectionSide1.ToString();
            Side1Model.MinEllipseLenString = ParamsService.MinEllipseLenSide1.ToString();
            Side1Model.MinGoodParamString = ParamsService.MinOuterDiamSide1.ToString("F2");
            Side1Model.MaxGoodParamString = ParamsService.MaxOuterDiamSide1.ToString("F2");
            Side1Model.MinInnerParamString = ParamsService.MinInnerDiamSide1.ToString("F2");
            Side1Model.MaxInnerParamString = ParamsService.MaxInnerDiamSide1.ToString("F2");
            Side1Model.ROILeftString = ParamsService.LastROILeftSide1.ToString();
            Side1Model.ROIRightString = ParamsService.LastROIRightSide1.ToString();
        }

        /// <summary>
        /// Загрузка сохранённых параметров для камеры сбоку 2
        /// </summary>
        private void LoadSide2ModelParameters()
        {
            if (CheckCameraBySN(ParamsService.LastCameraSNSide2)) Side2Model.SelectedCamera = ParamsService.LastCameraSNSide2;

            Side2Model.ExposureString = ParamsService.LastExposureSide2.ToString("F1");
            Side2Model.NFramesString = ParamsService.LastNSaveFramesSide2.ToString();
            Side2Model.ROITopString = ParamsService.LastROITopSide2.ToString();
            Side2Model.ROIBottomString = ParamsService.LastROIBottomSide2.ToString();
            Side2Model.RefMillimetersString = ParamsService.RefMillimetersSide2.ToString("F7");

            Side2Model.ThresholdString = ParamsService.LastSide2Threshold.ToString();
            Side2Model.AreaCalcThresholdString = ParamsService.LastAreaCalcThresholdSide2.ToString();
            Side2Model.AreaCalcCorrectionString = ParamsService.LastAreaCalcCorrectionSide2.ToString();
            Side2Model.MinEllipseLenString = ParamsService.MinEllipseLenSide2.ToString();
            Side2Model.MinGoodParamString = ParamsService.MinOuterDiamSide2.ToString("F2");
            Side2Model.MaxGoodParamString = ParamsService.MaxOuterDiamSide2.ToString("F2");
            Side2Model.MinInnerParamString = ParamsService.MinInnerDiamSide2.ToString("F2");
            Side2Model.MaxInnerParamString = ParamsService.MaxInnerDiamSide2.ToString("F2");
            Side2Model.ROILeftString = ParamsService.LastROILeftSide2.ToString();
            Side2Model.ROIRightString = ParamsService.LastROIRightSide2.ToString();
        }

        private void TubeManager_GoodTubeAdded(TubeModel tube) => GuiContext.Post(GoodTubeAdd, tube);

        private void GoodTubeAdd(object state) {
            var tube = state as TubeModel;
            GoodTubes.Insert(0, tube);
        }

        private void TubeManager_BadTubeAdded(TubeModel tube) => GuiContext.Post(BadTubeAdd, tube);

        private void BadTubeAdd(object state)
        {
            System.Diagnostics.Debug.WriteLine($"We've got to BadTubeAdd proc ... {Environment.TickCount}");
            var tube = state as TubeModel;
            if (!((tube.Length == 0) & (tube.Diameter == 0))) BadTubes.Insert(0, tube);

            switch (tube.CameraId)
            {
                case TubeDataCamera.HeadUp:
                    if (Side1Model.RemoverMode == RemoverMode.RemoveBad) Remover1CycleCommand.Execute(null);
                    break;
                case TubeDataCamera.Side1:
                    if (Side2Model.RemoverMode == RemoverMode.RemoveBad) Remover2CycleCommand.Execute(null);
                    break;
                case TubeDataCamera.Side2:
                    if (HeadUpModel.RemoverMode == RemoverMode.RemoveBad) Remover3CycleCommand.Execute(null);
                    break;
            }
        }

        /// <summary>
        /// Очистка списков трубок
        /// </summary>
        public ICommand ClearListsCommand =>
            _clearListsCommand ?? (_clearListsCommand = new RelayCommand<object>((o) =>
            {
                BadTubes.Clear();
                GoodTubes.Clear();
            }));

        /// <summary>
        /// Коллекция плохих (проверенных) трубок
        /// </summary>
        public ObservableCollection<TubeModel> BadTubes { get; set; } = new ObservableCollection<TubeModel>();

        /// <summary>
        /// Коллекция хороших (проверенных) трубок
        /// </summary>
        public ObservableCollection<TubeModel> GoodTubes { get; set; } = new ObservableCollection<TubeModel>();

        /// <summary>
        /// Количество плохих прошедших трубок
        /// </summary>
        public int BadTubesCount => BadTubes.Count;

        /// <summary>
        /// Количество хороших прошедших трубок
        /// </summary>
        public int GoodTubesCount => GoodTubes.Count;

        /// <summary>
        /// Обработчик события по изменению содержимого кадра с камеры сверху
        /// </summary>
        private void HeadUpFrameChanged(IntPtr dataPointer, long cols, long rows)
        {
            System.Diagnostics.Debug.WriteLine($"HeadUpFrameChanged event fire ... {Environment.TickCount}");
            HeadUpProcessingService.LoadFromFrame(dataPointer, cols, rows); // загружаем свежий кадр для обработки
            FillHeadUpFrameSource();

            if (HeadUpModel.SaveFramesCount > 0)
            {
                HeadUpProcessingService.SaveToFile(string.Empty, "верх");
                HeadUpModel.SaveFramesCount--;
            }
        }

        /// <summary>
        /// Обработчик события по изменению содержимого кадра с камеры сбоку 1
        /// </summary>
        private void Side1FrameChanged(IntPtr dataPointer, long cols, long rows)
        {
            Side1ProcessingService.LoadFromFrame(dataPointer, cols, rows);
            FillSide1FrameSource();

            if(Side1Model.SaveFramesCount > 0)
            {
                Side1ProcessingService.SaveToFile(string.Empty, "право");
                Side1Model.SaveFramesCount--;
            }
        }

        /// <summary>
        /// Обработчик события по изменению содержимого кадра с камеры сбоку 2
        /// </summary>
        /// <param name="dataPointer"></param>
        /// <param name="cols"></param>
        /// <param name="rows"></param>
        private void Side2FrameChanged(IntPtr dataPointer, long cols, long rows)
        {
            Side2ProcessingService.LoadFromFrame(dataPointer, cols, rows);
            FillSide2FrameSource();

            if (Side2Model.SaveFramesCount > 0)
            {
                Side2ProcessingService.SaveToFile(string.Empty, "лево");
                Side2Model.SaveFramesCount--;
            }
        }

        /// <summary>
        /// Произвести операции и отобразить изображение на экране
        /// </summary>
        private void FillHeadUpFrameSource()
        {
            var bitmapSource = GetHeadUpLayerByFrameMode();

            HeadUpModel.CanvasWidth = bitmapSource.Width;
            HeadUpModel.CanvasHeight = bitmapSource.Height;
            HeadUpFrameSource = bitmapSource;
        }

        private void FillSide1FrameSource()
        {
            var bitmapSource = GetSide1LayerByFrameMode();

            Side1Model.CanvasWidth = bitmapSource.Width;
            Side1Model.CanvasHeight = bitmapSource.Height;
            Side1FrameSource = bitmapSource;
        }        

        private void FillSide2FrameSource()
        {
            var bitmapSource = GetSide2LayerByFrameMode();

            Side2Model.CanvasWidth = bitmapSource.Width;
            Side2Model.CanvasHeight = bitmapSource.Height;
            Side2FrameSource = bitmapSource; 
        }

        /// <summary>
        /// Использование режима кадра
        /// </summary>
        /// <returns>Результат обработки</returns>
        private ImageSource GetHeadUpLayerByFrameMode()
        {
            var roi = (HeadUpModel.ROITop, HeadUpModel.ROIBottom);
            var belt = (HeadUpModel.ROILeft, HeadUpModel.ROIRight);

            switch (HeadUpModel.FrameMode)
            {
                case FrameMode.Threshold:
                    return HeadUpProcessingService.Threshold(HeadUpModel.Threshold, roi, belt);
                case FrameMode.Edges:
                    return HeadUpProcessingService.EdgesFind(HeadUpModel.Threshold, roi, belt);
                case FrameMode.MOGBackgroundRemover:
                    if(HeadUpProcessingService.BckgSubstractorInitialized)
                        return HeadUpProcessingService.GetForegroundMask(roi, belt);
                    break;
                case FrameMode.WithCalculatedHelpers:
                    if (!HeadUpProcessingService.BckgSubstractorInitialized) break;
                    var img = HeadUpProcessingService.CalculateTubeLength(HeadUpModel.Threshold, HeadUpModel.ROITop, HeadUpModel.ROIBottom,
                        HeadUpModel.ROILeft, HeadUpModel.ROIRight, HeadUpModel.RefMillimeters, out double tubelength, HeadUpModel.DebugEnabled);
                    if (tubelength >= 0.0) TubeLengthHandling(tubelength);
                    System.Diagnostics.Debug.WriteLine($"End of tube len calculation {Environment.TickCount}");
                    return img;
            }

            return HeadUpProcessingService.GetInitialFrame(roi, belt);
        }

        private ImageSource GetSide1LayerByFrameMode()
        {
            var roiY = (Side1Model.ROITop, Side1Model.ROIBottom);
            var roiX = (Side1Model.ROILeft, Side1Model.ROIRight);

            ImageSource img;

            switch (Side1Model.FrameMode)
            {
                case FrameMode.Threshold:
                    img = Side1ProcessingService.Threshold(Side1Model.AreaCalcThreshold, (Side1Model.ROITop, Side1Model.ROIBottom), (Side1Model.ROILeft, Side1Model.ROIRight));
                    return img;
                case FrameMode.WithCalculatedHelpers:
                    img = Side1ProcessingService.CalculateDiameters(Side1Model.Threshold, Side1Model.ROITop, Side1Model.ROIBottom, Side1Model.ROILeft,
                        Side1Model.ROIRight, Side1Model.AreaCalcThreshold, Side1Model.AreaCalcCorrection, (int)Side1Model.MinEllipseLen,
                        out List<double> diams, out List<double> thicks);
                    // TODO if(tubefound) 
                    TubeDiamsHandling1(diams.Average(), thicks.Average());
                    return img;
            }

            return Side1ProcessingService.GetInitialFrame(roiX, roiY);
        }

        private ImageSource GetSide2LayerByFrameMode()
        {
            var roiX = (Side2Model.ROILeft, Side2Model.ROIRight);
            var roiY = (Side2Model.ROITop, Side2Model.ROIBottom);

            ImageSource img;

            switch (Side2Model.FrameMode)
            {
                case FrameMode.Threshold:
                    img = Side2ProcessingService.Threshold(Side2Model.AreaCalcThreshold, (Side2Model.ROITop, Side2Model.ROIBottom), (Side2Model.ROILeft, Side2Model.ROIRight));
                    return img;
                case FrameMode.WithCalculatedHelpers:
                    img = Side2ProcessingService.CalculateDiameters(Side2Model.Threshold, Side2Model.ROITop, Side2Model.ROIBottom, Side2Model.ROILeft,
                        Side2Model.ROIRight, Side2Model.AreaCalcThreshold, Side2Model.AreaCalcCorrection, (int)Side2Model.MinEllipseLen,
                        out List<double> diams, out List<double> thicks);
                    // TODO if(tubefound) 
                    TubeDiamsHandling2(diams.Average(), thicks.Average());
                    return img;
            }

            return Side2ProcessingService.GetInitialFrame(roiX, roiY);
        }

        /// <summary>
        /// Обработка сообщения о трубке
        /// </summary>
        /// <param name="tubelength">Длина трубки</param>
        private void TubeLengthHandling(double tubelength)
        {
            TubeManager.NewTubeByLength(tubelength, HeadUpModel.MinGoodParam, HeadUpModel.MaxGoodParam);
        }

        private void TubeDiamsHandling1(double outer, double inner)
        {
            TubeManager.NewTubeByDiams(TubeDataCamera.Side1, outer, Side1Model.MinGoodParam,
                Side1Model.MaxGoodParam, inner, Side1Model.MinInnerParam, Side1Model.MaxInnerParam);
        }

        private void TubeDiamsHandling2(double outer, double inner)
        {
            TubeManager.NewTubeByDiams(TubeDataCamera.Side2, outer, Side2Model.MinGoodParam,
                Side2Model.MaxGoodParam, inner, Side2Model.MinInnerParam, Side2Model.MaxInnerParam);
        }

        /// <summary>
        /// Обновление списка камер
        /// </summary>
        private void UpdateLocator() => CamerasList = CameraLocator.GetDeviceList();          

        /// <summary>
        /// Источник для вывода изображения кадра
        /// </summary>
        public ImageSource HeadUpFrameSource
        {
            get => _headUpFrameSource;
            set
            {
                _headUpFrameSource = value;
                RaisePropertyChanged(nameof(HeadUpFrameSource));
            }
        }

        public ImageSource Side1FrameSource
        {
            get => _side1FrameSource;
            set
            {
                _side1FrameSource = value;
                RaisePropertyChanged(nameof(Side1FrameSource));
            }
        }

        public ImageSource Side2FrameSource
        {
            get => _side2FrameSource;
            set
            {
                _side2FrameSource = value;
                RaisePropertyChanged(nameof(Side2FrameSource));
            }
        }

        /// <summary>
        /// Список доступных камер
        /// </summary>
        public List<string> CamerasList
        {
            get => _camerasList;
            set
            {
                _camerasList = value;
                RaisePropertyChanged(nameof(CamerasList));
            }
        }              

        /// <summary>
        /// Загрузка фона для субстрактора
        /// </summary>
        public ICommand InitBackgroundSubstractorCommand =>
            _initBackgroundSubstractorCommand ?? (_initBackgroundSubstractorCommand = new RelayCommand<object>((o) =>
            {
                HeadUpProcessingService.InitBckgSubstractor();
            }));

        /// <summary>
        /// Сохранить следующие N кадров
        /// </summary>
        public ICommand SaveNFramesHeadUpCommand =>
            _saveNFramesHeadUpCommand ?? (_saveNFramesHeadUpCommand = new RelayCommand<object>((e) =>
            {
                HeadUpModel.SaveFramesCount = HeadUpModel.NFramesSaveCount;
            }));

        /// <summary>
        /// Сохранить следующие N кадров
        /// </summary>
        public ICommand SaveNFramesSide1Command =>
            _saveNFramesSide1Command ?? (_saveNFramesSide1Command = new RelayCommand<object>((e) =>
            {
                Side1Model.SaveFramesCount = Side1Model.NFramesSaveCount;
            }));

        /// <summary>
        /// Сохранить следующие N кадров
        /// </summary>
        public ICommand SaveNFramesSide2Command =>
            _saveNFramesSide2Command ?? (_saveNFramesSide2Command = new RelayCommand<object>((e) =>
            {
                Side2Model.SaveFramesCount = Side2Model.NFramesSaveCount;
            }));

        /// <summary>
        /// Команда остановки работы
        /// </summary>
        public ICommand EndUpCommand =>
            _endUpCommand ?? (_endUpCommand = new RelayCommand<CancelEventArgs>((e) =>
            {
                LocatorUpdate.Stop();

                SaveHeadUpParameters();
                SaveSide1Parameters();
                SaveSide2Parameters();

                ParamsService.BeltLeftPointX = HeadUpModel.ROILeft;
                ParamsService.BeltRightPointX = HeadUpModel.ROIRight;
                ParamsService.SaveParameters();
            }));

        private void SaveHeadUpParameters()
        {
            // если открыта камера, то закрываем
            while (!(HeadUpModel.CurrentState <= CameraState.Offline))
            {
                switch (HeadUpModel.CurrentState)
                {
                    case CameraState.AcqStarted:
                        StopAcqHeadUpCommand.Execute(null);
                        break;
                    case CameraState.ConnectionOpened:
                        CloseConnHeadUpCommand.Execute(null);
                        break;
                }
            }

            ParamsService.LastExposureHeadUp = HeadUpModel.Exposure;
            ParamsService.LastNSaveFramesHeadUp = HeadUpModel.NFramesSaveCount;
            ParamsService.LastThreshold = HeadUpModel.Threshold;
            ParamsService.LastROITopHeadUp = HeadUpModel.ROITop;
            ParamsService.LastROIBottomHeadUp = HeadUpModel.ROIBottom;
            ParamsService.RefMillimetersHeadUp = HeadUpModel.RefMillimeters;
            ParamsService.MaxTubeLength = HeadUpModel.MaxGoodParam;
            ParamsService.MinTubeLength = HeadUpModel.MinGoodParam;
        }

        private void SaveSide1Parameters()
        {
            while(!(Side1Model.CurrentState <= CameraState.Offline))
            {
                switch (Side1Model.CurrentState)
                {
                    case CameraState.AcqStarted:
                        StopAcqSide1Command.Execute(null);
                        break;
                    case CameraState.ConnectionOpened:
                        CloseConnSide1Command.Execute(null);
                        break;
                }
            }

            ParamsService.LastExposureSide1 = Side1Model.Exposure;
            ParamsService.LastNSaveFramesSide1 = Side1Model.NFramesSaveCount;
            ParamsService.LastROITopSide1 = Side1Model.ROITop;
            ParamsService.LastROIBottomSide1 = Side1Model.ROIBottom;
            ParamsService.RefMillimetersSide1 = Side1Model.RefMillimeters;
            ParamsService.LastSide1Threshold = Side1Model.Threshold;
            ParamsService.LastAreaCalcThresholdSide1 = Side1Model.AreaCalcThreshold;
            ParamsService.LastAreaCalcCorrectionSide1 = Side1Model.AreaCalcCorrection;
            ParamsService.MinEllipseLenSide1 = Side1Model.MinEllipseLen;
            ParamsService.LastROILeftSide1 = Side1Model.ROILeft;
            ParamsService.LastROIRightSide1 = Side1Model.ROIRight;
            ParamsService.MinOuterDiamSide1 = Side1Model.MinGoodParam;
            ParamsService.MaxOuterDiamSide1 = Side1Model.MaxGoodParam;
            ParamsService.MinInnerDiamSide1 = Side1Model.MinInnerParam;
            ParamsService.MaxInnerDiamSide1 = Side1Model.MaxInnerParam;
        }

        private void SaveSide2Parameters()
        {
            while(!(Side2Model.CurrentState <= CameraState.Offline))
            {
                switch (Side2Model.CurrentState)
                {
                    case CameraState.AcqStarted:
                        StopAcqSide2Command.Execute(null);
                        break;
                    case CameraState.ConnectionOpened:
                        CloseConnSide2Command.Execute(null);
                        break;
                }
            }

            ParamsService.LastExposureSide2 = Side2Model.Exposure;
            ParamsService.LastNSaveFramesSide2 = Side2Model.NFramesSaveCount;
            ParamsService.LastROITopSide2 = Side2Model.ROITop;
            ParamsService.LastROIBottomSide2 = Side2Model.ROIBottom;
            ParamsService.RefMillimetersSide2 = Side2Model.RefMillimeters;
            ParamsService.LastSide2Threshold = Side2Model.Threshold;
            ParamsService.LastAreaCalcThresholdSide2 = Side2Model.AreaCalcThreshold;
            ParamsService.LastAreaCalcCorrectionSide2 = Side2Model.AreaCalcCorrection;
            ParamsService.MinEllipseLenSide2 = Side2Model.MinEllipseLen;
            ParamsService.LastROILeftSide2 = Side2Model.ROILeft;
            ParamsService.LastROIRightSide2 = Side2Model.ROIRight;
            ParamsService.MinOuterDiamSide2 = Side2Model.MinGoodParam;
            ParamsService.MaxOuterDiamSide2 = Side2Model.MaxGoodParam;
            ParamsService.MinInnerDiamSide2 = Side2Model.MinInnerParam;
            ParamsService.MaxInnerDiamSide2 = Side2Model.MaxInnerParam;
        }

        /// <summary>
        /// Команда: "Открыть окно ручного режима"
        /// </summary>
        public ICommand ActivateManualModeCommand =>
            _activateManualModeCommand ?? (_activateManualModeCommand = new RelayCommand<object>((o) =>
            {
                DialogService.SpawnManualWindow();
            }));

        /// <summary>
        /// Команда: "Открыть окно настроек"
        /// </summary>
        public ICommand ActivateSettingsCommand =>
            _activateSettingsCommand ?? (_activateSettingsCommand = new RelayCommand<object>((o) =>
            {
                DialogService.SpawnSettingsWindow();
            }));

        /// <summary>
        /// Команда открытия соединения с камерой сверху
        /// </summary>
        public ICommand OpenConnHeadUpCommand =>
            _openConnHeadUpCommand ?? (_openConnHeadUpCommand = new RelayCommand<object>((o) =>
            {
                HeadUpCamera = new GxSingleCam(CameraLocator.Factory, ErrorService, HeadUpModel.SelectedCamera);
                HeadUpCamera.FrameChanged += HeadUpFrameChanged;
                if (HeadUpCamera.OpenConnection()) HeadUpModel.CurrentState = CameraState.ConnectionOpened;
            }));

        /// <summary>
        /// Команда открытия соединения с камерой сбоку 1
        /// </summary>
        public ICommand OpenConnSide1Command =>
            _openConnSide1Command ?? (_openConnSide1Command = new RelayCommand<object>((o) =>
            {
                Side1Camera = new GxSingleCam(CameraLocator.Factory, ErrorService, Side1Model.SelectedCamera);
                Side1Camera.FrameChanged += Side1FrameChanged;
                if (Side1Camera.OpenConnection()) Side1Model.CurrentState = CameraState.ConnectionOpened;
            }));

        public ICommand OpenConnSide2Command =>
            _openConnSide2Command ?? (_openConnSide2Command = new RelayCommand<object>((o) =>
            {
                Side2Camera = new GxSingleCam(CameraLocator.Factory, ErrorService, Side2Model.SelectedCamera);
                Side2Camera.FrameChanged += Side2FrameChanged;
                if (Side2Camera.OpenConnection()) Side2Model.CurrentState = CameraState.ConnectionOpened;
            }));

        /// <summary>
        /// Команда запуска сбора кадров с камеры сверху
        /// </summary>
        public ICommand StartAcqHeadUpCommand =>
            _startAcqHeadUpCommand ?? (_startAcqHeadUpCommand = new RelayCommand<object>((o) =>
            {
                if (string.IsNullOrEmpty(HeadUpModel.ExposureString))
                {
                    ErrorService.Report("Неверный формат экспозиции камеры сверху.", ErrorNotifierService.E_LEVEL.Error);
                    return;
                }

                ParamsService.LastCameraSNHeadUp = HeadUpModel.SelectedCamera;
                if (HeadUpCamera.StartAcquisition(HeadUpModel.Exposure)) HeadUpModel.CurrentState = CameraState.AcqStarted;
            }));

        /// <summary>
        /// Команда запуска сбора кадров с камеры сбоку 1
        /// </summary>
        public ICommand StartAcqSide1Command =>
            _startAcqSide1Command ?? (_startAcqSide1Command = new RelayCommand<object>((o) =>
            {
                if (string.IsNullOrEmpty(Side1Model.ExposureString))
                {
                    ErrorService.Report("Неверный формат экспозиции камеры сбоку 1.", ErrorNotifierService.E_LEVEL.Error);
                    return;
                }

                ParamsService.LastCameraSNSide1 = Side1Model.SelectedCamera;
                if (Side1Camera.StartAcquisition(Side1Model.Exposure)) Side1Model.CurrentState = CameraState.AcqStarted;
            }));

        /// <summary>
        /// Команда запуска сбора кадров с камеры сбоку 2
        /// </summary>
        public ICommand StartAcqSide2Command =>
            _startAcqSide2Command ?? (_startAcqSide2Command = new RelayCommand<object>((o) =>
            {
                if (string.IsNullOrEmpty(Side2Model.ExposureString))
                {
                    ErrorService.Report("Неверный формат экспозиции камеры сбоку 2.", ErrorNotifierService.E_LEVEL.Error);
                    return;
                }

                ParamsService.LastCameraSNSide2 = Side2Model.SelectedCamera;
                if (Side2Camera.StartAcquisition(Side2Model.Exposure)) Side2Model.CurrentState = CameraState.AcqStarted;
            }));

        /// <summary>
        /// Команда остановки сбора кадров на камере сверху
        /// </summary>
        public ICommand StopAcqHeadUpCommand =>
            _stopAcqHeadUpCommand ?? (_stopAcqHeadUpCommand = new RelayCommand<object>((o) =>
            {
                if (HeadUpCamera.StopAcquisition()) HeadUpModel.CurrentState = CameraState.ConnectionOpened;
            }));

        /// <summary>
        /// Команда остановки сбора кадров на камере сбоку 1
        /// </summary>
        public ICommand StopAcqSide1Command =>
            _stopAcqSide1Command ?? (_stopAcqSide1Command = new RelayCommand<object>((o) =>
            {
                if (Side1Camera.StopAcquisition()) Side1Model.CurrentState = CameraState.ConnectionOpened;
            }));

        /// <summary>
        /// Команда остановки сбора кадров на камере сбоку 2
        /// </summary>
        public ICommand StopAcqSide2Command =>
            _stopAcqSide2Command ?? (_stopAcqSide2Command = new RelayCommand<object>((o) =>
            {
                if (Side2Camera.StopAcquisition()) Side2Model.CurrentState = CameraState.ConnectionOpened;
            }));

        /// <summary>
        /// Команда закрытия соединения с камерой сверху
        /// </summary>
        public ICommand CloseConnHeadUpCommand =>
            _closeConnHeadUpCommand ?? (_closeConnHeadUpCommand = new RelayCommand<object>((o) =>
            {
                if (HeadUpCamera.CloseConnection()) HeadUpModel.CurrentState = CameraState.Offline;
            }));

        /// <summary>
        /// Команда закрытия соединения с камерой сбоку 1
        /// </summary>
        public ICommand CloseConnSide1Command =>
            _closeConnSide1Command ?? (_closeConnSide1Command = new RelayCommand<object>((o) =>
            {
                if (Side1Camera.CloseConnection()) Side1Model.CurrentState = CameraState.Offline;
            }));

        /// <summary>
        /// Команда закрытия соединения с камерой сбоку 2
        /// </summary>
        public ICommand CloseConnSide2Command =>
            _closeConnSide2Command ?? (_closeConnSide2Command = new RelayCommand<object>((o) =>
            {
                if (Side2Camera.CloseConnection()) Side2Model.CurrentState = CameraState.Offline;
            }));

        /// <summary>
        /// Команда изменения времени экспозиции "на ходу" для камеры сверху
        /// </summary>
        public ICommand HeadUpExpTimeChangedCommand =>
            _headUpExpTimeChangedCommand ?? (_headUpExpTimeChangedCommand = new RelayCommand<object>((o) =>
            {
                if (HeadUpModel.CurrentState == CameraState.AcqStarted) HeadUpCamera.SetExpositionTime(HeadUpModel.Exposure);
            }));

        /// <summary>
        /// Команда изменения времени экспозиции "на ходу" для камеры сбоку 1
        /// </summary>
        public ICommand Side1ExpTimeChangedCommand =>
            _side1ExpTimeChangedCommand ?? (_side1ExpTimeChangedCommand = new RelayCommand<object>((o) =>
            {
                if (Side1Model.CurrentState == CameraState.AcqStarted) Side1Camera.SetExpositionTime(Side1Model.Exposure);
            }));

        /// <summary>
        /// Команда изменения времени экспозиции "на ходу" для камеры сбоку 2
        /// </summary>
        public ICommand Side2ExpTimeChangedCommand =>
            _side2ExpTimeChangedCommand ?? (_side2ExpTimeChangedCommand = new RelayCommand<object>((o) =>
            {
                if (Side2Model.CurrentState == CameraState.AcqStarted) Side2Camera.SetExpositionTime(Side2Model.Exposure);
            }));

        /// <summary>
        /// Команда сохранения одного кадра с камеры сверху
        /// </summary>
        public ICommand SaveFrameHeadUpCommand =>
            _saveFrameHeadUpCommand ?? (_saveFrameHeadUpCommand = new RelayCommand<object>((o) =>
            {
                HeadUpProcessingService.SaveToFile(string.Empty, "верх");
            }));

        /// <summary>
        /// Команда сохранения одного кадра с камеры сбоку 1
        /// </summary>
        public ICommand SaveFrameSide1Command =>
            _saveFrameSide1Command ?? (_saveFrameSide1Command = new RelayCommand<object>((o) =>
            {
                Side1ProcessingService.SaveToFile(string.Empty, "право");
            }));

        /// <summary>
        /// Команда сохранения одного кадра с камеры сбоку 2
        /// </summary>
        public ICommand SaveFrameSide2Command =>
            _saveFrameSide2Command ?? (_saveFrameSide2Command = new RelayCommand<object>((o) =>
            {
                Side2ProcessingService.SaveToFile(string.Empty, "лево");
            }));

        /// <summary>
        /// Команда загрузки кадра для камеры сверху из файла
        /// </summary>
        public ICommand LoadFileHeadUpFrameCommand =>
            _loadFileHeadUpFrameCommand ?? (_loadFileHeadUpFrameCommand = new RelayCommand<object>((o) =>
           {
               var filename = DialogService.SpawnOpenFileDialog("Открыть кадр", new List<string>() { "*.bmp" });

               if(!string.IsNullOrEmpty(filename))
               {
                   HeadUpProcessingService.LoadFromFile(filename);
                   FillHeadUpFrameSource();
               }
           }));

        public ICommand LoadFileSide1FrameCommand =>
            _loadFileSide1FrameCommand ?? (_loadFileSide1FrameCommand = new RelayCommand<object>((o) =>
            {
                var filename = DialogService.SpawnOpenFileDialog("Открыть кадр", new List<string>() { "*.bmp" });

                if(!string.IsNullOrEmpty(filename))
                {
                    Side1ProcessingService.LoadFromFile(filename);
                    FillSide1FrameSource();
                }
            }));

        public ICommand LoadFileSide2FrameCommand =>
            _loadFileSide2FrameCommand ?? (_loadFileSide2FrameCommand = new RelayCommand<object>((o) =>
            {
                var filename = DialogService.SpawnOpenFileDialog("Открыть кадр", new List<string>() { "*.bmp" });

                if(!string.IsNullOrEmpty(filename))
                {
                    Side2ProcessingService.LoadFromFile(filename);
                    FillSide2FrameSource();
                }
            }));
    }
}