﻿using FiringCSWin.Helpers;
using FiringCSWin.Models;
using FiringCSWin.ViewModels;
using System.Windows;

namespace FiringCSWin.Views
{
    /// <summary>
    /// Логика взаимодействия для ManualModeWindow.xaml
    /// </summary>
    public partial class ManualModeWindow : Window
    {
        public ManualModeWindow()
        {
            InitializeComponent();

            // получение служб приложения
            var app = (App)Application.Current;
            var paramService = app.ParametersService;
            var errorService = app.ErrorService;
            var dialogService = app.DialogService;
            var commService = app.CommService;
            var alarmService = app.AlarmService;
            var sensorsModel = app.SensorsModel;
            var axisModels = app.AxisModels;
            var valvesModel = app.ValvesModel;
            var casetteAlgModel = app.CasetteAlgModel;
            var removerModels = app.RemoverModels;

            // создание и подключение модели представления к окну
            DataContext = new ManualModeViewModel(paramService, commService, errorService, dialogService,
                sensorsModel, axisModels, valvesModel, casetteAlgModel, alarmService, removerModels);
        }
    }
}