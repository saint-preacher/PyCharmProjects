﻿using System.Windows;

namespace FiringCSWin.Views
{
    /// <summary>
    /// Логика взаимодействия для InputCalcWindow.xaml
    /// </summary>
    public partial class InputCalcWindow : Window
    {
        public InputCalcWindow()
        {
            InitializeComponent();
        }
    }
}