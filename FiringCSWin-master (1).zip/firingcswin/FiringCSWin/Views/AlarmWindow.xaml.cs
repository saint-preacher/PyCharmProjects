﻿using System.Windows;

namespace FiringCSWin.Views
{
    /// <summary>
    /// Логика взаимодействия для AlarmWindow.xaml
    /// </summary>
    public partial class AlarmWindow : Window
    {
        public AlarmWindow()
        {
            InitializeComponent();
        }
    }
}