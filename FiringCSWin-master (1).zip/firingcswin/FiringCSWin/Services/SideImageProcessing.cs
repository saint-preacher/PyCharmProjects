﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Media;
using FiringCSWin.BaseServices;
using OpenCvSharp;

namespace FiringCSWin.Services
{
    public interface ISideImageProcessing : IImageProcessingService
    {
        /// <summary>
        /// Расчёт диаметров 
        /// </summary>
        /// <param name="threshold">Величина порога</param>
        /// <param name="roiTop">Верхний предел интереса</param>
        /// <param name="roiBottom">Нижний предел интереса</param>
        /// <param name="roiLeft">Левый предел интереса</param>
        /// <param name="roiRight">Правый предел интереса</param>
        /// <param name="areaCalcThreshold">Порог расчёта площади</param>
        /// <param name="areaCalcCorrection">Коррекция расчёта площади</param>
        /// <param name="minEllipseLen">Минимальная длина контура эллипса</param>
        /// <param name="diams">Внешние диаметры посчитанные</param>
        /// <param name="thicks">Внутренние диаметры посчитанные</param>
        ImageSource CalculateDiameters(double threshold, int roiTop, int roiBottom, int roiLeft, int roiRight,
            double areaCalcThreshold, double areaCalcCorrection, int minEllipseLen, out List<double> diams, out List<double> thicks);

        /// <summary>
        /// Вычисляет диаметры (внешний и внутренний) через аппроксимацию прямыми линиями по бинаризованному изображению
        /// </summary>
        /// <param name="centerPoint">Точка центра трубки, полученная на шаге 1</param>
        /// <param name="thickness">Рассчитанная толщина стенки (средняя)</param>
        /// <param name="outDiam">Рассчитанный внешний диаметр</param>
        /// <param name="thickDeviation">Стандартное отклонение по толщинам стенок</param>
        /// <param name="outDeviation">Стандартное отклонение по внешним диаметрам</param>
        /// <param name="lrDeviation">Эллипсность по внутреннему диаметру (среднеквадратическое отклонение одной стенки от другой)</param>
        /// <param name="LRDeviationList">Разницы между правой и левой стенок(px)</param>
        /// <param name="areaCalcThreshold">Порог для расчёта площади</param>
        void CalcDiamByLinesApprox(Point2f centerPoint, out double thickness, out double outDiam, out double thickDeviation, out double outDeviation, out double lrDeviation, out List<double> LRDeviationList, double areaCalcThreshold);

        /// <summary>
        /// Вычисляет диаметры (внешний и внутренний) через площадь бинаризованного изображения
        /// </summary>
        /// <param name="centerPoint">Точка центра трубки, полученная на шаге 1</param>
        /// <param name="thickness">Рассчитанная толщина стенки</param>
        /// <param name="outDiam">Рассчитанный внешний диаметр</param>
        /// <param name="areaCalcThreshold">Порог для расчёта площади</param>
        /// <param name="areaCalcCorrection">Добавка для расчёта площади</param>
        void CalcDiamByArea(Point2f centerPoint, out double thickness, out double outDiam, double areaCalcThreshold, double areaCalcCorrection);

        /// <summary>
        /// Поиск эллипсов на изображении
        /// </summary>
        /// <param name="threshold">Порог бинаризации</param>
        /// <param name="thickness">Полученная толщина стенки</param>
        /// <param name="outDiam">Полученный внешний диаметр трубки</param>
        /// <param name="innEllipse">Величина рассчитанной эллипсности внутренного диаметра</param>
        /// <param name="outEllipse">Величина рассчитанной эллипсности внешнего диаметра</param>
        /// <param name="center">Центральная точка полученная на этом этапе</param>
        /// <param name="areaCalcThreshold">Порог для расчёта площади</param>
        /// <param name="ellipseMinLenOfContour">Минимальная длина контура эллипса</param>
        void DetectEllipses(double threshold, out double thickness, out double outDiam, out double innEllipse, out double outEllipse, out Point2f center, double areaCalcThreshold, int ellipseMinLenOfContour);
    }

    public class SideImageProcessing : ImageProcessingService, ISideImageProcessing
    {
        public SideImageProcessing(IFileSystemProvider fsProvider) : base(fsProvider){}        

        public ImageSource CalculateDiameters(double threshold, int roiTop, int roiBottom, int roiLeft, int roiRight,
            double areaCalcThreshold, double areaCalcCorrection, int minEllipseLen, out List<double> diams, out List<double> thicks)
        {
            var timer = new Stopwatch();
            timer.Start();

            double Thick1, OutDiam1, Thick2, OutDiam2, Thick3, OutDiam3, InnEllipse, OutEllipse, LRDeviation, Thick2Dev, OutDiam2Dev;
            Point2f CenterPoint;

            thicks = new List<double>();
            diams = new List<double>();

            // STAGE 1: Canny обнаружение краёв и вписание эллипса
            DetectEllipses(threshold, out Thick1, out OutDiam1, out InnEllipse, out OutEllipse, out CenterPoint, areaCalcThreshold, minEllipseLen);

            if ((CenterPoint.X < Layer0.Width) && (CenterPoint.Y < Layer0.Height) && (CenterPoint.X > 0) && (CenterPoint.Y > 0))
            {
                // STAGE 2: Расчёт по прямым линиям наложенным на бинаризованное изображение
                CalcDiamByLinesApprox(CenterPoint, out Thick2, out OutDiam2, out Thick2Dev, out OutDiam2Dev, out LRDeviation, out var DevsList, areaCalcThreshold);

                // STAGE 3: Вычисление диаметра исходя из площади белых пикселей на бинаризованном изображении
                CalcDiamByArea(CenterPoint, out Thick3, out OutDiam3, areaCalcThreshold, areaCalcCorrection);
                
                FilterResults(Thick1, OutDiam1, Thick2, OutDiam2, Thick3, OutDiam3, thicks, diams);

                // нарисовать средний результат сверху кадра
                var meanDiam = diams.Average();
                var meanThick = thicks.Average();
                Cv2.PutText(Layer0, meanDiam.ToString("F2"), new Point(0, 0), HersheyFonts.HersheyPlain, 12.0, Scalar.Blue);
                Cv2.PutText(Layer0, meanThick.ToString("F2"), new Point(0, 100), HersheyFonts.HersheyPlain, 12.0, Scalar.Blue);
            }

            timer.Stop();
            Debug.WriteLine($"CalculateDiameters elapsed time {timer.ElapsedMilliseconds}ms");

            return PrepareSource(Layer0, (roiTop, roiBottom), (roiLeft, roiRight), true);
        }

        public void CalcDiamByLinesApprox(Point2f centerPoint, out double thickness, out double outDiam, out double thickDeviation, out double outDeviation, out double lrDeviation, out List<double> LRDeviationList, double areaCalcThreshold)
        {
            var watch = new Stopwatch();
            watch.Start();

            var temp = new Mat();
            Layer0.CopyTo(temp);

            Cv2.GaussianBlur(temp, temp, new Size(3.0, 3.0), 3.0, 3.0);
            Cv2.Threshold(temp, temp, areaCalcThreshold, 255.0, ThresholdTypes.Binary);

            thickness = -1.0;
            outDiam = -1.0;

            var xs = new double[] { centerPoint.X, centerPoint.X - centerPoint.Y + temp.Size().Height, temp.Size().Width, centerPoint.X + centerPoint.Y };
            var ys = new double[] { temp.Size().Height, temp.Size().Height, centerPoint.Y, 0.0 };
            var xe = new double[] { centerPoint.X, centerPoint.X - centerPoint.Y, 0.0, centerPoint.X + centerPoint.Y - temp.Size().Height };
            var ye = new double[] { 0.0, 0.0, centerPoint.Y, temp.Size().Height };

            var Thicknesses = new List<double>();
            var OutDiams = new List<double>();
            LRDeviationList = new List<double>();

            // рисуем 4 прямые, проходящие через центр по которым будем считать
            for (int i = 0; i < 4; i++)
            {
                var p1 = new Point(xs[i], ys[i]);
                var p2 = new Point(xe[i], ye[i]);

                var it = new LineIterator(temp, p1, p2);
                var DotsList = new List<Point>();
                byte PrevVal = 255;
                var PrevCount = 0;

                foreach (var pixel in it)
                {
                    var intensity = pixel.GetValue<byte>();
                    if (PrevVal != intensity)
                    {
                        if ((PrevCount < 20) && (DotsList.Count > 0))
                        {
                            DotsList.RemoveAt(DotsList.Count - 1);
                        }
                        else PrevCount = 0;
                        DotsList.Add(pixel.Pos);
                        Cv2.Circle(Layer0, pixel.Pos, 25, new Scalar(0, 255.0, 0), 3);
                    }

                    PrevCount++;
                    PrevVal = intensity;
                }

                if (DotsList.Count == 4)
                {
                    var firstPoint = DotsList[0];
                    var lastPoint = DotsList[3];
                    var dist = GetDist(firstPoint, lastPoint);
                    OutDiams.Add(dist);
                    var left = GetDist(firstPoint, DotsList[1]);
                    Thicknesses.Add(left);
                    var right = GetDist(DotsList[2], lastPoint);
                    Thicknesses.Add(right);
                    LRDeviationList.Add(left - right);
                }

                Cv2.Line(Layer0, p1, p2, new Scalar(0, 0, 255), 5);
            }

            // вычисляем среднее квадратическое отклонение
            thickDeviation = GetStdDeviation(Thicknesses);
            outDeviation = GetStdDeviation(OutDiams);

            thickness = (Thicknesses.Count > 0) ? Thicknesses.Average() : 0.0;
            outDiam = (OutDiams.Count > 0) ? OutDiams.Average() : 0.0;

            lrDeviation = GetStdDeviation(LRDeviationList);

            watch.Stop();
            Debug.WriteLine($"CalcDiamByLinesApprox : {watch.ElapsedMilliseconds}ms");
        }

        public void CalcDiamByArea(Point2f centerPoint, out double thickness, out double outDiam, double areaCalcThreshold, double areaCalcCorrection)
        {
            var watch = new Stopwatch();
            watch.Start();

            var temp = new Mat();
            Cv2.CvtColor(Layer0, temp, ColorConversionCodes.RGB2GRAY);

            Cv2.Threshold(temp, temp, areaCalcThreshold, 255.0, ThresholdTypes.Binary);

            var labels = new Mat();
            var stats = new Mat();
            var centroids = new Mat();

            // подсчёт площади белого поля вокруг центральной точки
            var nccomps = Cv2.ConnectedComponentsWithStats(temp, labels, stats, centroids);

            thickness = -1.0;
            outDiam = -1.0;
            var innDiam = -1.0;

            int TheMostArea = 0;

            for (int i = 0; i < nccomps; i++)
            {
                var S = stats.At<int>(i, (int)ConnectedComponentsTypes.Area);
                if (S < 10000) continue;
                var tiic = (labels.At<int>((int)centerPoint.Y, (int)centerPoint.X) == i);
                var d = Math.Sqrt(4 * S / Math.PI) + areaCalcCorrection;
                if (tiic)
                {
                    innDiam = d;
                }
                if (S > TheMostArea) TheMostArea = S;
            }

            if (TheMostArea > 10000)
            {
                var size = temp.Size();
                var S = size.Height * size.Width - TheMostArea;
                outDiam = Math.Sqrt(4 * S / Math.PI) + areaCalcCorrection;
            }

            if ((outDiam > 0) && (innDiam > 0)) thickness = (outDiam - innDiam) / 2.0;

            watch.Stop();
            Debug.WriteLine($"CalcDiamByArea : {watch.ElapsedMilliseconds}ms");
        }

        public void DetectEllipses(double threshold, out double thickness, out double outDiam, out double innEllipse, out double outEllipse, out Point2f center, double areaCalcThreshold, int ellipseMinLenOfContour)
        {
            var watch = new Stopwatch();
            watch.Start();

            var tempOut = new Mat();
            Layer0.CopyTo(tempOut);

            Cv2.GaussianBlur(tempOut, tempOut, new Size(3.0, 3.0), 3.0, 3.0);

            Cv2.Threshold(tempOut, tempOut, areaCalcThreshold, 255.0, ThresholdTypes.Binary);

            Mat cannyOut = new Mat();
            Cv2.Canny(tempOut, cannyOut, threshold, threshold * 2, 3, true);

            Cv2.FindContours(cannyOut, out Point[][] contours, out HierarchyIndex[] hierarchy, RetrievalModes.Tree, ContourApproximationModes.ApproxSimple);

            var minRect = new List<RotatedRect>();
            var minEllipse = new List<RotatedRect>();
            var parents = new List<int>();
            for (int i = 0; i < contours.Length; i++)
            {
                if ((contours[i].Length > ellipseMinLenOfContour) && !parents.Contains(hierarchy[i].Parent))
                {
                    minEllipse.Add(Cv2.FitEllipse(contours[i]));
                    parents.Add(i);
                }
            }

            center = new Point2f(0.0f, 0.0f);
            foreach (RotatedRect ellipse in minEllipse)
            {
                Cv2.Ellipse(Layer0, ellipse, new Scalar(255.0, 0.0, 0.0), 3);

                center += ellipse.Center;
            }
            if (minEllipse.Count > 0) center = new Point2f(center.X / minEllipse.Count, center.Y / minEllipse.Count);

            if (minEllipse.Count == 2)
            {
                var abs = minEllipse[0].Size.Height - minEllipse[1].Size.Height;
                if (abs > 0)
                {
                    outDiam = minEllipse[0].Size.Height;
                    var innDiam = minEllipse[1].Size.Height;
                    thickness = (outDiam - innDiam) / 2.0;
                    innEllipse = 100.0 * (minEllipse[1].Size.Height / minEllipse[1].Size.Width);
                    if (innEllipse > 100.0) innEllipse = 1.0 / innEllipse;
                    outEllipse = 100.0 * (minEllipse[0].Size.Height / minEllipse[0].Size.Width);
                    if (outEllipse > 100.0) outEllipse = 1.0 / outEllipse;
                }
                else
                {
                    var innDiam = minEllipse[0].Size.Height;
                    outDiam = minEllipse[1].Size.Height;
                    thickness = (outDiam - innDiam) / 2.0;
                    innEllipse = 100.0 * (minEllipse[0].Size.Height / minEllipse[0].Size.Width);
                    if (innEllipse > 100.0) innEllipse = 1.0 / innEllipse;
                    outEllipse = 100.0 * (minEllipse[1].Size.Height / minEllipse[1].Size.Width);
                    if (outEllipse > 100.0) outEllipse = 1.0 / outEllipse;
                }
            }
            else
            {
                outDiam = -1.0;
                thickness = -1.0;
                innEllipse = 100.0;
                outEllipse = 100.0;
            }

            watch.Stop();
            Debug.WriteLine($"DetectEllipses : {watch.ElapsedMilliseconds}ms");
        }
    }
}
