﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FiringCSWin.BaseServices;
using GxIAPINET;

namespace FiringCSWin.Services
{
    public interface IGxCamLocator
    {
        void Deinit();
        List<string> GetDeviceList();
        IGXFactory Factory { get; }
    }

    public class GxCamLocator : IGxCamLocator
    {
        public IGXFactory Factory { get; protected set; }
        IErrorService ErrorService;

        public GxCamLocator(IErrorService errorService) {
            ErrorService = errorService;
            Factory = IGXFactory.GetInstance();
            Factory.Init();
        }

        public void Deinit()
        {
            Factory.Uninit();
        }

        /// <summary>
        /// Получить список камер
        /// </summary>
        public List<string> GetDeviceList()
        {
            var resultList = new List<string>();
            var listGXDeviceInfo = new List<IGXDeviceInfo>();
            Factory.UpdateDeviceList(200, listGXDeviceInfo);

            // Если не найдено камер
            if (listGXDeviceInfo.Count <= 0)
            {
                ErrorService.Report("Не найдено ниодной камеры!", ErrorNotifierService.E_LEVEL.Warning);                
            }

            foreach(var device in listGXDeviceInfo)
            {
                resultList.Add(device.GetSN());
            }

            return resultList;
        }
    }
}
