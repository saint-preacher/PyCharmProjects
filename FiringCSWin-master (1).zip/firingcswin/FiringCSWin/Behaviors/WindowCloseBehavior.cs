﻿using Microsoft.Xaml.Behaviors;
using System.Windows;

namespace FiringCSWin.Behaviors
{
    public class WindowCloseBehavior : Behavior<Window>
    {
        private static readonly DependencyProperty CloseTriggerProperty = DependencyProperty.Register(
                "CloseTrigger",
                typeof(bool),
                typeof(WindowCloseBehavior),
                new PropertyMetadata(false, CloseTriggerChanged)
            );

        public bool CloseTrigger
        {
            get { return (bool)GetValue(CloseTriggerProperty); }
            set { SetValue(CloseTriggerProperty, value); }
        }

        private static void CloseTriggerChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var beh = d as WindowCloseBehavior;
            var nv = (bool)e.NewValue;

            if (nv) beh.AssociatedObject.Close();
        }
    }
}