﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FiringCSWin.Converters.Tests
{
    [TestClass()]
    public class BoolToTextBoxBackgroundConverterTests
    {
        private BoolToTextBoxBackgroundConverter TestingConverter = new BoolToTextBoxBackgroundConverter();

        [TestInitialize()]
        public void BeforeEachTest()
        {
            TestingConverter.TrueBrush = System.Windows.Media.Brushes.Green;
            TestingConverter.FalseBrush = System.Windows.Media.Brushes.Red;
        }

        [TestMethod()]
        public void ConvertTest()
        {
            var converterResult = (System.Windows.Media.Brush)TestingConverter.Convert(
                false,
                typeof(System.Windows.Media.Brush),
                null,
                System.Globalization.CultureInfo.CurrentUICulture
            );
            Assert.AreEqual(System.Windows.Media.Brushes.Red, converterResult);

            converterResult = (System.Windows.Media.Brush)TestingConverter.Convert(
                true,
                typeof(System.Windows.Media.Brush),
                null,
                System.Globalization.CultureInfo.CurrentUICulture
            );
            Assert.AreEqual(System.Windows.Media.Brushes.Green, converterResult);
        }

        [TestMethod()]
        public void ConvertBackTest()
        {
            Assert.IsTrue(TestingConverter.ConvertBack(
                System.Windows.Media.Brushes.Green,
                typeof(bool),
                null,
                System.Globalization.CultureInfo.CurrentUICulture) == null);
        }
    }
}