﻿using FiringCSWin.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Threading;

namespace FiringCSWin.Services.Tests
{
    [TestClass()]
    public class CommProtocolTests
    {
        [TestMethod()]
        public void GetStatusCommandTest() => Assert.AreEqual("GS\n", CommProtocol.GetStatus());

        [TestMethod()]
        public void SetTranSpeedCommandTest() => Assert.AreEqual("STS:5000\n", CommProtocol.SetTranSpeed(5000));

        [TestMethod()]
        public void SetCasetteStepsCommandTest() => Assert.AreEqual("SSC:100\n", CommProtocol.SetCasetteSteps(100));

        [TestMethod()]
        public void SetCasetteDownSpeedCommandTest() => Assert.AreEqual("SCD:300\n", CommProtocol.SetCasetteDownSpeed(300));

        [TestMethod()]
        public void SetDiscSpeedCommandTest() => Assert.AreEqual("SDS:6000\n", CommProtocol.SetDiscSpeed(6000));

        [TestMethod()]
        public void SetPneumoDelayCommandTest() => Assert.AreEqual("SDD:2000\n", CommProtocol.SetPneumoDelay(2000));

        [TestMethod()]
        public void SetRowCountCommandTest() => Assert.AreEqual("SRC:150\n", CommProtocol.SetRowCount(150));

        [TestMethod()]
        public void MoveCasetteByStepsTest() => Assert.AreEqual("DCP:10\n", CommProtocol.MoveCasetteBySteps(10));

        [TestMethod()]
        public void SetTransporterAccelTest() => Assert.AreEqual("STA:2500\n", CommProtocol.SetTransporterAccel(2500));

        [TestMethod()]
        public void SetTransporterDecelTest() => Assert.AreEqual("STD:2500\n", CommProtocol.SetTransporterDecel(2500));

        [TestMethod()]
        public void SetDiscAccelTest() => Assert.AreEqual("SRA:1000\n", CommProtocol.SetDiscAccel(1000));

        [TestMethod()]
        public void SetDiscDecelTest() => Assert.AreEqual("SRD:2500\n", CommProtocol.SetDiscDecel(2500));

        [TestMethod()]
        public void SetCasetteAccelTest() => Assert.AreEqual("SCSA:0\n", CommProtocol.SetCasetteAccel(0));

        [TestMethod()]
        public void SetCasetteDecelTest() => Assert.AreEqual("SCSD:0\n", CommProtocol.SetCasetteDecel(0));

        [TestMethod()]
        public void SetCasetteUpSpeedCommandTest() => Assert.AreEqual("SCTS:1000\n", CommProtocol.SetCasetteUpSpeed(1000));

        [TestMethod()]
        public void StartRowMoveCommandTest() => Assert.AreEqual("CARM:500\n", CommProtocol.StartCasettingRowMove(500));

        [TestMethod()]
        public void StartPushInCommandTest() => Assert.AreEqual("CAPI:1111\n", CommProtocol.StartCasettingPushIn(1111));

        [TestMethod()]
        public void StartNextRowCommandTest() => Assert.AreEqual("CANR:586\n", CommProtocol.StartCasettingNextRow(586));

        [TestMethod()]
        public void StartChangeCasetteTest() => Assert.AreEqual("CACC:279\n", CommProtocol.StartCasettingChange(279));

        [TestMethod()]
        public void PropertiesTest()
        {
            Assert.AreEqual("SVI:1\n", CommProtocol.EnablePneumo1);
            Assert.AreEqual("SVI:0\n", CommProtocol.DisablePneumo1);
            Assert.AreEqual("SVII:1\n", CommProtocol.EnablePneumo2);
            Assert.AreEqual("SVII:0\n", CommProtocol.DisablePneumo2);
            Assert.AreEqual("SVIII:1\n", CommProtocol.EnablePneumo3);
            Assert.AreEqual("SVIII:0\n", CommProtocol.DisablePneumo3);
            Assert.AreEqual("SIV:1\n", CommProtocol.EnablePneumo4);
            Assert.AreEqual("SIV:0\n", CommProtocol.DisablePneumo4);
            Assert.AreEqual("SV:1\n", CommProtocol.EnablePneumo5);
            Assert.AreEqual("SV:0\n", CommProtocol.DisablePneumo5);

            Assert.AreEqual("DTR:1\n", CommProtocol.StartTransporter);
            Assert.AreEqual("DTR:0\n", CommProtocol.StopTransporter);
            Assert.AreEqual("DDI:1\n", CommProtocol.StartDisc);
            Assert.AreEqual("DDI:0\n", CommProtocol.StopDisc);
            Assert.AreEqual("DCA:1\n", CommProtocol.StartCasette);
            Assert.AreEqual("DCA:0\n", CommProtocol.StopCasette);

            Assert.AreEqual("DCD:0\n", CommProtocol.CasetteDirectionDown);
            Assert.AreEqual("DCD:1\n", CommProtocol.CasetteDirectionUp);

            Assert.AreEqual("CAST:0\n", CommProtocol.DisableAutoCasetting);
            Assert.AreEqual("CAST:1\n", CommProtocol.EnableAutoCasetting);
        }

        [TestMethod()]
        public void ParseStatusAnswerTest()
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());

            var AnswersDict = new Dictionary<string, SensorsModel>()
            {
                { "S:341 TS:3838 FSC:1000 CRC:2 SC:900 CD:1234 DS:4500 DD:2222 RC:158 BPI:500 CP:4000000000 AL:0",
                    new SensorsModel(){
                        RowSensor = true,
                        TubeSensor = false,
                        Valve1Sensor = true,
                        Valve2Sensor = false,
                        Valve3Sensor = true,
                        Valve4Sensor = false,
                        Valve5Sensor = true,
                        CasetteReversing = false,
                        RowLimit = true,
                        PushLimit = false,
                        AutomaticCasetting = false,
                        ReservedLimit = false,
                        FullCasette = false,
                        CasetteTopLimit = false,
                        CasetteBottomLimit = false,
                        EmptyCasette = false,
                        CurrentTransporterSpeed = 3838,
                        CasetteStepsPerRow = 900,
                        CasetteFirstStepsPerRow = 1000,
                        CurrentRowCount = 2,
                        CurrentCasetteSpeed = 1234,
                        CurrentDiscSpeed = 4500,
                        PushIntoCasetteDelay = 2222,
                        RowCount = 158,
                        BeforePushIntoCasetteDelay = 500,
                        CasettePosition = 4000000000,
                        AlarmCode = 0
                    }
                },

                { "S:0 TS:65535 FSC:65535 CRC:65535 SC:65535 CD:65535 DS:65535 DD:65535 RC:65535 BPI:65535 CP:4294967295 AL:100",
                    new SensorsModel(){
                        RowSensor = false,
                        TubeSensor = false,
                        Valve1Sensor = false,
                        Valve2Sensor = false,
                        Valve3Sensor = false,
                        Valve4Sensor = false,
                        Valve5Sensor = false,
                        CasetteReversing = false,
                        RowLimit = false,
                        PushLimit = false,
                        AutomaticCasetting = false,
                        ReservedLimit = false,
                        FullCasette = false,
                        CasetteTopLimit = false,
                        CasetteBottomLimit = false,
                        EmptyCasette = false,
                        CurrentTransporterSpeed = ushort.MaxValue,
                        CasetteStepsPerRow = ushort.MaxValue,
                        CasetteFirstStepsPerRow = ushort.MaxValue,
                        CurrentRowCount = ushort.MaxValue,
                        CurrentCasetteSpeed = ushort.MaxValue,
                        CurrentDiscSpeed = ushort.MaxValue,
                        PushIntoCasetteDelay = ushort.MaxValue,
                        RowCount = ushort.MaxValue,
                        BeforePushIntoCasetteDelay = ushort.MaxValue,
                        CasettePosition = uint.MaxValue,
                        AlarmCode = 100
                    }
                },

                { "S:65535 TS:5000 FSC:333 CRC:10 SC:200 CD:300 DS:6000 DD:2000 RC:150 BPI:200 CP:0 AL:200",
                    new SensorsModel(){
                        RowSensor = true,
                        TubeSensor = true,
                        Valve1Sensor = true,
                        Valve2Sensor = true,
                        Valve3Sensor = true,
                        Valve4Sensor = true,
                        Valve5Sensor = true,
                        CasetteReversing = true,
                        RowLimit = true,
                        PushLimit = true,
                        AutomaticCasetting = true,
                        ReservedLimit = true,
                        FullCasette = true,
                        CasetteTopLimit = true,
                        CasetteBottomLimit = true,
                        EmptyCasette = true,
                        CurrentTransporterSpeed = 5000,
                        CasetteStepsPerRow = 200,
                        CasetteFirstStepsPerRow = 333,
                        CurrentRowCount = 10,
                        CurrentCasetteSpeed = 300,
                        CurrentDiscSpeed = 6000,
                        PushIntoCasetteDelay = 2000,
                        RowCount = 150,
                        BeforePushIntoCasetteDelay = 200,
                        CasettePosition = 0,
                        AlarmCode = 200
                    }
                }
            };

            foreach (var pair in AnswersDict)
            {
                var data = new SensorsModel();
                CommProtocol.ParseStatusAnswer(pair.Key, data);
                Assert.AreEqual(pair.Value, data);
            }

            var ArgExceptionAnswer = "S:3 fdfji 2-3 23- 24";
            var possiblyBadData = new SensorsModel();
            Assert.ThrowsException<ArgumentException>(() => CommProtocol.ParseStatusAnswer(ArgExceptionAnswer, possiblyBadData));

            var ArgExceptionAnswerTooFewAtoms = "S:0 TS:1 SC:2 CD:3:4 DS:5 DD:0 RC:0 CP:4294967295";
            Assert.ThrowsException<ArgumentException>(() => CommProtocol.ParseStatusAnswer(ArgExceptionAnswerTooFewAtoms, possiblyBadData));
        }
    }
}