﻿using FiringCSWin.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Moq;
using OpenCvSharp;
using FiringCSWin.BaseServices;
using System.Collections.Generic;

namespace FiringCSWin.Services.Tests
{
    [TestClass()]
    public class SideImageProcessingTests
    {
        Mock<IFileSystemProvider> fsProvider = new Mock<IFileSystemProvider>();

        [TestMethod()]
        public void GetRectIntersectPointTest()
        {
            var testObject = new SideImageProcessing(fsProvider.Object);

            var angles = new double[] { 0.0, 23.5, 45.0, 90.0, 148.3, 180.0, 220.0, 270.0, 300.0, 359.9 };
            var table = new (Rect, Point[])[]
            {
               ( new Rect(150, 110, 100, 80),
                    new Point[]{ new Point(250, 150), new Point(250, 128.259), new Point(240, 110), new Point(200, 110), new Point(150, 119.119),
                    new Point(150, 150), new Point(152.33, 190), new Point(200, 190), new Point(223.094, 190), new Point(250, 150.087) } )
            };

            foreach (var tableitem in table)
            {
                for (int i = 0; i < 10; i++)
                {
                    var critAngle = testObject.GetCriticalAngle(tableitem.Item1);
                    var expected = tableitem.Item2[i];
                    var actual = testObject.GetRectIntersectPoint(angles[i], critAngle, tableitem.Item1);
                    Assert.AreEqual(expected, actual);
                }
            }
        }

        [TestMethod()]
        public void GetCriticalAngleTest()
        {
            var testObject = new SideImageProcessing(fsProvider.Object);

            var testArray = new Dictionary<Rect, double>
            {
                { new Rect(150, 110, 100, 80), 38.659808 },
                { new Rect(0, 0, 50, 50), 45.0 },
                { new Rect(67, 203, 432, 432), 45.0 }
            };

            foreach (var test in testArray) Assert.AreEqual(test.Value, testObject.GetCriticalAngle(test.Key), 0.001);
        }
    }
}