﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FiringCSWin.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using FiringCSWin.BaseServices;

namespace FiringCSWin.Services.Tests
{
    [TestClass()]
    public class ImageProcessingServiceTests
    {
        [TestMethod()]
        public void MergeSortTest()
        {
            var inputArr = new (int, int, int, int)[] { (0, 5, 0, 6), (1, 4, 0, 5), (2, 2, 0, 3), (3, 0, 0, 1), (4, 7, 0, 8), (5, 6, 0, 7), (6, 1, 0, 2), (7, 3, 0, 4) };
            var mustbArr = new (int, int, int, int)[] { (3, 0, 0, 1), (6, 1, 0, 2), (2, 2, 0, 3), (7, 3, 0, 4), (1, 4, 0, 5), (0, 5, 0, 6), (5, 6, 0, 7), (4, 7, 0, 8) };
            var fsMock = new Mock<IFileSystemProvider>();

            var imgProcessingObject = new ImageProcessingService(fsMock.Object);
            var actual = imgProcessingObject.MergeSort(inputArr, 0, inputArr.Length);

            CollectionAssert.AreEqual(mustbArr, actual);
        }
    }
}