﻿using System.Windows;

namespace FiringCSWin.Views
{
    /// <summary>
    /// Логика взаимодействия для SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();
            DataContext = new ViewModels.SettingsViewModel(((App)Application.Current).ParametersService);
        }
    }
}