﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace FiringCSWin.Converters
{
    /// <summary>
    /// Конвертер между значениями типа bool и Brush.
    /// Истина соответствует зелёному цвету кисти, а
    /// ложь красному.
    /// </summary>
    public class BoolToTextBoxBackgroundConverter : IValueConverter
    {
        /// <summary>
        /// Кисть в случае истины
        /// </summary>
        public Brush TrueBrush { get; set; } = Brushes.Green;

        /// <summary>
        /// Кисть в случае лжи
        /// </summary>
        public Brush FalseBrush { get; set; } = Brushes.Red;

        // bool -> Brush
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool condition = (bool)value;
            return condition ? TrueBrush : FalseBrush;
        }

        // обратное преобразование не предусмотрено
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}