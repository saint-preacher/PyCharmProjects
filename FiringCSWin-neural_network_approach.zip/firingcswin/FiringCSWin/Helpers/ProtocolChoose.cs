﻿using FiringCSWin.Models;
using FiringCSWin.Services;

namespace FiringCSWin.Helpers
{
    public static class ProtocolChoose
    {
        /// <summary>
        /// Процедура выбора протокола для связи с платой.
        /// Используется для подключения протокола CommProtocol
        /// к объектам модели.
        /// </summary>
        /// <param name="axisModels">Модели "осей" шаговых двигателей</param>
        /// <param name="sensorsModel">Модель датчиков</param>
        /// <param name="valvesModel">Модель клапанов и исполнительных устройств</param>
        /// <param name="casetteAlgModel">Модель алгоритма кассетирования</param>
        /// <param name="removerModels">Модели представляющие циклы сдува</param>
        public static void ChooseCommProtocol((IAxisModel TransporterDrive, IAxisModel DiscDrive, IAxisModel CasetteDrive) axisModels, ISensorsModel sensorsModel,
            IValvesModel valvesModel, ICasettingAlgModel casetteAlgModel, (IRemoverModel, IRemoverModel, IRemoverModel) removerModels)
        {
            axisModels.TransporterDrive.SpeedCommand = CommProtocol.SetTranSpeed;
            axisModels.TransporterDrive.AccelCommand = CommProtocol.SetTransporterAccel;
            axisModels.TransporterDrive.DecelCommand = CommProtocol.SetTransporterDecel;
            axisModels.TransporterDrive.StartDriveCommand = CommProtocol.StartTransporter;
            axisModels.TransporterDrive.StopDriveCommand = CommProtocol.StopTransporter;

            axisModels.DiscDrive.SpeedCommand = CommProtocol.SetDiscSpeed;
            axisModels.DiscDrive.AccelCommand = CommProtocol.SetDiscAccel;
            axisModels.DiscDrive.DecelCommand = CommProtocol.SetDiscDecel;
            axisModels.DiscDrive.StartDriveCommand = CommProtocol.StartDisc;
            axisModels.DiscDrive.StopDriveCommand = CommProtocol.StopDisc;

            axisModels.CasetteDrive.SpeedCommand = CommProtocol.SetCasetteDownSpeed;
            axisModels.CasetteDrive.ReverseSpeedCommand = CommProtocol.SetCasetteUpSpeed;
            axisModels.CasetteDrive.SetReverseDirectionCommand = CommProtocol.CasetteDirectionUp;
            axisModels.CasetteDrive.SetStraightDirectionCommand = CommProtocol.CasetteDirectionDown;
            axisModels.CasetteDrive.StartDriveCommand = CommProtocol.StartCasette;
            axisModels.CasetteDrive.StopDriveCommand = CommProtocol.StopCasette;
            axisModels.CasetteDrive.MoveCommand = CommProtocol.MoveCasetteBySteps;

            removerModels.Item1.SetRemoverDelayCommand = CommProtocol.SetRemoverDelay;
            removerModels.Item2.SetRemoverDelayCommand = CommProtocol.SetRemoverDelay;
            removerModels.Item3.SetRemoverDelayCommand = CommProtocol.SetRemoverDelay;
            removerModels.Item1.SetRemoverLengthCommand = CommProtocol.SetRemoverLength;
            removerModels.Item2.SetRemoverLengthCommand = CommProtocol.SetRemoverLength;
            removerModels.Item3.SetRemoverLengthCommand = CommProtocol.SetRemoverLength;
            removerModels.Item1.StartCommand = CommProtocol.StartRemover1Cycle;
            removerModels.Item2.StartCommand = CommProtocol.StartRemover2Cycle;
            removerModels.Item3.StartCommand = CommProtocol.StartRemover3Cycle;
            removerModels.Item1.SetCameraRemoverDistCommand = CommProtocol.SetCamera1RemoveDistance;
            removerModels.Item2.SetCameraRemoverDistCommand = CommProtocol.SetCamera2RemoveDistance;
            removerModels.Item3.SetCameraRemoverDistCommand = CommProtocol.SetCamera3RemoveDistance;

            valvesModel.Valve1EnableCommand = CommProtocol.EnablePneumo1;
            valvesModel.Valve1DisableCommand = CommProtocol.DisablePneumo1;
            valvesModel.Valve2EnableCommand = CommProtocol.EnablePneumo2;
            valvesModel.Valve2DisableCommand = CommProtocol.DisablePneumo2;
            valvesModel.Valve3EnableCommand = CommProtocol.EnablePneumo3;
            valvesModel.Valve3DisableCommand = CommProtocol.DisablePneumo3;
            valvesModel.Valve4EnableCommand = CommProtocol.EnablePneumo4;
            valvesModel.Valve4DisableCommand = CommProtocol.DisablePneumo4;
            valvesModel.Valve5EnableCommand = CommProtocol.EnablePneumo5;
            valvesModel.Valve5DisableCommand = CommProtocol.DisablePneumo5;

            casetteAlgModel.StepsPerRowCommand = CommProtocol.SetCasetteSteps;
            casetteAlgModel.FirstStepsPerRowCommand = CommProtocol.SetFirstCasetteSteps;
            casetteAlgModel.BeforePushInDelayCommand = CommProtocol.SetBeforePushInDelay;
            casetteAlgModel.PushInCasetteDelayCommand = CommProtocol.SetPneumoDelay;
            casetteAlgModel.RowCountCommand = CommProtocol.SetRowCount;
            casetteAlgModel.StartCasettingCommand = CommProtocol.EnableAutoCasetting;
            casetteAlgModel.StopCasettingCommand = CommProtocol.DisableAutoCasetting;
            casetteAlgModel.StartRowMoveCommand = CommProtocol.StartCasettingRowMove(1);
            casetteAlgModel.StartPushInCommand = CommProtocol.StartCasettingPushIn(2);
            casetteAlgModel.StartNextRowCommand = CommProtocol.StartCasettingNextRow(3);
            casetteAlgModel.StartChangeCasetteCommand = CommProtocol.StartCasettingChange(4);
            casetteAlgModel.ZeroCounterCommand = CommProtocol.CasettingZeroCounter();
        }
    }
}