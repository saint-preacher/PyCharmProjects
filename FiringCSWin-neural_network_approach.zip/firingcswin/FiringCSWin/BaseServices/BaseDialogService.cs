﻿using FiringCSWin.ViewModels;
using FiringCSWin.Views;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows;

namespace FiringCSWin.BaseServices
{
    public interface IBaseDialogService
    {
        /// <summary>
        /// Показать сообщение Windows (MessageBox)
        /// </summary>
        /// <param name="msg">Текст сообщения</param>
        /// <param name="caption">Заголовок окна</param>
        /// <param name="buttons">Набор кнопок</param>
        /// <param name="image">Изображение</param>
        void ShowMsgBox(string msg, string caption, MessageBoxButton buttons, MessageBoxImage image);

        /// <summary>
        /// Показать окно ввода беззнакового целового параметра
        /// </summary>
        /// <param name="title">Заголовок окна</param>
        /// <param name="action">Действие при выборе (нажатие ОК или ENTER)</param>
        void SpawnUshortCalcDialog(string title, Action<ushort> action);

        /// <summary>
        /// Показать окно об аварии
        /// </summary>
        /// <param name="desc">Описание аварийной ситуации</param>
        /// <param name="action">Действие по закрытию окна</param>
        void SpawnAlarmWindow(string desc, Action action);

        /// <summary>
        /// Показать диалог сохранения файла
        /// </summary>
        /// <param name="title">Заголовок окна</param>
        /// <param name="filterExt">Строка фильтра с расширением</param>
        /// <returns>Имя файла</returns>
        string SpawnSaveFileDialog(string title, List<string> filterExt);

        /// <summary>
        /// Показать диалог открытия файла
        /// </summary>
        /// <param name="title">Заголовок окна</param>
        /// <param name="filterExt">Строка фильтра с расширением</param>
        /// <returns>Имя файла</returns>
        string SpawnOpenFileDialog(string title, List<string> filterExt);
    }

    public class BaseDialogService : IBaseDialogService, IDisposable
    {
        private Mutex AlarmWindowMutex = new Mutex();

        /// <summary>
        /// Просто показываем окно сообщения
        /// </summary>
        /// <param name="msg">Текст сообщения</param>
        /// <param name="caption">Заголовок окна сообщения</param>
        /// <param name="buttons">Кнопки</param>
        /// <param name="image">Иконка сообщения</param>
        public void ShowMsgBox(string msg, string caption, MessageBoxButton buttons, MessageBoxImage image)
        {
            MessageBox.Show(msg, caption, buttons, image);
        }

        /// <summary>
        /// Открыть окно ввода (калькулятор) параметра типа ushort
        /// </summary>
        /// <param name="title">Заголовок окна</param>
        /// <param name="action">Действие при подтверждении ввода</param>
        public void SpawnUshortCalcDialog(string title, Action<ushort> action)
        {
            var calcWindow = new InputCalcWindow();
            calcWindow.DataContext = new UshortInputCalcViewModel(title) { ApplyAction = action };
            calcWindow.ShowDialog();
        }

        /// <summary>
        /// Отобразить окно аварии
        /// </summary>
        /// <param name="desc">Описание, изза чего произошла ошибка</param>
        /// <param name="action">Действие, выполняемое по закрытию окна</param>
        public void SpawnAlarmWindow(string desc, Action action)
        {
            if (AlarmWindowMutex.WaitOne(5000))
            {
                var alarmWindow = new AlarmWindow();
                alarmWindow.DataContext = new AlarmViewModel(action) { AlarmText = desc };
                alarmWindow.ShowDialog();
                AlarmWindowMutex.ReleaseMutex();
            }
        }

        public string ConstructFilterStringFromExtension(string extension)
        {
            var fltr = "Неизвестный тип файла";

            var extensionDict = new Dictionary<string, string>
            {
                { "3ds", "Графический формат 3D Studio" },
                { "3gp", "Видео с мобильного телефона" },
                { "7z", "Архив 7-Zip" },
                { "ai", "Файл Adobe Illustrator" },
                { "ani", "Анимированный курсор Windows" },
                { "arj", "Архив ARJ" },
                { "asm", "Файл исходного кода на Ассемблере" },
                { "avi", "Файл видео" },
                { "awk", "Скрип AWK" },
                { "bas", "Файл исходного кода на BASIC" },
                { "bat", "Командный файл Windows" },
                { "bmp", "Изображение Bitmap" },
                { "bz2", "Архив Bzip2" },
                { "c", "Файл исходного кода на Си" },
                { "cab", "Архив Windows Cabinet" },
                { "cdr", "Файл Corel Draw" },
                { "chm", "Файл справки Windows" },
                { "class", "Класс Java" },
                { "cmd", "Командный файл Windows" },
                { "cpp", "Файл исходного кода на С++" },
                { "cs", "Файл исходного кода на C#" },
                { "csv", "Таблица значений с разделителем" },
                { "dat", "Бинарный файл данный" },
                { "db", "Файл базы данных" },
                { "dbf", "Файл базы данных" },
                { "doc", "Документ Microsoft Word" },
                { "docx", "Документ Microsoft Word 2007" },
                { "dwg", "Чертёж AutoCad" },
                { "epub", "Электронная книга" },
                { "exe", "Исполняемый файл Windows" },
                { "gif", "Изображение GIF" },
                { "html", "Файл разметки HTML" },
                { "ico", "Значок Windows" },
                { "java", "Файл исходного кода на Java" },
                { "jpeg", "Изображение JPEG" },
                { "json", "Файл разметки JSON" },
                { "lua", "Скрипт на Lua" },
                { "mid", "Музыка в формате MIDI" },
                { "mp3", "Аудиозапись в формате MP3" },
                { "mpeg", "Файл видео MPEG" },
                { "obj", "Объектный файл" },
                { "pas", "Файл исходного кода на Pascal" },
                { "png", "Изображение Portable Network Graphics" },
                { "rar", "Архив RAR" },
                { "tar", "Архив TAR" },
                { "tiff", "Изображение TIFF" },
                { "xaml", "Файл разметки XAML" },
                { "zip", "Архив ZIP" }
            };

            if (extensionDict.ContainsKey(extension)) fltr = extensionDict[extension];

            return $"{fltr} (.{extension})|*.{extension}";
        }

        public string SpawnSaveFileDialog(string title, List<string> filterExt)
        {
            var Filter = string.Empty;

            foreach (var ext in filterExt)
            {
                if (!string.IsNullOrEmpty(Filter)) Filter += "|";
                Filter += ConstructFilterStringFromExtension(ext);
            }

            var sfd = new SaveFileDialog()
            {
                Title = title,
                FileName = "Безымянный",
                Filter = Filter
            };

            if (sfd.ShowDialog() == true)
            {
                return sfd.FileName;
            }

            return string.Empty;
        }

        public string SpawnOpenFileDialog(string title, List<string> filterExt)
        {
            var Filter = string.Empty;

            foreach(var ext in filterExt)
            {
                if (!string.IsNullOrEmpty(Filter)) Filter += "|";
                Filter += ConstructFilterStringFromExtension(ext);
            }

            var ofd = new OpenFileDialog()
            {
                Title = title,
                Filter = Filter
            };

            if (ofd.ShowDialog() == true) return ofd.FileName;

            return string.Empty;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                AlarmWindowMutex.Close();
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}