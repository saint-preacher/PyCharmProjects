﻿using System.Collections.Generic;
using System.IO;

namespace FiringCSWin.BaseServices
{
    /// <summary>
    /// Служба сохранённия, загрузки и использования параметров
    /// </summary>
    public class ConfigService
    {
        private string CfgFilename = "config.ini";

        private Dictionary<string, string> CfgEntries = new Dictionary<string, string>();

        public string this[string key]
        {
            get => CfgEntries[key];
            set => CfgEntries[key] = value;
        }

        /// <summary>
        /// Проверка наличия в словаре параметра
        /// </summary>
        /// <param name="key">Ключ для проверки</param>
        /// <returns>Наличие параметра</returns>
        public bool ContainsParameter(string key) => CfgEntries.ContainsKey(key);

        /// <summary>
        /// Добавить параметр в конфиг-файл
        /// </summary>
        /// <param name="key">Имя параметра</param>
        /// <param name="value">Значение по-умолчанию</param>
        public void Add(string key, string value) => CfgEntries.Add(key, value);

        /// <summary>
        /// Инициализация сервиса
        /// </summary>
        /// <param name="initiallyValues">Словарь с параметрами по-умолчанию</param>
        public void Initialize(Dictionary<string, string> initiallyValues)
        {
            // загружаем параметры из файла
            foreach (var pair in initiallyValues) Add(pair.Key, pair.Value);
            if (File.Exists(CfgFilename))
            {
                LoadEntries();
            }
            else CreateDefault();
        }

        /// <summary>
        /// Создать новый конфигурационный файл с параметрами по умолчанию
        /// </summary>
        private void CreateDefault()
        {
            using (var fileStream = new FileStream(CfgFilename, FileMode.CreateNew, FileAccess.Write))
            {
                SaveToStream(fileStream);
            }
        }

        /// <summary>
        /// Обновить Ini-файл
        /// </summary>
        protected void UpdateFile()
        {
            using (var fileStream = new FileStream(CfgFilename, FileMode.Truncate, FileAccess.Write))
            {
                SaveToStream(fileStream);
            }
        }

        /// <summary>
        /// Сохранить параметры в поток
        /// </summary>
        /// <param name="stream">Объект потока для сохранения</param>
        public void SaveToStream(Stream stream)
        {
            var writer = new StreamWriter(stream);
            foreach (var Pair in CfgEntries)
            {
                writer.WriteLine($"[{Pair.Key}] = \"{Pair.Value}\"");
            }

            writer.Flush();
        }

        /// <summary>
        /// Загрузить параметры из конфигурационного файла
        /// </summary>
        protected void LoadEntries()
        {
            using (var fileStream = new FileStream(CfgFilename, FileMode.Open, FileAccess.Read))
            {
                var reader = new StreamReader(fileStream);
                LoadEntriesFromStream(reader);
            }
        }

        public void LoadEntriesFromStream(StreamReader reader)
        {
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                ParseLine(line);
            }
        }

        /// <summary>
        /// Парсинг строки
        /// </summary>
        /// <param name="line">Строка для парсинга</param>
        private void ParseLine(string line)
        {
            int mode = 0;
            var key = string.Empty;
            var value = string.Empty;

            for (int i = 0; i < line.Length; i++)
            {
                ParseCharacter(line, i, ref mode, ref key, ref value);
            }

            if (!string.IsNullOrEmpty(key) && !string.IsNullOrEmpty(value))
            {
                if (!ContainsParameter(key))
                {
                    Add(key, value);
                }
                else CfgEntries[key] = value;
            }
        }

        /// <summary>
        /// Метод посимвольной обработки
        /// </summary>
        /// <param name="line">Строка для парсинга</param>
        /// <param name="i">Индекс символа в строке</param>
        /// <param name="mode">Текущий режим (глобальный)</param>
        /// <param name="key">Выходной ключ параметра</param>
        /// <param name="value">Выходное значение параметра</param>
        public static void ParseCharacter(string line, int i, ref int mode, ref string key, ref string value)
        {
            switch (line[i])
            {
                case ' ':
                    // не учитываем пробелы вообще
                    break;

                case '[':
                    mode = 1;
                    break;

                case ']':
                    if (mode == 1) mode = 2;
                    break;

                case '=':
                    if (mode == 2) mode = 3;
                    break;

                case '"':
                    if (mode > 2) mode++;
                    break;

                default:
                    switch (mode)
                    {
                        case 1:
                            key += line[i];
                            break;

                        case 4:
                            value += line[i];
                            break;

                        default:
                            break;
                    }
                    break;
            }
        }
    }
}