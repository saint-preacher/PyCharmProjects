﻿using System.Collections.Generic;
using System.Threading;

namespace FiringCSWin.BaseServices
{
    public delegate void AlarmEventHandler(string desc);

    public delegate void AlarmCodeEventHandler(int code);

    public interface IAlarmService
    {
        event AlarmEventHandler AlarmEvent;

        void Alarm(int code);
    }

    public class AlarmService : IAlarmService
    {
        private Dictionary<int, string> AlarmsCodes = new Dictionary<int, string>
        {
            { 0, "Нет аварии" },
            { 1, "Проверка аварийного сигнала." },
            { 2, "Превышено время ожидания перемещения ряда изделий на позицию загрузки в кассету." },
            { 3, "Сработал аварийный концевик нижнего положения кассеты." },
            { 4, "Превышено время ожидания перемещения кассеты до упора вверх." },
            { 5, "Отсутствует полная кассета или присутствует пустая." },
            { 6, "Превышено время ожидания работы пневмоцилиндра смены кассеты." },
            { 7, "Для запуска отключите пневмоцилиндр и/или уберить полную кассету." }
        };
        
        public AlarmService(){}

        public event AlarmEventHandler AlarmEvent;

        public void Alarm(int code)
        {
            if (AlarmsCodes.ContainsKey(code))
            {
                AlarmEvent?.Invoke(AlarmsCodes[code]);
            }
        }
    }
}