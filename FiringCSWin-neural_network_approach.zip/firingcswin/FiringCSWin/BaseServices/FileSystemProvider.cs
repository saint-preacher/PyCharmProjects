﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace FiringCSWin.BaseServices
{
    public interface IFileSystemProvider
    {
        bool DirExists(string path);
        void DirCreate(string path);
        bool FileExists(string path);
        IEnumerable<string> DirEnumFiles(string path, string pattern);
        IEnumerable<string> DirEnumDirs(string path, string pattern);
        string GetCurrentDirectory();
    }

    /// <summary>
    /// Стандартный провайдер к функциям файловой системы в .NET
    /// </summary>
    public class NETFSProvider : IFileSystemProvider
    {
        /// <summary>
        /// Создать директорию
        /// </summary>
        /// <param name="path">Путь + имя новой директории</param>
        public void DirCreate(string path)
        {
            Directory.CreateDirectory(path);
        }

        /// <summary>
        /// Перечисление директорий
        /// </summary>
        /// <param name="path">Путь к месту перечисления</param>
        /// <param name="pattern">Паттерн поиска (можно использовать ? и *)</param>
        /// <returns>Коллекция путей и имён директорий</returns>
        public IEnumerable<string> DirEnumDirs(string path, string pattern = "*")
        {
            return Directory.EnumerateDirectories(path, pattern);
        }

        /// <summary>
        /// Перечисление файлов
        /// </summary>
        /// <param name="path">Путь к месту перечисления</param>
        /// <param name="pattern">Паттерн поиска (можно использовать ? и *)</param>
        /// <returns>Коллекция путей и имён файлов</returns>
        public IEnumerable<string> DirEnumFiles(string path, string pattern = "*")
        {
            return Directory.EnumerateFiles(path, pattern);
        }

        /// <summary>
        /// Проверка существования директории
        /// </summary>
        /// <param name="path">Путь к проверяемой директории</param>
        /// <returns>Истину, в случае существования директории</returns>
        public bool DirExists(string path)
        {
            return Directory.Exists(path);
        }

        /// <summary>
        /// Проверка существования файла
        /// </summary>
        /// <param name="path">Путь к проверяемому файлу</param>
        /// <returns>Истину, в случае существования файла</returns>
        public bool FileExists(string path)
        {
            return File.Exists(path);
        }

        /// <summary>
        /// Получение пути с именем текущей директории
        /// </summary>
        public string GetCurrentDirectory() => Directory.GetCurrentDirectory();
    }
}
