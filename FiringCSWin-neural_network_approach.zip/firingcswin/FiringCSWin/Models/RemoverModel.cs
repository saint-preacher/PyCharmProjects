﻿using FiringCSWin.BaseServices;
using FiringCSWin.MVVMBase;
using System;
using System.Threading.Tasks;

namespace FiringCSWin.Models
{
    public enum RemoverMode { NoRemove, RemoveBad };

    public interface IRemoverModel
    {
        Func<ushort, string> SetRemoverDelayCommand { get; set; }
        Func<ushort, string> SetRemoverLengthCommand { get; set; }
        Func<ushort, string> SetCameraRemoverDistCommand { get; set; }

        string StartCommand { get; set; }

        /// <summary>
        /// Задержка перед сдувом брака (мс)
        /// </summary>
        ushort RemoverDelay { get; set; }

        /// <summary>
        /// Длина импульса сдува брака (мс)
        /// </summary>
        ushort RemoverLength { get; set; }

        /// <summary>
        /// Расстояние в ячейках ремня между камерой и сдувом
        /// </summary>
        ushort RemoverDist { get; set; }

        void Start();
    }

    public class RemoverModel : ModelBase, IRemoverModel
    {
        private ushort _removerDelay;
        private ushort _removerLength;
        private ushort _removerDist;
        private ICommService commService;

        public RemoverModel(ICommService comm) => commService = comm;
        
        public ushort RemoverDelay
        {
            get => _removerDelay;
            set
            {
                _removerDelay = value;
                Task.Run(() => commService.SendCommand(SetRemoverDelayCommand(value)));
                RaisePropertyChanged(nameof(RemoverDelay));
            }
        }
        
        public ushort RemoverLength
        {
            get => _removerLength;
            set
            {
                _removerLength = value;
                Task.Run(() => commService.SendCommand(SetRemoverLengthCommand(value)));
                RaisePropertyChanged(nameof(RemoverLength));
            }
        }

        public ushort RemoverDist
        {
            get => _removerDist;
            set
            {
                _removerDist = value;
                Task.Run(() => commService.SendCommand(SetCameraRemoverDistCommand(value)));
                RaisePropertyChanged(nameof(RemoverDist));
            }
        }

        public Func<ushort, string> SetRemoverDelayCommand { get; set; }

        public Func<ushort, string> SetRemoverLengthCommand { get; set; }

        public Func<ushort, string> SetCameraRemoverDistCommand { get; set; }

        public string StartCommand { get; set; }

        public void Start() => Task.Run(() => commService.SendCommand(StartCommand));
    }
}
