﻿using FiringCSWin.Services;

namespace FiringCSWin.Models
{
    public class TubeModel
    {
        public const int DumpedGood         = 0b000;
        public const int DumpedByLength     = 0b001;
        public const int DumpedByOuterDiam  = 0b010;
        public const int DumpedByInnerDiam  = 0b100;

        public TubeDataCamera CameraId { get; set; }
        public double Diameter { get; set; }
        public double InnerDiameter { get; set; }
        public double Length { get; set; }
        public ulong Id { get; set; }
        public int Dumped { get; set; }

        public bool IsGood => Dumped == DumpedGood;

        public bool IsDumpedByLength => (Dumped & DumpedByLength) > 0;

        public bool IsDumpedByOuterDiam => (Dumped & DumpedByOuterDiam) > 0;

        public bool IsDumpedByInnerDiam => (Dumped & DumpedByInnerDiam) > 0;

        public override string ToString()
        {
            switch (CameraId)
            {
                case TubeDataCamera.HeadUp:
                    return HeadUpCheck();
                case TubeDataCamera.Side1:
                case TubeDataCamera.Side2:
                    return SideCheck();
            }

            return "ОШИБКА";
        }

        protected string HeadUpCheck()
        {
            if (IsGood)
            {
                return $"ВЕРХ L = {Length:F3}";
            } else
            {
                if (IsDumpedByLength) return $"ВЕРХ L = ({Length:F2})";
            }

            return $"ОШИБКА L = ({Length:F3})";
        }

        protected string SideCheck()
        {
            var name = (CameraId == TubeDataCamera.Side1) ? "СЛЕВА" : "СПРАВА";

            if (IsGood)
            {
                return $"{name} D = {Diameter:F2}, d = {InnerDiameter:F2}";
            } else
            {
                string retString = $"{name} ";
                if (IsDumpedByOuterDiam) retString += $"D = ({Diameter:F2}) ";
                if (IsDumpedByOuterDiam && IsDumpedByInnerDiam) retString += "и ";
                if (IsDumpedByInnerDiam) retString += $"d = ({InnerDiameter:F2}) ";

                return retString;
            }
        }
    }
}
