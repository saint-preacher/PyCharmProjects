﻿using Microsoft.ML.Data;
using System.Drawing;

namespace FiringCSWin.Models.TensorFlow
{
    public class ImageData
    {
        [LoadColumn(0)]
        public string ImagePath;

        [LoadColumn(1)]
        public string Label;
    }
}
