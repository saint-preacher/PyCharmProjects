﻿namespace FiringCSWin.Models.TensorFlow
{
    public class ImagePrediction : ImageData
    {
        public float[] Score;

        public string PredictedLabelValue;
    }
}
