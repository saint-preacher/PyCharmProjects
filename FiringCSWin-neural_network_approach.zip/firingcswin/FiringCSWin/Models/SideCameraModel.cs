﻿namespace FiringCSWin.Models
{
    public interface ISideCameraModel : ICameraModel
    {
        /// <summary>
        /// Величина порога для алгоритма Canny
        /// </summary>
        double CannyThreshold { get; }

        /// <summary>
        /// Строка для величины порога для алгоритма Canny
        /// </summary>
        string CannyThresholdString { get; set; }

        /// <summary>
        /// Коррекция расчёта площади
        /// </summary>
        double AreaCalcCorrection { get; }

        /// <summary>
        /// Строка для величины коррекции расчёта площади
        /// </summary>
        string AreaCalcCorrectionString { get; set; }

        /// <summary>
        /// Минимальная длина эллипса
        /// </summary>
        double MinEllipseLen { get; }

        /// <summary>
        /// Строка для величины минимальной длины эллипса
        /// </summary>
        string MinEllipseLenString { get; set; }

        /// <summary>
        /// Минимальный внутрений диаметр
        /// </summary>
        double MinInnerParam { get; }

        /// <summary>
        /// Строка для величины минимального внутреннего диаметра
        /// </summary>
        string MinInnerParamString { get; set; }

        /// <summary>
        /// Максимальный внутренний диаметр
        /// </summary>
        double MaxInnerParam { get; }

        /// <summary>
        /// Строка для величины максимального внутреннего диаметра
        /// </summary>
        string MaxInnerParamString { get; set; }
    }

    public class SideCameraModel: CameraModel, ISideCameraModel
    {
        private double _cannyThreshold;
        private string _cannyThresholdString;
        private double _areaCalcCorrection;
        private string _areaCalcCorrectionString;
        private double _minEllipseLen;
        private string _minEllipseLenString;
        private double _minInnerParam;
        private string _minInnerParamString;
        private double _maxInnerParam;
        private string _maxInnerParamString;

        public double MinInnerParam
        {
            get => _minInnerParam;
            protected set
            {
                _minInnerParam = value;
                RaisePropertyChanged(nameof(MinInnerParam));
            }
        }

        public string MinInnerParamString
        {
            get => _minInnerParamString;
            set
            {
                if(double.TryParse(value, out double outvar))
                {
                    _minInnerParamString = value;
                    RaisePropertyChanged(nameof(MinInnerParam));
                    MinInnerParam = outvar;
                }
            }
        }

        public double MaxInnerParam
        {
            get => _maxInnerParam;
            protected set
            {
                _maxInnerParam = value;
                RaisePropertyChanged(nameof(MaxInnerParam));
            }
        }

        public string MaxInnerParamString
        {
            get => _maxInnerParamString;
            set
            {
                if(double.TryParse(value, out double outvar))
                {
                    _maxInnerParamString = value;
                    RaisePropertyChanged(nameof(MaxInnerParamString));
                    MaxInnerParam = outvar;
                }
            }
        }

        public double CannyThreshold
        {
            get => _cannyThreshold;
            protected set
            {
                _cannyThreshold = value;
                RaisePropertyChanged(nameof(CannyThreshold));
            }
        }

        public string CannyThresholdString {
            get => _cannyThresholdString;
            set
            {
                if(double.TryParse(value, out double outvar))
                {
                    _cannyThresholdString = value;
                    RaisePropertyChanged(nameof(CannyThresholdString));
                    CannyThreshold = outvar;
                }
            }
        }

        public double AreaCalcCorrection {
            get => _areaCalcCorrection;
            protected set
            {
                _areaCalcCorrection = value;
                RaisePropertyChanged(nameof(AreaCalcCorrection));
            }
        }

        public string AreaCalcCorrectionString {
            get => _areaCalcCorrectionString;
            set
            {
                if(double.TryParse(value, out double outvar))
                {
                    _areaCalcCorrectionString = value;
                    RaisePropertyChanged(nameof(AreaCalcCorrectionString));
                    AreaCalcCorrection = outvar;
                }
            }
        }

        public double MinEllipseLen
        {
            get => _minEllipseLen;
            protected set
            {
                _minEllipseLen = value;
                RaisePropertyChanged(nameof(MinEllipseLen));
            }
        }

        public string MinEllipseLenString {
            get => _minEllipseLenString;
            set
            {
                if(double.TryParse(value, out double outvar))
                {
                    _minEllipseLenString = value;
                    RaisePropertyChanged(nameof(MinEllipseLenString));
                    MinEllipseLen = outvar;
                }
            }
        }
    }
}
