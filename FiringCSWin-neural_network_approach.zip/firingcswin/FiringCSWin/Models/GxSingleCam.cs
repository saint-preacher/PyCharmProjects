﻿using FiringCSWin.BaseServices;
using FiringCSWin.Services;
using GxIAPINET;
using System;
using System.Collections.Generic;
using System.Windows;

namespace FiringCSWin
{
    public delegate void FrameChangedEventHandler(IntPtr dataPointer, long cols, long rows);

    public class GxSingleCam
    {
        bool _isSnap;
        long rows, cols;

        IGXDevice objIGXDevice;
        IGXStream objIGXStream;
        IGXFeatureControl objIGXFeatureControl;
        IErrorService ErrorService;
        IGXFactory Factory;
        string SerialNum;
        
        public event FrameChangedEventHandler FrameChanged; // событие изменения содержимого кадра

        public GxSingleCam(IGXFactory factory, IErrorService errorService, string serialNum)
        {
            SerialNum = serialNum;
            Factory = factory;
            ErrorService = errorService;
        }        

        public bool OpenConnection()
        {
            try
            {
                // Закрыть поток
                CloseStream();

                // Если устройство уже было открыто, нужно его закрыть
                CloseDevice();

                // Если уже открыто - закрыть
                if (objIGXDevice != null)
                {
                    objIGXDevice.Close();
                    objIGXDevice = null;
                }                

                // Открываем камеру
                objIGXDevice = Factory.OpenDeviceBySN(SerialNum, GX_ACCESS_MODE.GX_ACCESS_EXCLUSIVE);
                objIGXFeatureControl = objIGXDevice.GetRemoteFeatureControl();

                // Открываем поток
                if (objIGXDevice != null)
                {
                    objIGXStream = objIGXDevice.OpenStream(0);
                }

                // установка оптимального размера пакета
                GX_DEVICE_CLASS_LIST objDeviceClass = objIGXDevice.GetDeviceInfo().GetDeviceClass();
                if (GX_DEVICE_CLASS_LIST.GX_DEVICE_CLASS_GEV == objDeviceClass)
                {
                    if (objIGXFeatureControl.IsImplemented("GevSCPSPacketSize"))
                    {
                        var nPacketSize = objIGXStream.GetOptimalPacketSize();
                        objIGXFeatureControl.GetIntFeature("GevSCPSPacketSize").SetValue(nPacketSize);
                    }
                }

                InitDevice();

                InitTriggers();

                GetRowsCols();

                return true;
            }
            catch (Exception ex)
            {
                ErrorService.Report($"GxSingleCam.Create: {ex.Message}", ErrorNotifierService.E_LEVEL.Warning);
            }
            return false;
        }
        /// <summary>
        /// Настройка триггеров 
        /// </summary>
        private void InitTriggers()
        {
            var features = new string[] { "TriggerMode", "TriggerSource" };
            var values = new string[] { "On", "Line0" };

            // включаем срабатывание по триггеру, источник Line0
            if (objIGXFeatureControl != null)
            {
                for (int i = 0; i < features.Length; i++)
                {
                    var list = new List<string>();
                    if (objIGXFeatureControl.IsImplemented(features[i]) && objIGXFeatureControl.IsWritable(features[i]))
                    {
                        objIGXFeatureControl.GetEnumFeature(features[i]).SetValue(values[i]);
                    }
                }
            }
        }

        private void GetRowsCols()
        {
            var features = new Dictionary<string, Action<long>>
            {
                { "Width", (width) => cols = width },
                { "Height", (height) => rows = height }
            };

            if(objIGXFeatureControl != null)
            {
                foreach (var feature in features) {
                    if (objIGXFeatureControl.IsImplemented(feature.Key) && objIGXFeatureControl.IsReadable(feature.Key))
                        feature.Value(objIGXFeatureControl.GetIntFeature(feature.Key).GetValue());
                }
            }
        }

        /// <summary>
        /// Инициализация устройства
        /// </summary>
        private void InitDevice()
        {
            if (objIGXFeatureControl != null)
            {
                objIGXFeatureControl.GetEnumFeature("AcquisitionMode").SetValue("Continuous");
            }
        }

        /// <summary>
        /// Закрыть поток
        /// </summary>
        private void CloseStream()
        {
            try
            {
                if (objIGXStream != null)
                {
                    objIGXStream.Close();
                    objIGXStream = null;
                }
            }
            catch (Exception e) {
                ErrorService.Report($"GxSingleCam.CloseStream: Произошла ошибка при закрытии потока {e.Message}", ErrorNotifierService.E_LEVEL.Warning);
            }
        }

        /// <summary>
        /// Закрыть устройство
        /// </summary>
        private void CloseDevice()
        {
            try
            {
                if (null != objIGXDevice)
                {
                    objIGXDevice.Close();
                    objIGXDevice = null;
                }
            }
            catch (Exception e) {
                ErrorService.Report($"GxSingleCam.CloseDevice: Произошла ошибка при закрытии устройства {e.Message}", ErrorNotifierService.E_LEVEL.Error);
            }
        }

        /// <summary>
        /// Закрытие соединения
        /// </summary>
        /// <returns></returns>
        public bool CloseConnection()
        {
            try
            {
                if (_isSnap)
                {
                    if (objIGXFeatureControl != null)
                    {
                        objIGXFeatureControl.GetCommandFeature("AcquisitionStop").Execute();
                        objIGXFeatureControl = null;
                    }

                    if (objIGXStream != null)
                    {
                        objIGXStream.StopGrab();

                        objIGXStream.UnregisterCaptureCallback();
                        objIGXStream.Close();
                        objIGXStream = null;
                    }
                }

                _isSnap = false;                

                if (objIGXDevice != null)
                {
                    objIGXDevice.Close();
                    objIGXDevice = null;
                }

                return true;
            }
            catch (Exception ex)
            {
                ErrorService.Report($"GxSingleCam.CloseConnection: Произошла ошибка при закрытии соединения {ex.Message}", ErrorNotifierService.E_LEVEL.Error);
            }

            return false;
        }

        public bool StopAcquisition()
        {
            try
            {
                // остановка получения кадров с камеры
                if (objIGXFeatureControl != null)
                {
                    objIGXFeatureControl.GetCommandFeature("AcquisitionStop").Execute();
                }

                if (objIGXStream != null)
                {
                    objIGXStream.StopGrab();
                    objIGXStream.UnregisterCaptureCallback();
                }
                
                _isSnap = false;
                return true;
            }
            catch (Exception ex)
            {
                ErrorService.Report($"Ошибка остановки сбора кадров {ex.Message}", ErrorNotifierService.E_LEVEL.Error);
            }
            return false;
        }

        public bool SetExpositionTime(float exptime)
        {
            try
            {
                if(objIGXFeatureControl != null)
                {
                    objIGXFeatureControl.GetFloatFeature("ExposureTime").SetValue(exptime);
                    return true;
                }                
            } catch (Exception ex)
            {
                ErrorService.Report($"Ошибка задания экспозиции {ex.Message}", ErrorNotifierService.E_LEVEL.Error);
            }

            return false;
        }

        public bool StartAcquisition(float exptime)
        {
            try
            {      
                if (objIGXFeatureControl != null)
                {
                    objIGXFeatureControl.GetFloatFeature("ExposureTime").SetValue(exptime);
                    objIGXFeatureControl.GetCommandFeature("AcquisitionStart").Execute();
                }

                // запуск потока получения изображений
                if (objIGXStream != null)
                {
                    objIGXStream.RegisterCaptureCallback(this, CaptureCallbackPro);
                    objIGXStream.StartGrab();
                }

                _isSnap = true;
                return true;
            }
            catch (Exception ex)
            {
                ErrorService.Report($"Ошибка запуска сбора кадров {ex.Message}", ErrorNotifierService.E_LEVEL.Error);
            }

            return false;
        }

        /// <summary>
        /// Callback для получения изображения
        /// </summary>
        /// <param name="obj">пользовательский параметр</param>
        /// <param name="objIFrameData">Данные кадра</param>
        private void CaptureCallbackPro(object objUserParam, IFrameData objIFrameData)
        {
            try
            {
                var objGxSingleCam = objUserParam as GxSingleCam;                
                objGxSingleCam.HandleFrame(objIFrameData);
            }
            catch (Exception e){
                ErrorService.Report($"Ошибка сохранения буфера кадра {e.Message}", ErrorNotifierService.E_LEVEL.Error);
            }
        }

        private void HandleFrame(IFrameData objIFrameData)
        {
            if(objIFrameData != null)
            {
                FrameChanged?.Invoke(objIFrameData.GetBuffer(), cols, rows);
            }
        }
    }
}
