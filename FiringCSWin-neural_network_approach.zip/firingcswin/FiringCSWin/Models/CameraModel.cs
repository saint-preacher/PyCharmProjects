﻿using FiringCSWin.MVVMBase;
using Microsoft.ML;
using System.Windows.Media;

namespace FiringCSWin.Models
{
    public enum CameraState { NoCameraSelected, Offline, ConnectionOpened, AcqStarted };

    public enum FrameMode { Raw, Threshold, Edges, MOGBackgroundRemover, WithCalculatedHelpers, WithCalculatedHelpers2 };

    public delegate void RemoverModeChangedEventHandler(RemoverMode removerMode);

    public interface ICameraModel
    {
        /// <summary>
        /// Выбранная камера
        /// </summary>
        string SelectedCamera { get; set; }

        /// <summary>
        /// Текущее состояние соединения с камерой
        /// </summary>
        CameraState CurrentState { get; set; }

        /// <summary>
        /// Ширина холста для отображения кадра
        /// </summary>
        double CanvasWidth { get; set; }

        /// <summary>
        /// Высота холста для отображения кадра
        /// </summary>
        double CanvasHeight { get; set; }

        /// <summary>
        /// Строка для значения коэффициента перевода в миллиметры
        /// </summary>
        string RefMillimetersString { get; set; }

        /// <summary>
        /// Коэффициент перевода в миллиметры
        /// </summary>
        double RefMillimeters { get; }

        /// <summary>
        /// Количество сохранённых кадров
        /// </summary>
        int SaveFramesCount { get; set; }

        /// <summary>
        /// Величина экспозиции в мкс
        /// </summary>
        float Exposure { get; }

        /// <summary>
        /// Строка величины экспозиции
        /// </summary>
        string ExposureString { get; set; }

        /// <summary>
        /// Количество кадров для съемки командой "Сохранить N Кадров"
        /// </summary>
        int NFramesSaveCount { get; }

        /// <summary>
        /// Строка количества кадров для съемки командой "Сохранить N кадров"
        /// </summary>
        string NFramesString { get; set; }

        /// <summary>
        /// Строка для максимального значения измеряемого параметра
        /// </summary>
        string MaxGoodParamString { get; set; }

        /// <summary>
        /// Максимальное значение измеряемого параметра, для того чтобы считать трубку хорошей
        /// </summary>
        double MaxGoodParam { get; }

        /// <summary>
        /// Строка для минимального значения измеряемого параметра
        /// </summary>
        string MinGoodParamString { get; set; }

        /// <summary>
        /// Минимальное значение измеряемого параметра, для того чтобы считать трубку хорошей
        /// </summary>
        double MinGoodParam { get; }
        
        /// <summary>
        /// Строка для значения верхней ординаты ROI
        /// </summary>
        string ROITopString { get; set; }

        /// <summary>
        /// Значение верхней ординаты ROI
        /// </summary>
        int ROITop { get; }

        /// <summary>
        /// Строка для значения нижней ординаты ROI
        /// </summary>
        string ROIBottomString { get; set; }

        /// <summary>
        /// Значение нижней ординаты ROI
        /// </summary>
        int ROIBottom { get; }

        /// <summary>
        /// Левая точка прямоугольника интереса
        /// </summary>
        int ROILeft { get; }

        /// <summary>
        /// Правая точка прямоугольника интереса
        /// </summary>
        int ROIRight { get; }

        /// <summary>
        /// Строка для значения левой точки прямоугольника интереса
        /// </summary>
        string ROILeftString { get; set; }

        /// <summary>
        /// Строка для значения правой точки прямоугольника интереса
        /// </summary>
        string ROIRightString { get; set; }

        /// <summary>
        /// Строка для значения порога
        /// </summary>
        string ThresholdString { get; set; }

        /// <summary>
        /// Значение для порога операции бинаризации (0-255)
        /// </summary>
        byte Threshold { get; }

        /// <summary>
        /// Режим отображения кадра
        /// </summary>
        FrameMode FrameMode { get; set; }

        /// <summary>
        /// Режим сдува
        /// </summary>
        RemoverMode RemoverMode { get; set; }

        /// <summary>
        /// Флаг включенного режима отладки
        /// </summary>
        bool DebugEnabled { get; set; }

        /// <summary>
        /// Событие изменения режима сдува
        /// </summary>
        event RemoverModeChangedEventHandler RemoverModeChanged;

        /// <summary>
        /// Доступность кнопки "Загрузить кадр из файла"
        /// </summary>
        bool LoadFromFrameEnabled { get; }

        /// <summary>
        /// Строка состояния забора кадров камеры
        /// </summary>
        string CameraStateString { get; }

        /// <summary>
        /// Цвет строки состояния забора кадров
        /// </summary>
        Brush CameraStateBrush { get; }

        /// <summary>
        /// Доступ к выбору камеры
        /// </summary>
        bool ComboboxEnabled { get; }

        /// <summary>
        /// Доступность открытия соединения с камерой
        /// </summary>
        bool OpenEnabled { get; }

        /// <summary>
        /// Доступность старта сбора кадров
        /// </summary>
        bool StartEnabled { get; }

        /// <summary>
        /// Доступность остановки сбора кадров
        /// </summary>
        bool StopEnabled { get; }

        /// <summary>
        /// Доступность закрытия соединения с камерой
        /// </summary>
        bool CloseEnabled { get; }
    }

    public class CameraModel : ModelBase, ICameraModel 
    {
        private string _selectedCamera;
        private CameraState _currentState;
        private string _exposureString;
        private float _exposure;
        private double _canvasWidth;
        private double _canvasHeight;
        private int _nFramesSaveCount;
        private string _nFramesString;
        private int _saveFramesCount;
        private FrameMode _frameMode;
        private RemoverMode _removerMode;
        private int _roiTop;
        private int _roiBottom;
        private string _roiTopString;
        private string _roiBottomString;
        private int _roiLeft;
        private int _roiRight;
        private string _roiLeftString;
        private string _roiRightString;
        private double _refMillimeters;
        private string _refMillimetersString;
        private double _maxGoodParam;
        private string _maxGoodParamString;
        private double _minGoodParam;
        private string _minGoodParamString;
        private bool _debugEnabled;
        private byte _threshold;
        private string _thresholdString;

        public event RemoverModeChangedEventHandler RemoverModeChanged;

        public CameraModel()
        {
            CurrentState = CameraState.NoCameraSelected;
        }
        
        /// <summary>
        /// Выбранная камера
        /// </summary>
        public string SelectedCamera
        {
            get => _selectedCamera;
            set
            {
                _selectedCamera = value;
                RaisePropertyChanged(nameof(SelectedCamera));
                if (!string.IsNullOrEmpty(_selectedCamera)) CurrentState = CameraState.Offline;
            }
        }

        /// <summary>
        /// Текущее состояние соединения с камерой
        /// </summary>
        public CameraState CurrentState
        {
            get => _currentState;
            set
            {
                _currentState = value;
                RaisePropertyChanged(nameof(CurrentState));
                RaisePropertyChanged(nameof(LoadFromFrameEnabled));
                RaisePropertyChanged(nameof(CameraStateString));
                RaisePropertyChanged(nameof(CameraStateBrush));
                RaisePropertyChanged(nameof(ComboboxEnabled));
                RaisePropertyChanged(nameof(OpenEnabled));
                RaisePropertyChanged(nameof(StartEnabled));
                RaisePropertyChanged(nameof(StopEnabled));
                RaisePropertyChanged(nameof(CloseEnabled));
            }
        }

        /// <summary>
        /// Ширина холста для отображения кадра
        /// </summary>
        public double CanvasWidth
        {
            get => _canvasWidth;
            set
            {
                _canvasWidth = value;
                RaisePropertyChanged(nameof(CanvasWidth));
            }
        }

        /// <summary>
        /// Высота холста для отображения кадра
        /// </summary>
        public double CanvasHeight
        {
            get => _canvasHeight;
            set
            {
                _canvasHeight = value;
                RaisePropertyChanged(nameof(CanvasHeight));
            }
        }

        /// <summary>
        /// Строка для значения коэффициента перевода в миллиметры
        /// </summary>
        public string RefMillimetersString
        {
            get => _refMillimetersString;
            set
            {
                if (double.TryParse(value, out double outvar))
                {
                    _refMillimetersString = value;
                    RaisePropertyChanged(nameof(RefMillimetersString));
                    RefMillimeters = outvar;
                }
            }
        }

        /// <summary>
        /// Коэффициент перевода в миллиметры
        /// </summary>
        public double RefMillimeters
        {
            get => _refMillimeters;
            protected set
            {
                _refMillimeters = value;
                RaisePropertyChanged(nameof(RefMillimeters));
            }
        }


        public int SaveFramesCount
        {
            get => _saveFramesCount;
            set
            {
                _saveFramesCount = value;
                RaisePropertyChanged(nameof(SaveFramesCount));
            }
        }

        /// <summary>
        /// Величина экспозиции в мкс
        /// </summary>
        public float Exposure
        {
            get => _exposure;
            protected set
            {
                _exposure = value;
                RaisePropertyChanged(nameof(Exposure));
            }
        }

        /// <summary>
        /// Строка величины экспозиции
        /// </summary>
        public string ExposureString
        {
            get => _exposureString;
            set
            {
                if (float.TryParse(value, out float outvar))
                {
                    _exposureString = value;
                    RaisePropertyChanged(nameof(ExposureString));
                    Exposure = outvar;
                }
            }
        }

        /// <summary>
        /// Строка для значения порога
        /// </summary>
        public string ThresholdString
        {
            get => _thresholdString;
            set
            {
                if (byte.TryParse(value, out byte outvar))
                {
                    _thresholdString = value;
                    RaisePropertyChanged(nameof(ThresholdString));
                    Threshold = outvar;
                }
            }
        }

        /// <summary>
        /// Значение для операции порога (0-255)
        /// </summary>
        public byte Threshold
        {
            get => _threshold;
            protected set
            {
                _threshold = value;
                RaisePropertyChanged(nameof(Threshold));
            }
        }

        /// <summary>
        /// Количество кадров для съемки командой "Сохранить N Кадров"
        /// </summary>
        public int NFramesSaveCount
        {
            get => _nFramesSaveCount;
            protected set
            {
                _nFramesSaveCount = value;
                RaisePropertyChanged(nameof(NFramesSaveCount));
            }
        }

        /// <summary>
        /// Строка количества кадров для съемки командой "Сохранить N кадров"
        /// </summary>
        public string NFramesString
        {
            get => _nFramesString;
            set
            {
                if (int.TryParse(value, out int outvar))
                {
                    _nFramesString = value;
                    RaisePropertyChanged(nameof(NFramesString));
                    NFramesSaveCount = outvar;
                }
            }
        }

        /// <summary>
        /// Строка для значения максимальной длины трубки
        /// </summary>
        public string MaxGoodParamString
        {
            get => _maxGoodParamString;
            set
            {
                if (double.TryParse(value, out double outvar))
                {
                    _maxGoodParamString = value;
                    RaisePropertyChanged(nameof(MaxGoodParamString));
                    MaxGoodParam = outvar;
                }
            }
        }

        /// <summary>
        /// Максимальная длина трубки
        /// </summary>
        public double MaxGoodParam
        {
            get => _maxGoodParam;
            protected set
            {
                _maxGoodParam = value;
                RaisePropertyChanged(nameof(MaxGoodParam));
            }
        }

        /// <summary>
        /// Строка для значения минимальной длины трубки
        /// </summary>
        public string MinGoodParamString
        {
            get => _minGoodParamString;
            set
            {
                if (double.TryParse(value, out double outvar))
                {
                    _minGoodParamString = value;
                    RaisePropertyChanged(nameof(MinGoodParamString));
                    MinGoodParam = outvar;
                }
            }
        }

        /// <summary>
        /// Минимальная длина трубки
        /// </summary>
        public double MinGoodParam
        {
            get => _minGoodParam;
            protected set
            {
                _minGoodParam = value;
                RaisePropertyChanged(nameof(MinGoodParam));
            }
        }

        /// <summary>
        /// Строка для значения верхней ординаты ROI
        /// </summary>
        public string ROITopString
        {
            get => _roiTopString;
            set
            {
                if (int.TryParse(value, out int outvar) && (outvar >= 0))
                {
                    _roiTopString = value;
                    RaisePropertyChanged(nameof(ROITopString));
                    ROITop = outvar;
                }
            }
        }

        /// <summary>
        /// Значение верхней ординаты ROI
        /// </summary>
        public int ROITop
        {
            get => _roiTop;
            protected set
            {
                _roiTop = value;
                RaisePropertyChanged(nameof(ROITop));
            }
        }

        /// <summary>
        /// Строка для значения нижней ординаты ROI
        /// </summary>
        public string ROIBottomString
        {
            get => _roiBottomString;
            set
            {
                if (int.TryParse(value, out int outvar) && (outvar >= 0))
                {
                    _roiBottomString = value;
                    RaisePropertyChanged(nameof(ROIBottomString));
                    ROIBottom = outvar;
                }
            }
        }

        /// <summary>
        /// Значение нижней ординаты ROI
        /// </summary>
        public int ROIBottom
        {
            get => _roiBottom;
            protected set
            {
                _roiBottom = value;
                RaisePropertyChanged(nameof(ROIBottom));
            }
        }

        public int ROILeft
        {
            get => _roiLeft;
            protected set
            {
                _roiLeft = value;
                RaisePropertyChanged(nameof(ROILeft));
            }
        }

        public string ROILeftString
        {
            get => _roiLeftString;
            set
            {
                if (int.TryParse(value, out int outvar) && (outvar >= 0))
                {
                    _roiLeftString = value;
                    RaisePropertyChanged(nameof(ROILeftString));
                    ROILeft = outvar;
                }
            }
        }

        public int ROIRight
        {
            get => _roiRight;
            protected set
            {
                _roiRight = value;
                RaisePropertyChanged(nameof(ROIRight));
            }
        }

        public string ROIRightString
        {
            get => _roiRightString;
            set
            {
                if (int.TryParse(value, out int outvar) && (outvar >= 0))
                {
                    _roiRightString = value;
                    RaisePropertyChanged(nameof(ROIRightString));
                    ROIRight = outvar;
                }
            }
        }

        /// <summary>
        /// Режим отображения кадра
        /// </summary>
        public FrameMode FrameMode
        {
            get => _frameMode;
            set
            {
                _frameMode = value;
                RaisePropertyChanged(nameof(FrameMode));
            }
        }

        /// <summary>
        /// Режим сдува
        /// </summary>
        public RemoverMode RemoverMode
        {
            get => _removerMode;
            set
            {
                _removerMode = value;
                RemoverModeChanged?.Invoke(value);
                RaisePropertyChanged(nameof(RemoverMode));
            }
        }

        public bool DebugEnabled
        {
            get => _debugEnabled;
            set
            {
                _debugEnabled = value;
                RaisePropertyChanged(nameof(DebugEnabled));
            }
        }

        /// <summary>
        /// Доступность кнопки "Загрузить кадр из файла"
        /// </summary>
        public bool LoadFromFrameEnabled
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                        return true;
                    case CameraState.ConnectionOpened:
                    case CameraState.AcqStarted:
                    default:
                        return false;
                }
            }
        }

        /// <summary>
        /// Строка состояния забора кадров камеры
        /// </summary>
        public string CameraStateString
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                        return "CLOSED";
                    case CameraState.ConnectionOpened:
                        return "OPENED";
                    case CameraState.AcqStarted:
                        return "WORKING";
                    default:
                        return "CLOSED";
                }
            }
        }

        /// <summary>
        /// Цвет строки состояния забора кадров
        /// </summary>
        public Brush CameraStateBrush
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                        return Brushes.White;
                    case CameraState.ConnectionOpened:
                        return Brushes.LimeGreen;
                    case CameraState.AcqStarted:
                        return Brushes.Green;
                    default:
                        return Brushes.White;
                }
            }
        }

        /// <summary>
        /// Доступ к выбору камеры
        /// </summary>
        public bool ComboboxEnabled
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                        return true;
                    case CameraState.ConnectionOpened:
                    case CameraState.AcqStarted:
                        return false;
                    default:
                        return false;
                }
            }
        }

        /// <summary>
        /// Доступность открытия соединения с камерой
        /// </summary>
        public bool OpenEnabled
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.Offline:
                        return true;
                    case CameraState.NoCameraSelected:
                    case CameraState.ConnectionOpened:
                    case CameraState.AcqStarted:
                        return false;
                    default:
                        return false;
                }
            }
        }

        /// <summary>
        /// Доступность старта сбора кадров
        /// </summary>
        public bool StartEnabled
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.ConnectionOpened:
                        return true;
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                    case CameraState.AcqStarted:
                        return false;
                    default:
                        return false;
                }
            }
        }

        /// <summary>
        /// Доступность остановки сбора кадров
        /// </summary>
        public bool StopEnabled
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                    case CameraState.ConnectionOpened:
                        return false;
                    case CameraState.AcqStarted:
                        return true;
                    default:
                        return false;
                }
            }
        }

        /// <summary>
        /// Доступность закрытия соединения с камерой
        /// </summary>
        public bool CloseEnabled
        {
            get
            {
                switch (CurrentState)
                {
                    case CameraState.ConnectionOpened:
                        return true;
                    case CameraState.NoCameraSelected:
                    case CameraState.Offline:
                    case CameraState.AcqStarted:
                        return false;
                    default:
                        return false;
                }
            }
        }
    }
}
