﻿using FiringCSWin.BaseServices;
using FiringCSWin.Models;
using FiringCSWin.MVVMBase;
using FiringCSWin.Services;
using System.Windows.Input;

namespace FiringCSWin.ViewModels
{
    /// <summary>
    /// ViewModel для окна ручного режима
    /// </summary>
    public class ManualModeViewModel : CommAvailViewModel
    {
        // реализация свойств
        private RelayCommand<object> _saveConfigCommand;    
        private RelayCommand<object> _alarmCheckCommand;

        // службы
        private IErrorService ErrorService;

        private IAlarmService AlarmService { get; set; }

        /// <summary>
        /// Команда сохранения файла параметров
        /// </summary>
        public ICommand SaveConfigCommand =>
            _saveConfigCommand ?? (_saveConfigCommand = new RelayCommand<object>((o) => ParamsService.SaveParameters()));

        /// <summary>
        /// Создание объекта ViewModel окна ручного управления движками
        /// </summary>
        /// <param name="paramsService">Объект службы параметров в конфиг-файле</param>
        /// <param name="commService">Объект службы работы с последовательным портом</param>
        /// <param name="errorService">Объект службы оповещения об ошибках и логирования</param>
        /// <param name="dlgService">Объект службы диалоговых окон</param>
        /// <param name="axisModels">Кортеж с моделями для "осей" шаговых двигателей</param>
        /// <param name="sensors">Модель датчиков</param>
        /// <param name="valvesModel">Модель клапанов и других исполнительных устройств</param>
        /// <param name="cassAlgModel">Модель для управления кассетированием</param>
        /// <param name="alarmService">Объект службы сообщения об авариях</param>
        /// <param name="removerModels">Модели, представляющие циклы сдува</param>
        public ManualModeViewModel(IParameters paramsService, ICommPollableService<ISensorsModel> commService, IErrorService errorService, IDialogService dlgService, ISensorsModel sensors,
            (IAxisModel td, IAxisModel dd, IAxisModel cd) axisModels, IValvesModel valvesModel, ICasettingAlgModel cassAlgModel, IAlarmService alarmService, (IRemoverModel,IRemoverModel,IRemoverModel) removerModels)
        {
            Sensors = sensors;
            Valves = valvesModel;
            CasetteAlg = cassAlgModel;

            Remover1 = removerModels.Item1;
            Remover2 = removerModels.Item2;
            Remover3 = removerModels.Item3;

            ErrorService = errorService;
            ParamsService = paramsService;
            DialogService = dlgService;
            AlarmService = alarmService;

            TransporterDrive = axisModels.td;
            DiscDrive = axisModels.dd;
            CasetteDrive = axisModels.cd;

            CommService = commService;

            InitParams();
        }      

        /// <summary>
        /// Проверка вывода аварии
        /// </summary>
        public ICommand AlarmCheckCommand =>
            _alarmCheckCommand ??
                (_alarmCheckCommand =
                    new RelayCommand<object>((o) => AlarmService.Alarm(1)));
    }
}