﻿using FiringCSWin.BaseServices;
using FiringCSWin.Models;
using FiringCSWin.MVVMBase;
using FiringCSWin.Services;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FiringCSWin.ViewModels
{
    /// <summary>
    /// Эту абстрактную VM'ку будем подключать к любым классами VM'ок
    /// которым требуется соединяться с нашей ардуиной
    /// </summary>
    public abstract class CommAvailViewModel : ModelBase
    {
        protected RelayCommand<object> _openTranspSpeedCalcCommand;
        protected RelayCommand<object> _openDiscSpeedCalcCommand;
        protected RelayCommand<object> _openCasetteDownSpeedCalcCommand;
        protected RelayCommand<object> _openCasetteUpSpeedCalcCommand;
        protected RelayCommand<object> _openTranspAccelCommand;
        protected RelayCommand<object> _openDiscAccelCommand;
        protected RelayCommand<object> _openMoveStepsCommand;
        protected RelayCommand<object> _openStepsByRowCommand;
        protected RelayCommand<object> _openFirstStepsByRowCommand;
        protected RelayCommand<object> _openPushInDelayCommand;
        protected RelayCommand<object> _openBeforePushInDelayCommand;
        protected RelayCommand<object> _openRowCountCommand;
        protected RelayCommand<object> _openRemoveDelayCalcCommand;
        protected RelayCommand<object> _openRemoveLengthCalcCommand;
        protected RelayCommand<object> _openRemover1DistCalcCommand;
        protected RelayCommand<object> _openRemover2DistCalcCommand;
        protected RelayCommand<object> _openRemover3DistCalcCommand;
        protected RelayCommand<object> _remove1CycleCommand;
        protected RelayCommand<object> _remove2CycleCommand;
        protected RelayCommand<object> _remove3CycleCommand;
        protected RelayCommand<object> _startTransporterCommand;
        protected RelayCommand<object> _stopTransporterCommand;
        protected RelayCommand<object> _startDiscCommand;
        protected RelayCommand<object> _stopDiscCommand;
        protected RelayCommand<object> _startDiscNTransCommand;
        protected RelayCommand<object> _stopDiscNTransCommand;
        protected RelayCommand<object> _startCasetteCommand;
        protected RelayCommand<object> _stopCasetteCommand;
        protected RelayCommand<object> _moveCasetteByCommand;
        protected RelayCommand<object> _enableCasetteReverseCommand;
        protected RelayCommand<object> _disableCasetteReverseCommand;
        protected RelayCommand<object> _enablePneumo1Command;
        protected RelayCommand<object> _disablePneumo1Command;
        protected RelayCommand<object> _enablePneumo2Command;
        protected RelayCommand<object> _disablePneumo2Command;
        protected RelayCommand<object> _enablePneumo3Command;
        protected RelayCommand<object> _disablePneumo3Command;
        protected RelayCommand<object> _enablePneumo4Command;
        protected RelayCommand<object> _disablePneumo4Command;
        protected RelayCommand<object> _enablePneumo5Command;
        protected RelayCommand<object> _disablePneumo5Command;
        protected RelayCommand<object> _startCasettingCommand;
        protected RelayCommand<object> _stopCasettingCommand;
        protected RelayCommand<object> _startRowMoveCommand;
        protected RelayCommand<object> _startPushInCommand;
        protected RelayCommand<object> _startNextRowCommand;
        protected RelayCommand<object> _startChangeCasetteCommand;
        protected RelayCommand<object> _zeroCounterCommand;

        // модели
        protected ISensorsModel _sensors;
        protected IRemoverModel _remover1;
        protected IRemoverModel _remover2;
        protected IRemoverModel _remover3;
        protected IAxisModel _transpDrive;
        protected IAxisModel _discDrive;
        protected IAxisModel _casetteDrive;
        protected IValvesModel _valves;
        protected ICasettingAlgModel _cassAlg;

        protected bool _gearTrainMoving;

        /// <summary>
        /// Модель датчиков и других опрашиваемых с платы величин
        /// </summary>
        public ISensorsModel Sensors
        {
            get => _sensors;
            set
            {
                _sensors = value;
                RaisePropertyChanged(nameof(Sensors));
            }
        }

        /// <summary>
        /// Модель, представляющая цикл сдува №1
        /// </summary>
        public IRemoverModel Remover1
        {
            get => _remover1;
            set
            {
                _remover1 = value;
                RaisePropertyChanged(nameof(Remover1));
            }
        }

        /// <summary>
        /// Модель, представляющая цикл сдува №2
        /// </summary>
        public IRemoverModel Remover2
        {
            get => _remover2;
            set
            {
                _remover2 = value;
                RaisePropertyChanged(nameof(Remover2));
            }
        }

        /// <summary>
        /// Модель, представляющая цикл сдува №3
        /// </summary>
        public IRemoverModel Remover3
        {
            get => _remover3;
            set
            {
                _remover3 = value;
                RaisePropertyChanged(nameof(Remover3));
            }
        }

        /// <summary>
        /// Модель привода транспортёра
        /// </summary>
        public IAxisModel TransporterDrive
        {
            get => _transpDrive;
            set
            {
                _transpDrive = value;
                RaisePropertyChanged(nameof(TransporterDrive));
            }
        }

        /// <summary>
        /// Модель привода диска оплавки
        /// </summary>
        public IAxisModel DiscDrive
        {
            get => _discDrive;
            set
            {
                _discDrive = value;
                RaisePropertyChanged(nameof(DiscDrive));
            }
        }

        /// <summary>
        /// Модель привода перемещения кассеты
        /// </summary>
        public IAxisModel CasetteDrive
        {
            get => _casetteDrive;
            set
            {
                _casetteDrive = value;
                RaisePropertyChanged(nameof(CasetteDrive));
            }
        }

        /// <summary>
        /// Модель клапанов и других исполнительных устройств
        /// </summary>
        public IValvesModel Valves
        {
            get => _valves;
            set
            {
                _valves = value;
                RaisePropertyChanged(nameof(Valves));
            }
        }

        /// <summary>
        /// Модель управления кассетированием
        /// </summary>
        public ICasettingAlgModel CasetteAlg
        {
            get => _cassAlg;
            set
            {
                _cassAlg = value;
                RaisePropertyChanged(nameof(CasetteAlg));
            }
        }

        // службы
        protected ICommPollableService<ISensorsModel> CommService;
        protected IParameters ParamsService;
        protected IDialogService DialogService;

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) скорости транспортёра
        /// </summary>
        public ICommand OpenTranspSpeedCalcCommand =>
            _openTranspSpeedCalcCommand ??
                (_openTranspSpeedCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Скорость транспортёра",
                            (s) =>
                            {
                                TransporterDrive.Speed = s;
                                ParamsService.TransporterSpeed = s;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) скорости вращения диска оплавки
        /// </summary>
        public ICommand OpenDiscSpeedCalcCommand =>
            _openDiscSpeedCalcCommand ??
                (_openDiscSpeedCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Скорость диска",
                            (s) =>
                            {
                                DiscDrive.Speed = s;
                                ParamsService.DiscSpeed = s;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) скорости кассеты вниз (смена рядов)
        /// </summary>
        public ICommand OpenCasetteDownSpeedCalcCommand =>
            _openCasetteDownSpeedCalcCommand ??
                (_openCasetteDownSpeedCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Скорость кассеты вниз",
                            (s) =>
                            {
                                CasetteDrive.Speed = s;
                                ParamsService.CasetteDownSpeed = s;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) скорости кассеты вверх (перемещение на исходную)
        /// </summary>
        public ICommand OpenCasetteUpSpeedCalcCommand =>
            _openCasetteUpSpeedCalcCommand ??
                (_openCasetteUpSpeedCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Скорость кассеты вверх",
                            (s) =>
                            {
                                CasetteDrive.ReverseSpeed = s;
                                ParamsService.CasetteUpSpeed = s;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) ускорения транспортёра
        /// </summary>
        public ICommand OpenTranspAccelCalcCommand =>
            _openTranspAccelCommand ??
                (_openTranspAccelCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Ускорение транспортёра",
                            (a) =>
                            {
                                TransporterDrive.Accel = a;
                                ParamsService.TransporterAccel = a;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) ускорения диска оплавки
        /// </summary>
        public ICommand OpenDiscAccelCalcCommand =>
            _openDiscAccelCommand ??
                (_openDiscAccelCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Ускорение диска оплавки",
                            (a) =>
                            {
                                DiscDrive.Accel = a;
                                ParamsService.DiscAccel = a;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) шагов на конкретное расстояние
        /// </summary>
        public ICommand OpenMoveStepsCalcCommand =>
            _openMoveStepsCommand ??
                (_openMoveStepsCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Шагов для движения кассеты",
                            (s) => CasetteDrive.MoveSteps = s)));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) шагов на ряд трубок (для автоматического кассетирования)
        /// </summary>
        public ICommand OpenStepsByRowCalcCommand =>
            _openStepsByRowCommand ??
                (_openStepsByRowCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Шагов кассеты на ряд трубок",
                            (s) =>
                            {
                                CasetteAlg.StepsPerRow = s;
                                ParamsService.CasettingStepsByRow = s;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) шагов на первый ряд трубок (для автоматического кассетирования)
        /// </summary>
        public ICommand OpenFirstStepsByRowCalcCommand =>
            _openFirstStepsByRowCommand ??
                (_openFirstStepsByRowCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Шагов кассеты в первом ряду",
                            (s) =>
                            {
                                CasetteAlg.FirstStepsPerRow = s;
                                ParamsService.CasettingFirstStepsByRow = s;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) задержки пневмоцилиндра при загрузке ряда трубок
        /// в кассету (для автоматического кассетирования)
        /// </summary>
        public ICommand OpenPushInDelayCalcCommand =>
            _openPushInDelayCommand ??
                (_openPushInDelayCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Задержка пневмоцилиндра загрузки в кассету",
                            (d) =>
                            {
                                CasetteAlg.PushInDelay = d;
                                ParamsService.CasettingPushDelay = d;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) задержки перед пневмоцилиндром загрузки ряда
        /// трубок в  кассету (для автоматического кассетирования)
        /// </summary>
        public ICommand OpenBeforePushInDelayCalcCommand =>
            _openBeforePushInDelayCommand ??
                (_openBeforePushInDelayCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Задержка перед загрузкой в кассету",
                            (d) =>
                            {
                                CasetteAlg.BeforePushInDelay = d;
                                ParamsService.CasettingBeforePushInDelay = d;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) количества рядов трубок в кассете
        /// (для автоматического кассетирования)
        /// </summary>
        public ICommand OpenRowCountCalcCommand =>
            _openRowCountCommand ??
                (_openRowCountCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Количество рядов трубок в кассете",
                            (r) =>
                            {
                                CasetteAlg.RowCount = r;
                                ParamsService.CasettingRowCount = r;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) задержки перед сдувом в
        /// цикле сдува (в миллисекундах)
        /// </summary>
        public ICommand OpenRemoverDelayCalcCommand =>
            _openRemoveDelayCalcCommand ??
                (_openRemoveDelayCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Задержка перед сдувом (мс)",
                            (d) =>
                            {
                                Remover1.RemoverDelay = d;
                                Remover2.RemoverDelay = d;
                                Remover3.RemoverDelay = d;
                                ParamsService.RemoverDelay = d;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) длины импульса
        /// сдува (в миллисекундах)
        /// </summary>
        public ICommand OpenRemoverLengthCalcCommand =>
            _openRemoveLengthCalcCommand ??
                (_openRemoveLengthCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Длина импульса сдува (мс)",
                            (l) =>
                            {
                                Remover1.RemoverLength = l;
                                Remover2.RemoverLength = l;
                                Remover3.RemoverLength = l;
                                ParamsService.RemoverLength = l;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) расстояния от камеры 1
        /// до сдува (в ячейках ремня)
        /// </summary>
        public ICommand OpenRemover1DistCalcCommand =>
            _openRemover1DistCalcCommand ??
                (_openRemover1DistCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Расстояние от сдува до камеры 1",
                            (d) =>
                            {
                                Remover1.RemoverDist = d;
                                ParamsService.RemoverDist1 = d;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) расстояния от камеры 1
        /// до сдува (в ячейках ремня)
        /// </summary>
        public ICommand OpenRemover2DistCalcCommand =>
            _openRemover2DistCalcCommand ??
                (_openRemover2DistCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Расстояние от сдува до камеры 2",
                            (d) =>
                            {
                                Remover2.RemoverDist = d;
                                ParamsService.RemoverDist2 = d;
                            })));

        /// <summary>
        /// Команда открытия окна ввода (калькулятор) расстояния от камеры 3
        /// до сдува (в ячейках ремня)
        /// </summary>
        public ICommand OpenRemover3DistCalcCommand =>
            _openRemover3DistCalcCommand ??
                (_openRemover3DistCalcCommand =
                    new RelayCommand<object>((o) =>
                        DialogService.SpawnUshortCalcDialog("Расстояние от сдува до камеры 3",
                            (d) =>
                            {
                                Remover3.RemoverDist = d;
                                ParamsService.RemoverDist3 = d;
                            })));

        /// <summary>
        /// Команда запуска транспортёра
        /// </summary>
        public ICommand StartTransporterCommand =>
            _startTransporterCommand ??
                (_startTransporterCommand =
                    new RelayCommand<object>((o) => TransporterDrive.Start()));

        /// <summary>
        /// Команда остановки транспортёра
        /// </summary>
        public ICommand StopTransporterCommand =>
            _stopTransporterCommand ??
                (_stopTransporterCommand =
                    new RelayCommand<object>((o) => TransporterDrive.Stop()));

        /// <summary>
        /// Команда запуска вращения диска оплавки
        /// </summary>
        public ICommand StartDiscCommand =>
            _startDiscCommand ??
                (_startDiscCommand =
                    new RelayCommand<object>((o) => DiscDrive.Start()));

        /// <summary>
        /// Команда остановки вращения диска оплавки
        /// </summary>
        public ICommand StopDiscCommand =>
            _stopDiscCommand ??
                (_stopDiscCommand =
                    new RelayCommand<object>((o) => DiscDrive.Stop()));

        /// <summary>
        /// Команда запуска движения кассеты
        /// </summary>
        public ICommand StartCasetteCommand =>
            _startCasetteCommand ??
                (_startCasetteCommand =
                    new RelayCommand<object>((o) => CasetteDrive.Start()));

        /// <summary>
        /// Команда остановки движения кассеты
        /// </summary>
        public ICommand StopCasetteCommand =>
            _stopCasetteCommand ??
                (_stopCasetteCommand =
                    new RelayCommand<object>((o) => CasetteDrive.Stop()));

        /// <summary>
        /// Включить движение кассеты в обратную сторону
        /// </summary>
        public ICommand EnableCasetteReverseCommand =>
            _enableCasetteReverseCommand ??
                (_enableCasetteReverseCommand =
                    new RelayCommand<object>((o) => CasetteDrive.SetReverseDirection()));

        /// <summary>
        /// Отключить движение кассеты в обратную сторону
        /// </summary>
        public ICommand DisableCasetteReverseCommand =>
            _disableCasetteReverseCommand ??
                (_disableCasetteReverseCommand =
                    new RelayCommand<object>((o) => CasetteDrive.SetStraightDirection()));

        /// <summary>
        /// Движение кассеты на фиксированное расстояние
        /// </summary>
        public ICommand MoveCasetteByCommand =>
            _moveCasetteByCommand ??
                (_moveCasetteByCommand =
                    new RelayCommand<object>((o) => CasetteDrive.MoveBy()));

        /// <summary>
        /// Команда включения клапана №1
        /// </summary>
        public ICommand EnablePneumo1Command =>
            _enablePneumo1Command ??
                (_enablePneumo1Command =
                    new RelayCommand<object>((o) => Valves.Valve1On()));

        /// <summary>
        /// Команда отключения клапана №1
        /// </summary>
        public ICommand DisablePneumo1Command =>
            _disablePneumo1Command ??
                (_disablePneumo1Command =
                    new RelayCommand<object>((o) => Valves.Valve1Off()));

        /// <summary>
        /// Команда включения клапана №2
        /// </summary>
        public ICommand EnablePneumo2Command =>
            _enablePneumo2Command ??
                (_enablePneumo2Command =
                    new RelayCommand<object>((o) => Valves.Valve2On()));

        /// <summary>
        /// Команда отключения клапана №2
        /// </summary>
        public ICommand DisablePneumo2Command =>
            _disablePneumo2Command ??
                (_disablePneumo2Command =
                    new RelayCommand<object>((o) => Valves.Valve2Off()));

        /// <summary>
        /// Команда включения клапана №3
        /// </summary>
        public ICommand EnablePneumo3Command =>
            _enablePneumo3Command ??
                (_enablePneumo3Command =
                    new RelayCommand<object>((o) => Valves.Valve3On()));

        /// <summary>
        /// Команда отключения клапана №3
        /// </summary>
        public ICommand DisablePneumo3Command =>
            _disablePneumo3Command ??
                (_disablePneumo3Command =
                    new RelayCommand<object>((o) => Valves.Valve3Off()));

        /// <summary>
        /// Команда включения клапана №4
        /// </summary>
        public ICommand EnablePneumo4Command =>
            _enablePneumo4Command ??
                (_enablePneumo4Command =
                    new RelayCommand<object>((o) => Valves.Valve4On()));

        /// <summary>
        /// Команда отключения клапана №4
        /// </summary>
        public ICommand DisablePneumo4Command =>
            _disablePneumo4Command ??
                (_disablePneumo4Command =
                    new RelayCommand<object>((o) => Valves.Valve4Off()));

        /// <summary>
        /// Команда включения клапана №5
        /// </summary>
        public ICommand EnablePneumo5Command =>
            _enablePneumo5Command ??
                (_enablePneumo5Command =
                    new RelayCommand<object>((o) => Valves.Valve5On()));

        /// <summary>
        /// Команда отключения клапана №5
        /// </summary>
        public ICommand DisablePneumo5Command =>
            _disablePneumo5Command ??
                (_disablePneumo5Command =
                    new RelayCommand<object>((o) => Valves.Valve5Off()));

        public ICommand StartCasettingCommand =>
            _startCasettingCommand ??
                (_startCasettingCommand =
                    new RelayCommand<object>((o) => CasetteAlg.StartCasetting()));

        /// <summary>
        /// Команда остановки подпрограмм автоматического кассетирования
        /// </summary>
        public ICommand StopCasettingCommand =>
            _stopCasettingCommand ??
                (_stopCasettingCommand =
                    new RelayCommand<object>((o) => CasetteAlg.StopCasetting()));

        /// <summary>
        /// Команда запуска подпрограммы "Перемещение ряда изделий"
        /// </summary>
        public ICommand StartRowMoveCommand =>
            _startRowMoveCommand ??
                (_startRowMoveCommand =
                    new RelayCommand<object>((o) => CasetteAlg.StartRowMove()));

        /// <summary>
        /// Команда запуска подпрограммы "Загрузка в кассету"
        /// </summary>
        public ICommand StartPushInCommand =>
            _startPushInCommand ??
                (_startPushInCommand =
                    new RelayCommand<object>((o) => CasetteAlg.StartPushIn()));

        /// <summary>
        /// Команда запуска подпрограммы "Смена ряда"
        /// </summary>
        public ICommand StartNextRowCommand =>
            _startNextRowCommand ??
                (_startNextRowCommand =
                    new RelayCommand<object>((o) => CasetteAlg.StartNextRow()));

        /// <summary>
        /// Команда запуска подпрограммы "Смена кассеты"
        /// </summary>
        public ICommand StartCasetteChangeCommand =>
            _startChangeCasetteCommand ??
                (_startChangeCasetteCommand =
                    new RelayCommand<object>((o) => CasetteAlg.StartChangeCasette()));

        /// <summary>
        /// Команда очистки счётчика рядов в кассете
        /// </summary>
        public ICommand ZeroCounterCommand =>
            _zeroCounterCommand ??
                (_zeroCounterCommand =
                    new RelayCommand<object>((o) => CasetteAlg.ZeroCounter()));

        /// <summary>
        /// Команда одновременного запуска транспортёра и диска
        /// </summary>
        public ICommand StartDiscNTransCommand =>
            _startDiscNTransCommand ??
                (_startDiscNTransCommand =
                    new RelayCommand<object>((o) =>
                    {
                        GeartrainMoving = true;
                        TransporterDrive.Start();
                        DiscDrive.Start();
                    }));

        /// <summary>
        /// Команда одновременной остановки транспортёра и диска
        /// </summary>
        public ICommand StopDiscNTransCommand =>
            _stopDiscNTransCommand ??
                (_stopDiscNTransCommand =
                    new RelayCommand<object>((o) =>
                    {
                        TransporterDrive.Stop();
                        DiscDrive.Stop();
                        GeartrainMoving = false;
                    }));

        /// <summary>
        /// Команда старта цикла сдува 1
        /// </summary>
        public ICommand Remover1CycleCommand =>
            _remove1CycleCommand ??
                (_remove1CycleCommand =
                    new RelayCommand<object>((o) =>
                    {
                        Remover1.Start();
                    }));

        /// <summary>
        /// Команда старта цикла сдува 2
        /// </summary>
        public ICommand Remover2CycleCommand =>
            _remove2CycleCommand ??
                (_remove2CycleCommand =
                    new RelayCommand<object>((o) =>
                    {
                        Remover2.Start();
                    }));

        /// <summary>
        /// Команда старта цикла сдува 3
        /// </summary>
        public ICommand Remover3CycleCommand =>
            _remove3CycleCommand ??
                (_remove3CycleCommand =
                    new RelayCommand<object>((o) =>
                    {
                        Remover3.Start();
                    }));

        protected void InitParams()
        {
            // загруженные из конфига параметры передаём в плату
            TransporterDrive.Speed = ParamsService.TransporterSpeed;
            DiscDrive.Speed = ParamsService.DiscSpeed;
            CasetteDrive.Speed = ParamsService.CasetteDownSpeed;
            CasetteDrive.ReverseSpeed = ParamsService.CasetteUpSpeed;
            TransporterDrive.Accel = ParamsService.TransporterAccel;
            DiscDrive.Accel = ParamsService.DiscAccel;
            CasetteAlg.StepsPerRow = ParamsService.CasettingStepsByRow;
            CasetteAlg.FirstStepsPerRow = ParamsService.CasettingFirstStepsByRow;
            CasetteAlg.PushInDelay = ParamsService.CasettingPushDelay;
            CasetteAlg.RowCount = ParamsService.CasettingRowCount;
            CasetteAlg.BeforePushInDelay = ParamsService.CasettingBeforePushInDelay;
            Remover1.RemoverDelay = ParamsService.RemoverDelay;
            Remover1.RemoverLength = ParamsService.RemoverLength;
            Remover2.RemoverDelay = ParamsService.RemoverDelay;
            Remover2.RemoverLength = ParamsService.RemoverLength;
            Remover3.RemoverDelay = ParamsService.RemoverDelay;
            Remover3.RemoverLength = ParamsService.RemoverLength;
            Remover1.RemoverDist = ParamsService.RemoverDist1;
            Remover2.RemoverDist = ParamsService.RemoverDist2;
            Remover3.RemoverDist = ParamsService.RemoverDist3;
        }

        /// <summary>
        /// Флаг для индикации нажатия кнопки "ДСК"
        /// </summary>
        public bool GeartrainMoving
        {
            get => _gearTrainMoving;
            set
            {
                _gearTrainMoving = value;
                RaisePropertyChanged(nameof(GeartrainMoving));
            }
        }
    }
}
