﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;

namespace FiringCSWin.MVVMBase
{
    public class ModelBase : INotifyPropertyChanged, IDataErrorInfo
    {
        protected Dictionary<string, string> validationErrors = new Dictionary<string, string>();

        protected SynchronizationContext GuiContext = SynchronizationContext.Current;

        public virtual void Refresh()
        {
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public string this[string columnName] => validationErrors.ContainsKey(columnName) ? validationErrors[columnName] : null;

        public bool IsValid => !validationErrors.Values.Any(x => !string.IsNullOrEmpty(x));

        public string Error => "";
    }
}