﻿using FiringCSWin.BaseServices;
using FiringCSWin.Views;
using System.Windows;
using System.Linq;

namespace FiringCSWin.Services
{
    public interface IDialogService : IBaseDialogService
    {
        void SpawnManualWindow();

        void SpawnSettingsWindow();
    }

    public class DialogService : BaseDialogService, IDialogService
    {
        /// <summary>
        /// Отобразить окно ручного режима
        /// </summary>
        public void SpawnManualWindow()
        {
            var wnd = Application.Current.Windows.OfType<ManualModeWindow>();
            var ManualWindow = wnd.Count() > 0 ? wnd.ElementAt(0) : new ManualModeWindow();
            ManualWindow.Show();
            ManualWindow.Activate();
        }

        /// <summary>
        /// Отобразить окно настроек
        /// </summary>
        public void SpawnSettingsWindow()
        {
            var wnd = Application.Current.Windows.OfType<SettingsWindow>();
            var settingsWindow = wnd.Count() > 0 ? wnd.ElementAt(0) : new SettingsWindow();
            settingsWindow.Show();
            settingsWindow.Activate();
        }
    }
}
