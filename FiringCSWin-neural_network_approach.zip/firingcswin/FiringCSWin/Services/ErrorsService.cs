﻿using FiringCSWin.BaseServices;
using System.IO;
using System.Threading;

namespace FiringCSWin.Services
{
    public interface IErrorService
    {
        void RegisterErrors();

        void Report(uint number);

        void Report(string message, ErrorNotifierService.E_LEVEL level);

        Stream LogStream { get; }
    }

    public class ErrorsService : ErrorNotifierService, IErrorService
    {
        public const uint ERROR_BAUDRATE_WRONG_FORMAT = 1;

        Mutex ReportSync = new Mutex();

        /// <summary>
        /// Имя файла лога
        /// </summary>
        public string LogFileName { get; set; } = "log.txt";

        /// <summary>
        /// Ошибка форматирования параметра скорости опроса (baudrate)
        /// </summary>
        public readonly static ErrorObject ErrorBaudrateWrongFormat =
            new ErrorObject(ERROR_BAUDRATE_WRONG_FORMAT, "Скорость опроса последовательного порта задана в неверном формате." +
                " Это должно быть положительное целое число.", E_LEVEL.Error, 60000);

        /// <summary>
        /// Объект неизвестной ошибки
        /// </summary>
        public readonly static ErrorObject UnknownError = new ErrorObject(ERROR_UNKNOWN, "Неизвестная ошибка.", E_LEVEL.Fatal, 60000);

        /// <summary>
        /// Регистрация сообщений об ошибках в системе
        /// </summary>
        public void RegisterErrors()
        {
            var arrayOfErrors = new ErrorObject[]
            {
                ErrorBaudrateWrongFormat
            };

            foreach (var error in arrayOfErrors) Register(error);
        }

        /// <summary>
        /// Оповещение о незарегистрированной ошибке
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="level"></param>
        public void Report(string msg, E_LEVEL level)
        {
            if (ReportSync.WaitOne(5000))
            {
                // поиск, среди зарегистрированных с таких же текстом
                if (!ErrorDictionaryContainsMessage(msg, out uint number))
                {
                    // если нет то регистрируем с каким-нибудь не использованным номером
                    number = UnoccupiedNumber();
                    Register(new ErrorObject(number, msg, level, 60000));
                }

                Report(number);
                ReportSync.ReleaseMutex();
            }
        }

        public ErrorsService(IBaseDialogService dialogService) : base(dialogService, UnknownError)
        {
            LogStream = new FileStream(LogFileName, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
            RegisterErrors();
        }

        ~ErrorsService()
        {
            LogStream.Close();
        }
    }
}