﻿using FiringCSWin.Models;

namespace FiringCSWin.Services
{
    public enum TubeDataCamera { HeadUp, Side1, Side2 };

    public delegate void TubeAddedEventHandler(TubeModel tube);
    public delegate void TubeRemovedEventHandler(TubeModel tube);
    public delegate void TubeModifyEventHandler(TubeModel tube);

    public interface ITubeManager
    {
        event TubeAddedEventHandler BadTubeAdded;
        event TubeAddedEventHandler GoodTubeAdded;

        void NewTubeByLength(double width, double min, double max);

        void NewTubeByDiams(TubeDataCamera camera, double outerdiam, double outermin, double outermax, double innerdiam, double innermin, double innermax);
    }

    public class TubeManager : ITubeManager
    {
        ulong CurrentID;

        public event TubeAddedEventHandler BadTubeAdded;
        public event TubeAddedEventHandler GoodTubeAdded;

        public void NewTubeByLength(double length, double min, double max)
        {
            if ((length >= min) && (length <= max))
            {
                NewGoodTube(TubeDataCamera.HeadUp, 0.0, 0.0, length);
            }
            else NewBadTube(TubeDataCamera.HeadUp, 0.0, 0.0, length, TubeModel.DumpedByLength);
        }

        public void NewTubeByDiams(TubeDataCamera camera, double outerdiam, double outermin, double outermax, double innerdiam, double innermin, double innermax)
        {
            int dumped = TubeModel.DumpedGood;

            if ((outerdiam < outermin) || (outerdiam > outermax)) dumped |= TubeModel.DumpedByOuterDiam;
            if ((innerdiam < innermin) || (innerdiam > innermax)) dumped |= TubeModel.DumpedByInnerDiam;

            if (dumped == TubeModel.DumpedGood) {
                NewGoodTube(camera, outerdiam, innerdiam, 0.0);
            } else NewBadTube(camera, outerdiam, innerdiam, 0.0, dumped);
        }

        public void NewBadTube(TubeDataCamera camera, double diam, double innerdiam, double length, int dumped)
        {
            var tube = new TubeModel()
            {
                CameraId = camera,
                Id = CurrentID++,
                Diameter = diam,
                InnerDiameter = innerdiam,
                Length = length,
                Dumped = dumped
            };

            BadTubeAdded?.Invoke(tube);
        }

        public void NewGoodTube(TubeDataCamera camera, double diam, double innerdiam, double length)
        {
            var tube = new TubeModel()
            {
                CameraId = camera,
                Id = CurrentID++,
                Diameter = diam,
                InnerDiameter = innerdiam,
                Length = length,
                Dumped = TubeModel.DumpedGood
            };

            GoodTubeAdded?.Invoke(tube);
        }

    }
}
