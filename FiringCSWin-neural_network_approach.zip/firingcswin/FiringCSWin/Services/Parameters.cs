﻿using FiringCSWin.BaseServices;
using System;
using System.Collections.Generic;

namespace FiringCSWin.Services
{
    public interface IParameters
    {
        /// <summary>
        /// Загрузка параметров из файла
        /// </summary>
        void LoadParameters();

        /// <summary>
        /// Символическое имя последовательного порта
        /// </summary>
        string ComPortName { get; set; }

        /// <summary>
        /// Скорость обмена по последовательному порту
        /// </summary>
        int Baudrate { get; set; }

        /// <summary>
        /// Сохраняемая скорость транспортёра
        /// </summary>
        ushort TransporterSpeed { get; set; }

        /// <summary>
        /// Сохраняемая скорость вращения диска оплавки
        /// </summary>
        ushort DiscSpeed { get; set; }

        /// <summary>
        /// Сохраняемая скорость движения кассеты вниз
        /// </summary>
        ushort CasetteDownSpeed { get; set; }

        /// <summary>
        /// Сохраняемая скорость движения кассеты вверх
        /// </summary>
        ushort CasetteUpSpeed { get; set; }

        /// <summary>
        /// Разгон транспортёра
        /// </summary>
        ushort TransporterAccel { get; set; }

        /// <summary>
        /// Разгон диска оплавки
        /// </summary>
        ushort DiscAccel { get; set; }

        /// <summary>
        /// Задержка цикла сдува в миллисекундах 
        /// </summary>
        ushort RemoverDelay { get; set; }

        /// <summary>
        /// Длина сигнала сдува в цикле в миллисекундах
        /// </summary>
        ushort RemoverLength { get; set; }

        /// <summary>
        /// Расстояние от камеры 1 до сдува в ячейках ремня
        /// </summary>
        ushort RemoverDist1 { get; set; }

        /// <summary>
        /// Расстояние от камеры 2 до сдува в ячейках ремня
        /// </summary>
        ushort RemoverDist2 { get; set; }

        /// <summary>
        /// Расстояние от камеры 3 до сдува в ячейках ремня
        /// </summary>
        ushort RemoverDist3 { get; set; }

        /// <summary>
        /// Количество шагов на ряд при автоматическом кассетировании
        /// </summary>
        ushort CasettingStepsByRow { get; set; }

        /// <summary>
        /// Количество шагов на первый ряд при автоматическом кассетировании
        /// </summary>
        ushort CasettingFirstStepsByRow { get; set; }

        /// <summary>
        /// Задержка пневмоцилиндра загрузки в кассету при автоматическом кассетировании
        /// </summary>
        ushort CasettingPushDelay { get; set; }

        /// <summary>
        /// Задержка пневмоцилиндра перед загрузкой в кассету при автоматическом кассетировании
        /// </summary>
        ushort CasettingBeforePushInDelay { get; set; }

        /// <summary>
        /// Количество рядов в кассете при автоматическом кассетировании
        /// </summary>
        ushort CasettingRowCount { get; set; }

        /// <summary>
        /// Серийник последней используемой камеры (камера верх)
        /// </summary>
        string LastCameraSNHeadUp { get; set; }

        /// <summary>
        /// Серийник последней используемой камеры (камера сбоку 1)
        /// </summary>
        string LastCameraSNSide1 { get; set; }

        /// <summary>
        /// Серийник последней используемой камеры (камера сбоку 2)
        /// </summary>
        string LastCameraSNSide2 { get; set; }

        /// <summary>
        /// Последняя используемая экспозиция (камера сверху)
        /// </summary>
        float LastExposureHeadUp { get; set; }

        /// <summary>
        /// Последняя используемая экспозиция (камера сбоку 1)
        /// </summary>
        float LastExposureSide1 { get; set; }

        /// <summary>
        /// Последняя используемая экспозиция (камера сбоку 2)
        /// </summary>
        float LastExposureSide2 { get; set; }

        /// <summary>
        /// Последнее число количества кадров для сохранения (камера верх)
        /// </summary>
        int LastNSaveFramesHeadUp { get; set; }

        /// <summary>
        /// Последнее число количества кадров для сохранения (камера сбоку 1)
        /// </summary>
        int LastNSaveFramesSide1 { get; set; }

        /// <summary>
        /// Последнее число количества кадров для сохранения (камера сбоку 2)
        /// </summary>
        int LastNSaveFramesSide2 { get; set; }

        /// <summary>
        /// Последнее значение порога
        /// </summary>
        byte LastThreshold { get; set; }

        /// <summary>
        /// Последнее значение порога бинаризации для расчёта диаметров камера сбоку 1
        /// </summary>
        double LastSide1Threshold { get; set; }

        /// <summary>
        /// Последнее значение порога бинаризации для расчёта диаметров камера сбоку 2
        /// </summary>
        double LastSide2Threshold { get; set; }

        /// <summary>
        /// Последнее значение для порога Canny камера сбоку 1
        /// </summary>
        double LastCannyThresholdSide1 { get; set; }

        /// <summary>
        /// Последнее значение для порога Canny  камера сбоку 2
        /// </summary>
        double LastCannyThresholdSide2 { get; set; }

        /// <summary>
        /// Последнее значение для величины коррекции при расчёте по площади камера сбоку 1
        /// </summary>
        double LastAreaCalcCorrectionSide1 { get; set; }

        /// <summary>
        /// Последнее значение для величины коррекции при расчёте по площади камера сбоку 2
        /// </summary>
        double LastAreaCalcCorrectionSide2 { get; set; }

        /// <summary>
        /// Минимальная длина эллипса для расчёта диаметров камера сбоку 1
        /// </summary>
        double MinEllipseLenSide1 { get; set; }

        /// <summary>
        /// Минимальная длина эллипса для расчёта диаметров камера сбоку 2
        /// </summary>
        double MinEllipseLenSide2 { get; set; }
        
        /// <summary>
        /// Верхняя ордината региона интереса (камера верх)
        /// </summary>
        int LastROITopHeadUp { get; set; }

        /// <summary>
        /// Верхняя ордината региона интереса (камера сбоку 1)
        /// </summary>
        int LastROITopSide1 { get; set; }

        /// <summary>
        /// Верхняя ордината региона интереса (камера сбоку 2)
        /// </summary>
        int LastROITopSide2 { get; set; }

        /// <summary>
        /// Нижняя ордината региона интереса (камера верх)
        /// </summary>
        int LastROIBottomHeadUp { get; set; }

        /// <summary>
        /// Нижняя ордината региона интереса (камера сбоку 1)
        /// </summary>
        int LastROIBottomSide1 { get; set; }

        /// <summary>
        /// Нижняя ордината региона интереса (камера сбоку 2)
        /// </summary>
        int LastROIBottomSide2 { get; set; }

        /// <summary>
        /// Левая абсцисса региона интереса (камера сбоку 1)
        /// </summary>
        int LastROILeftSide1 { get; set; }

        /// <summary>
        /// Левая абсцисса региона интереса (Камера сбоку 2)
        /// </summary>
        int LastROILeftSide2 { get; set; }

        /// <summary>
        /// Правая абсцисса региона интереса (камера сбоку 1)
        /// </summary>
        int LastROIRightSide1 { get; set; }

        /// <summary>
        /// Правая абсцисса региона интереса (камера сбоку 2)
        /// </summary>
        int LastROIRightSide2 { get; set; }

        /// <summary>
        /// Х координата левой точки ребра ремня
        /// </summary>
        int BeltLeftPointX { get; set; }

        /// <summary>
        /// X координата правой точки ребра ремня
        /// </summary>
        int BeltRightPointX { get; set; }

        /// <summary>
        /// Коэффициент перевода в миллиметры (камера верх)
        /// </summary>
        double RefMillimetersHeadUp { get; set; }

        /// <summary>
        /// Коэффициент перевода в миллиметры (камера сбоку 1)
        /// </summary>
        double RefMillimetersSide1 { get; set; }

        /// <summary>
        /// Коэффициент перевода в миллиметры (камера сбоку 2)
        /// </summary>
        double RefMillimetersSide2 { get; set; }

        /// <summary>
        /// Максимальная длина трубки
        /// </summary>
        double MaxTubeLength { get; set; }

        /// <summary>
        /// Минимальная длина трубки
        /// </summary>
        double MinTubeLength { get; set; }

        /// <summary>
        /// Максимальный внешний диаметр трубки с камеры 1
        /// </summary>
        double MaxOuterDiamSide1 { get; set; }

        /// <summary>
        /// Минимальные внешний диаметр трубки с камеры 1
        /// </summary>
        double MinOuterDiamSide1 { get; set; }

        /// <summary>
        /// Максимальный внешний диаметр трубки с камеры 2
        /// </summary>
        double MaxOuterDiamSide2 { get; set; }

        /// <summary>
        /// Минимальный внешний диаметр трубки с камеры 2
        /// </summary>
        double MinOuterDiamSide2 { get; set; }

        /// <summary>
        /// Максимальный внутренний диаметр трубки с камеры 1
        /// </summary>
        double MaxInnerDiamSide1 { get; set; }

        /// <summary>
        /// Минимальный внутренний диаметр трубки с камеры 1
        /// </summary>
        double MinInnerDiamSide1 { get; set; }

        /// <summary>
        /// Максимальный внутренний диаметр трубки с камеры 2
        /// </summary>
        double MaxInnerDiamSide2 { get; set; }

        /// <summary>
        /// Минимальный внутренний диаметр трубки с камеры 2 
        /// </summary>
        double MinInnerDiamSide2 { get; set; }

        /// <summary>
        /// Путь к папке для сохранения картинок после классификации нейросетью
        /// </summary>
        string PredictionSavePath { get; set; }

        /// <summary>
        /// Сохранить файл с параметрами
        /// </summary>
        void SaveParameters();
    }

    public class Parameters : ConfigService, IParameters
    {
        private IErrorService ErrorService;

        private const string COMPORTNAME = "ComPortName";
        private const string BAUDRATE = "Baudrate";
        private const string TRANSPSPEED = "TransporterSpeed";
        private const string DISCSPEED = "DiscSpeed";
        private const string CASETTEDOWNSPEED = "CasetteDownSpeed";
        private const string CASETTEUPSPEED = "CasetteUpSpeed";
        private const string TRANSPACCEL = "TransporterAccel";
        private const string DISCACCEL = "DiscAccel";
        private const string REMOVERDELAY = "RemoverDelay";
        private const string REMOVERLENGTH = "RemoverLength";
        private const string CASETTINGSTEPSBYROW = "CasettingStepsByRow";
        private const string CASETTINGFIRSTSTEPSBYROW = "CasettingFirstStepsByRow";
        private const string CASETTINGPUSHDELAY = "CasettingPushDelay";
        private const string CASETTINGROWCOUNT = "CasettingRowCount";
        private const string CASETTINGBEFOREPUSHDELAY = "CasettingBeforePushInDelay";
        private const string LASTCAMERASNHEADUP = "LastCameraSNHeadUp";
        private const string LASTCAMERASNSIDE1 = "LastCameraSNSide1";
        private const string LASTCAMERASNSIDE2 = "LastCameraSNSide2";
        private const string LASTEXPOSUREHEADUP = "LastExposureHeadUp";
        private const string LASTEXPOSURESIDE1 = "LastExposureSide1";
        private const string LASTEXPOSURESIDE2 = "LastExposureSide2";
        private const string LASTSAVEFRAMESHEADUP = "LastSaveFramesHeadUp";
        private const string LASTSAVEFRAMESSIDE1 = "LastSaveFramesSide1";
        private const string LASTSAVEFRAMESSIDE2 = "LastSaveFramesSide2";
        private const string LASTTHRESHOLD = "LastThreshold";
        private const string LASTROITOPHEADUP = "LastROITopHeadUp";
        private const string LASTROITOPSIDE1 = "LastROITopSide1";
        private const string LASTROITOPSIDE2 = "LastROITopSide2";
        private const string LASTROIBOTTOMHEADUP = "LastROIBottomHeadUp";
        private const string LASTROIBOTTOMSIDE1 = "LastROIBottomSide1";
        private const string LASTROIBOTTOMSIDE2 = "LastROIBottomSide2";
        private const string LASTROILEFTSIDE1 = "LastROILeftSide1";
        private const string LASTROILEFTSIDE2 = "LastROILeftSide2";
        private const string LASTROIRIGHTSIDE1 = "LastROIRightSide1";
        private const string LASTROIRIGHTSIDE2 = "LastROIRightSide2";
        private const string BELTLEFTPOINTX = "BeltLeftPointX";
        private const string BELTRIGHTPOINTX = "BeltRightPointX";
        private const string REFMILLIMETERSHEADUP = "RefMillimetersHeadUp";
        private const string REFMILLIMETERSSIDE1 = "RefMillimetersSide1";
        private const string REFMILLIMETERSSIDE2 = "RefMillimetersSide2";
        private const string MAXTUBELENGTH = "MaxTubeLength";
        private const string MINTUBELENGTH = "MinTubeLength";
        private const string LASTSIDE1THRESHOLD = "LastSide1Threshold";
        private const string LASTSIDE2THRESHOLD = "LastSide2Threshold";
        private const string LASTCANNYTHRESHOLDSIDE1 = "LastCannyThresholdSide1";
        private const string LASTCANNYTHRESHOLDSIDE2 = "LastCannyThresholdSide2";
        private const string MINELLIPSELENSIDE1 = "MinEllipseLenSide1";
        private const string MINELLIPSELENSIDE2 = "MinEllipseLenSide2";
        private const string LASTAREACORRECTIONSIDE1 = "LastAreaCorrectionSide1";
        private const string LASTAREACORRECTIONSIDE2 = "LastAreaCorrectionSide2";
        private const string REMOVERDIST1 = "RemoverDist1";
        private const string REMOVERDIST2 = "RemoverDist2";
        private const string REMOVERDIST3 = "RemoverDist3";
        private const string MAXOUTERDIAM1 = "MaxOuterDiamSide1";
        private const string MINOUTERDIAM1 = "MinOuterDiamSide1";
        private const string MAXOUTERDIAM2 = "MaxOuterDiamSide2";
        private const string MINOUTERDIAM2 = "MinOuterDiamSide2";
        private const string MAXINNERDIAM1 = "MaxInnerDiamSide1";
        private const string MININNERDIAM1 = "MinInnerDiamSide1";
        private const string MAXINNERDIAM2 = "MaxInnerDiamSide2";
        private const string MININNERDIAM2 = "MinInnerDiamSide2";
        private const string PREDICTIONSAVEPATH = "PredictionSavePath";

        private const string DEFAULT_COMPORTNAME = "COM1";
        private const int DEFAULT_BAUDRATE = 57600;

        /// <summary>
        /// Получить числовой параметр
        /// </summary>
        /// <param name="paramKey">Ключ параметра</param>
        /// <param name="defaultValue">Значение по-умолчанию</param>
        /// <param name="formatErrorId">Id ошибки для службы сообщений об ошибках</param>
        /// <param name="errorService">Служба сообщений об ошибках</param>
        /// <typeparam name="T">Тип числа</typeparam>
        /// <returns>Значение параметра</returns>
        public T GetNonStringParam<T>(string paramKey, T defaultValue, uint formatErrorId) where T : IConvertible
        {
            T result = defaultValue;

            try
            {
                result = (T)Convert.ChangeType(this[paramKey], typeof(T));
            }
            catch (FormatException)
            {
                // подключение к службе вывода сообщений об ошибках
                ErrorService.Report(formatErrorId);
            }
            catch (KeyNotFoundException)
            {
                result = defaultValue;
            }

            return result;
        }

        /// <summary>
        /// Символическое имя последовательного порта
        /// </summary>
        public string ComPortName
        {
            get => this[COMPORTNAME];
            set => this[COMPORTNAME] = value;
        }

        /// <summary>
        /// Скорость обмена по последовательному порту
        /// </summary>
        public int Baudrate
        {
            get => GetNonStringParam(BAUDRATE, DEFAULT_BAUDRATE, ErrorsService.ERROR_BAUDRATE_WRONG_FORMAT);
            set => this[BAUDRATE] = value.ToString();
        }

        /// <summary>
        /// Сохраняемая скорость транспортёра
        /// </summary>
        public ushort TransporterSpeed
        {
            get => GetNonStringParam<ushort>(TRANSPSPEED, 0, 0);
            set => this[TRANSPSPEED] = value.ToString();
        }

        /// <summary>
        /// Сохраняемая скорость вращения диска оплавки
        /// </summary>
        public ushort DiscSpeed
        {
            get => GetNonStringParam<ushort>(DISCSPEED, 0, 0);
            set => this[DISCSPEED] = value.ToString();
        }

        /// <summary>
        /// Сохраняемая скорость движения кассеты вниз
        /// </summary>
        public ushort CasetteDownSpeed
        {
            get => GetNonStringParam<ushort>(CASETTEDOWNSPEED, 0, 0);
            set => this[CASETTEDOWNSPEED] = value.ToString();
        }

        /// <summary>
        /// Сохраняемая скорость движения кассеты вверх
        /// </summary>
        public ushort CasetteUpSpeed
        {
            get => GetNonStringParam<ushort>(CASETTEUPSPEED, 0, 0);
            set => this[CASETTEUPSPEED] = value.ToString();
        }

        /// <summary>
        /// Разгон транспортёра
        /// </summary>
        public ushort TransporterAccel
        {
            get => GetNonStringParam<ushort>(TRANSPACCEL, 0, 0);
            set => this[TRANSPACCEL] = value.ToString();
        }

        /// <summary>
        /// Разгон диска оплавки
        /// </summary>
        public ushort DiscAccel
        {
            get => GetNonStringParam<ushort>(DISCACCEL, 0, 0);
            set => this[DISCACCEL] = value.ToString();
        }

        /// <summary>
        /// Задержка цикла сдува в миллисекундах
        /// </summary>
        public ushort RemoverDelay
        {
            get => GetNonStringParam<ushort>(REMOVERDELAY, 1000, 0);
            set => this[REMOVERDELAY] = value.ToString();
        }

        /// <summary>
        /// Длина сигнала сдува в цикле в миллисекундах
        /// </summary>
        public ushort RemoverLength
        {
            get => GetNonStringParam<ushort>(REMOVERLENGTH, 500, 0);
            set => this[REMOVERLENGTH] = value.ToString();
        }

        /// <summary>
        /// Расстояние от сдува до камеры 1
        /// </summary>
        public ushort RemoverDist1
        {
            get => GetNonStringParam<ushort>(REMOVERDIST1, 12, 0);
            set => this[REMOVERDIST1] = value.ToString();
        }

        /// <summary>
        /// Расстояние от сдува до камеры 2
        /// </summary>
        public ushort RemoverDist2
        {
            get => GetNonStringParam<ushort>(REMOVERDIST2, 24, 0);
            set => this[REMOVERDIST2] = value.ToString();
        }

        /// <summary>
        /// Расстояние от сдува до камеры 3
        /// </summary>
        public ushort RemoverDist3
        {
            get => GetNonStringParam<ushort>(REMOVERDIST3, 40, 0);
            set => this[REMOVERDIST3] = value.ToString();
        }

        /// <summary>
        /// Количество шагов на ряд при автоматическом кассетировании
        /// </summary>
        public ushort CasettingStepsByRow
        {
            get => GetNonStringParam<ushort>(CASETTINGSTEPSBYROW, 0, 0);
            set => this[CASETTINGSTEPSBYROW] = value.ToString();
        }

        /// <summary>
        /// Количество шагов на первый ряд при автоматическом кассетировании
        /// </summary>
        public ushort CasettingFirstStepsByRow
        {
            get => GetNonStringParam<ushort>(CASETTINGFIRSTSTEPSBYROW, 0, 0);
            set => this[CASETTINGFIRSTSTEPSBYROW] = value.ToString();
        }

        /// <summary>
        /// Задержка пневмоцилиндра загрузки в кассету при автоматическом кассетировании
        /// </summary>
        public ushort CasettingPushDelay
        {
            get => GetNonStringParam<ushort>(CASETTINGPUSHDELAY, 0, 0);
            set => this[CASETTINGPUSHDELAY] = value.ToString();
        }

        /// <summary>
        /// Задержка пневмоцилиндра перед загрузкой в кассету при автоматическом кассетировании
        /// </summary>
        public ushort CasettingBeforePushInDelay
        {
            get => GetNonStringParam<ushort>(CASETTINGBEFOREPUSHDELAY, 0, 0);
            set => this[CASETTINGBEFOREPUSHDELAY] = value.ToString();
        }

        /// <summary>
        /// Количество рядов в кассете при автоматическом кассетировании
        /// </summary>
        public ushort CasettingRowCount
        {
            get => GetNonStringParam<ushort>(CASETTINGROWCOUNT, 0, 0);
            set => this[CASETTINGROWCOUNT] = value.ToString();
        }

        /// <summary>
        /// Серийник последней используемой камеры (сверху)
        /// </summary>
        public string LastCameraSNHeadUp
        {
            get => this[LASTCAMERASNHEADUP];
            set => this[LASTCAMERASNHEADUP] = value;
        }

        public string LastCameraSNSide1
        {
            get => this[LASTCAMERASNSIDE1];
            set => this[LASTCAMERASNSIDE1] = value;
        }

        public string LastCameraSNSide2
        {
            get => this[LASTCAMERASNSIDE2];
            set => this[LASTCAMERASNSIDE2] = value;
        }

        /// <summary>
        /// Последняя используемая экспозиция (камера сверху)
        /// </summary>
        public float LastExposureHeadUp
        {
            get => GetNonStringParam<float>(LASTEXPOSUREHEADUP, 20.0f, 0);
            set => this[LASTEXPOSUREHEADUP] = value.ToString("F1");
        }

        public float LastExposureSide1
        {
            get => GetNonStringParam<float>(LASTEXPOSURESIDE1, 20.0f, 0);
            set => this[LASTEXPOSURESIDE1] = value.ToString("F1");
        }

        public float LastExposureSide2
        {
            get => GetNonStringParam<float>(LASTEXPOSURESIDE2, 20.0f, 0);
            set => this[LASTEXPOSURESIDE2] = value.ToString("F1");
        }

        /// <summary>
        /// Последнее число количества кадров для сохранения (камера сверху)
        /// </summary>
        public int LastNSaveFramesHeadUp
        {
            get => GetNonStringParam<int>(LASTSAVEFRAMESHEADUP, 100, 0);
            set => this[LASTSAVEFRAMESHEADUP] = value.ToString();
        }

        public int LastNSaveFramesSide1
        {
            get => GetNonStringParam<int>(LASTSAVEFRAMESSIDE1, 100, 0);
            set => this[LASTSAVEFRAMESSIDE1] = value.ToString();
        }

        public int LastNSaveFramesSide2
        {
            get => GetNonStringParam<int>(LASTSAVEFRAMESSIDE2, 100, 0);
            set => this[LASTSAVEFRAMESSIDE2] = value.ToString();
        }

        /// <summary>
        /// Последнее значение порога
        /// </summary>
        public byte LastThreshold
        {
            get => GetNonStringParam<byte>(LASTTHRESHOLD, 128, 0);
            set => this[LASTTHRESHOLD] = value.ToString();
        }

        /// <summary>
        /// Верхняя ордината региона интереса (камера сверху)
        /// </summary>
        public int LastROITopHeadUp
        {
            get => GetNonStringParam(LASTROITOPHEADUP, 750, 0);
            set => this[LASTROITOPHEADUP] = value.ToString();
        }

        public int LastROITopSide1
        {
            get => GetNonStringParam(LASTROITOPSIDE1, 750, 0);
            set => this[LASTROITOPSIDE1] = value.ToString();
        }

        public int LastROITopSide2
        {
            get => GetNonStringParam(LASTROITOPSIDE2, 750, 0);
            set => this[LASTROITOPSIDE2] = value.ToString();
        }

        /// <summary>
        /// Нижняя ордината региона интереса (камера сверху)
        /// </summary>
        public int LastROIBottomHeadUp
        {
            get => GetNonStringParam(LASTROIBOTTOMHEADUP, 1800, 0);
            set => this[LASTROIBOTTOMHEADUP] = value.ToString();
        }

        public int LastROIBottomSide1
        {
            get => GetNonStringParam(LASTROIBOTTOMSIDE1, 1800, 0);
            set => this[LASTROIBOTTOMSIDE1] = value.ToString();
        }

        public int LastROIBottomSide2
        {
            get => GetNonStringParam(LASTROIBOTTOMSIDE2, 1800, 0);
            set => this[LASTROIBOTTOMSIDE2] = value.ToString();
        }

        public int LastROILeftSide1
        {
            get => GetNonStringParam(LASTROILEFTSIDE1, 0, 0);
            set => this[LASTROILEFTSIDE1] = value.ToString();
        }

        public int LastROILeftSide2
        {
            get => GetNonStringParam(LASTROILEFTSIDE2, 0, 0);
            set => this[LASTROILEFTSIDE2] = value.ToString();
        }

        public int LastROIRightSide1
        {
            get => GetNonStringParam(LASTROIRIGHTSIDE1, 2448, 0);
            set => this[LASTROIRIGHTSIDE1] = value.ToString();
        }

        public int LastROIRightSide2
        {
            get => GetNonStringParam(LASTROIRIGHTSIDE2, 2448, 0);
            set => this[LASTROIRIGHTSIDE2] = value.ToString();
        }

        /// <summary>
        /// Х координата левой точки ребра ремня
        /// </summary>
        public int BeltLeftPointX
        {
            get => GetNonStringParam(BELTLEFTPOINTX, 816, 0);
            set => this[BELTLEFTPOINTX] = value.ToString();
        }

        /// <summary>
        /// X координата правой точки ребра ремня
        /// </summary>
        public int BeltRightPointX
        {
            get => GetNonStringParam(BELTRIGHTPOINTX, 1632, 0);
            set => this[BELTRIGHTPOINTX] = value.ToString();
        }

        /// <summary>
        /// Коэфициент перевода в миллиметры (камера сверху)
        /// </summary>
        public double RefMillimetersHeadUp {
            get => GetNonStringParam(REFMILLIMETERSHEADUP, 1.0, 0);
            set => this[REFMILLIMETERSHEADUP] = value.ToString("F7");
        }

        public double RefMillimetersSide1
        {
            get => GetNonStringParam(REFMILLIMETERSSIDE1, 1.0, 0);
            set => this[REFMILLIMETERSSIDE1] = value.ToString("F7");
        }

        public double RefMillimetersSide2
        {
            get => GetNonStringParam(REFMILLIMETERSSIDE2, 1.0, 0);
            set => this[REFMILLIMETERSSIDE2] = value.ToString("F7");
        }

        /// <summary>
        /// Максимальная длина трубки
        /// </summary>
        public double MaxTubeLength {
            get => GetNonStringParam(MAXTUBELENGTH, 15.23, 0);
            set => this[MAXTUBELENGTH] = value.ToString("F3");
        }

        /// <summary>
        /// Минимальная длина трубки
        /// </summary>
        public double MinTubeLength {
            get => GetNonStringParam(MINTUBELENGTH, 15.02, 0);
            set => this[MINTUBELENGTH] = value.ToString("F3");
        }             
        
        public double MaxOuterDiamSide1
        {
            get => GetNonStringParam(MAXOUTERDIAM1, 2.25, 0);
            set => this[MAXOUTERDIAM1] = value.ToString("F2");
        }

        public double MinOuterDiamSide1
        {
            get => GetNonStringParam(MINOUTERDIAM1, 2.05, 0);
            set => this[MINOUTERDIAM1] = value.ToString("F2");
        }

        public double MaxOuterDiamSide2
        {
            get => GetNonStringParam(MAXOUTERDIAM2, 2.25, 0);
            set => this[MAXOUTERDIAM2] = value.ToString("F2");
        }

        public double MinOuterDiamSide2
        {
            get => GetNonStringParam(MINOUTERDIAM2, 2.05, 0);
            set => this[MINOUTERDIAM2] = value.ToString("F2");
        }

        public double MaxInnerDiamSide1
        {
            get => GetNonStringParam(MAXINNERDIAM1, 1.00, 0);
            set => this[MAXINNERDIAM1] = value.ToString("F2");
        }

        public double MinInnerDiamSide1
        {
            get => GetNonStringParam(MININNERDIAM1, 0.95, 0);
            set => this[MININNERDIAM1] = value.ToString("F2");
        }

        public double MaxInnerDiamSide2
        {
            get => GetNonStringParam(MAXINNERDIAM2, 1.00, 0);
            set => this[MAXINNERDIAM2] = value.ToString("F2");
        }

        public double MinInnerDiamSide2
        {
            get => GetNonStringParam(MININNERDIAM2, 0.95, 0);
            set => this[MININNERDIAM2] = value.ToString("F2");
        }

        public double LastSide1Threshold {
            get => GetNonStringParam(LASTSIDE1THRESHOLD, 50.0, 0);
            set => this[LASTSIDE1THRESHOLD] = value.ToString("F3");
        }

        public double LastSide2Threshold {
            get => GetNonStringParam(LASTSIDE2THRESHOLD, 50.0, 0);
            set => this[LASTSIDE2THRESHOLD] = value.ToString("F3");
        }

        public double LastCannyThresholdSide1 {
            get => GetNonStringParam(LASTCANNYTHRESHOLDSIDE1, 100.0, 0);
            set => this[LASTCANNYTHRESHOLDSIDE1] = value.ToString("F3");
        }

        public double LastCannyThresholdSide2 {
            get => GetNonStringParam(LASTCANNYTHRESHOLDSIDE2, 100.0, 0);
            set => this[LASTCANNYTHRESHOLDSIDE2] = value.ToString("F3");
        }

        public double LastAreaCalcCorrectionSide1
        {
            get => GetNonStringParam(LASTAREACORRECTIONSIDE1, 0.0, 0);
            set => this[LASTAREACORRECTIONSIDE1] = value.ToString("F3");
        }

        public double LastAreaCalcCorrectionSide2
        {
            get => GetNonStringParam(LASTAREACORRECTIONSIDE2, 0.0, 0);
            set => this[LASTAREACORRECTIONSIDE2] = value.ToString("F3");
        }

        public double MinEllipseLenSide1 {
            get => GetNonStringParam(MINELLIPSELENSIDE1, 500.0, 0);
            set => this[MINELLIPSELENSIDE1] = value.ToString("F3");
        }

        public double MinEllipseLenSide2 {
            get => GetNonStringParam(MINELLIPSELENSIDE2, 500.0, 0);
            set => this[MINELLIPSELENSIDE2] = value.ToString("F3");
        }

        public string PredictionSavePath
        {
            get => this[PREDICTIONSAVEPATH];
            set => this[PREDICTIONSAVEPATH] = value;
        }

        public Parameters(IErrorService errorService)
        {
            ErrorService = errorService;
        }

        /// <summary>
        /// Загрузка параметров из файла
        /// </summary>
        public void LoadParameters()
        {
            // добавляем параметры по-умолчанию
            // в случае отсутствия в папке с программой
            // файла config.ini, он будет создан с этими параметрами
            var initDict = new Dictionary<string, string>();
            initDict.Add(COMPORTNAME, DEFAULT_COMPORTNAME);
            initDict.Add(BAUDRATE, DEFAULT_BAUDRATE.ToString());
            initDict.Add(TRANSPSPEED, "0");
            initDict.Add(DISCSPEED, "0");
            initDict.Add(CASETTEDOWNSPEED, "0");
            initDict.Add(CASETTEUPSPEED, "0");
            initDict.Add(TRANSPACCEL, "0");
            initDict.Add(DISCACCEL, "0");
            initDict.Add(CASETTINGSTEPSBYROW, "0");
            initDict.Add(CASETTINGPUSHDELAY, "0");
            initDict.Add(CASETTINGROWCOUNT, "0");
            initDict.Add(LASTCAMERASNHEADUP, "");
            initDict.Add(LASTCAMERASNSIDE1, "");
            initDict.Add(LASTCAMERASNSIDE2, "");
            initDict.Add(LASTEXPOSUREHEADUP, "20,0");
            initDict.Add(LASTEXPOSURESIDE1, "20,0");
            initDict.Add(LASTEXPOSURESIDE2, "20,0");
            initDict.Add(LASTSAVEFRAMESHEADUP, "100");
            initDict.Add(LASTSAVEFRAMESSIDE1, "100");
            initDict.Add(LASTSAVEFRAMESSIDE2, "100");
            initDict.Add(LASTTHRESHOLD, "128");
            initDict.Add(LASTROITOPHEADUP, "750");
            initDict.Add(LASTROITOPSIDE1, "750");
            initDict.Add(LASTROITOPSIDE2, "750");
            initDict.Add(LASTROIBOTTOMHEADUP, "1800");
            initDict.Add(LASTROIBOTTOMSIDE1, "1800");
            initDict.Add(LASTROIBOTTOMSIDE2, "1800");
            initDict.Add(BELTLEFTPOINTX, "816");
            initDict.Add(BELTRIGHTPOINTX, "1632");
            initDict.Add(REFMILLIMETERSHEADUP, "1,0");
            initDict.Add(REFMILLIMETERSSIDE1, "1,0");
            initDict.Add(REFMILLIMETERSSIDE2, "1,0");
            initDict.Add(MAXTUBELENGTH, "15,00");
            initDict.Add(MINTUBELENGTH, "15,25");
            initDict.Add(REMOVERDELAY, "1000");
            initDict.Add(REMOVERLENGTH, "500");
            initDict.Add(LASTSIDE1THRESHOLD, "50,0");
            initDict.Add(LASTSIDE2THRESHOLD, "50,0");
            initDict.Add(LASTCANNYTHRESHOLDSIDE1, "100,0");
            initDict.Add(LASTCANNYTHRESHOLDSIDE2, "100,0");
            initDict.Add(LASTAREACORRECTIONSIDE1, "0,0");
            initDict.Add(LASTAREACORRECTIONSIDE2, "0,0");
            initDict.Add(MINELLIPSELENSIDE1, "500,0");
            initDict.Add(MINELLIPSELENSIDE2, "500,0");
            initDict.Add(REMOVERDIST1, "12");
            initDict.Add(REMOVERDIST2, "24");
            initDict.Add(REMOVERDIST3, "40");
            initDict.Add(PREDICTIONSAVEPATH, "D:\\data");
                
            Initialize(initDict);
        }

        /// <summary>
        /// Сохранить файл с параметрами
        /// </summary>
        public void SaveParameters() => UpdateFile();
    }
}