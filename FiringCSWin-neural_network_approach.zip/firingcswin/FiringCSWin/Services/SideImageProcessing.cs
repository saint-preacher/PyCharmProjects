﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Media;
using FiringCSWin.BaseServices;
using OpenCvSharp;

namespace FiringCSWin.Services
{
    public interface ISideImageProcessing : IImageProcessingService
    {
        /// <summary>
        /// Расчёт диаметров 
        /// </summary>
        /// <param name="cannyThreshold">Величина порога для алгоритма Canny</param>
        /// <param name="roiTop">Верхний предел интереса</param>
        /// <param name="roiBottom">Нижний предел интереса</param>
        /// <param name="roiLeft">Левый предел интереса</param>
        /// <param name="roiRight">Правый предел интереса</param>
        /// <param name="threshold">Величина порога бинаризации</param>
        /// <param name="areaCalcCorrection">Коррекция расчёта площади</param>
        /// <param name="minEllipseLen">Минимальная длина контура эллипса</param>
        /// <param name="diams">Внешние диаметры посчитанные</param>
        /// <param name="thicks">Внутренние диаметры посчитанные</param>
        /// <param name="coefmm">Коэффициент перевода в миллиметры</param>
        ImageSource CalculateDiameters(double cannyThreshold, int roiTop, int roiBottom, int roiLeft, int roiRight,
            double threshold, double areaCalcCorrection, int minEllipseLen, out List<double> diams, out List<double> thicks, double coefmm);

        ImageSource CalculateDiameters2(double threshold, int roiTop, int roiBottom, int roiLeft, int roiRight,
            double cannyThreshold, int minContourLen, out List<double> diams, out List<double> thicks, double coefmm);

        /// <summary>
        /// Вычисляет диаметры (внешний и внутренний) через аппроксимацию прямыми линиями по бинаризованному изображению
        /// </summary>
        /// <param name="centerPoint">Точка центра трубки, полученная на шаге 1</param>
        /// <param name="thickness">Рассчитанная толщина стенки (средняя)</param>
        /// <param name="outDiam">Рассчитанный внешний диаметр</param>
        /// <param name="thickDeviation">Стандартное отклонение по толщинам стенок</param>
        /// <param name="outDeviation">Стандартное отклонение по внешним диаметрам</param>
        /// <param name="lrDeviation">Эллипсность по внутреннему диаметру (среднеквадратическое отклонение одной стенки от другой)</param>
        /// <param name="LRDeviationList">Разницы между правой и левой стенок(px)</param>
        /// <param name="areaCalcThreshold">Порог для расчёта площади</param>
        /// <param name="coefmm">Коэффициент перевода в миллиметры</param>
        void CalcDiamByLinesApprox(Point2f centerPoint, out double thickness, out double outDiam, out double thickDeviation, out double outDeviation, out double lrDeviation, out List<double> LRDeviationList, double areaCalcThreshold);

        /// <summary>
        /// Вычисляет диаметры (внешний и внутренний) через площадь бинаризованного изображения
        /// </summary>
        /// <param name="centerPoint">Точка центра трубки, полученная на шаге 1</param>
        /// <param name="thickness">Рассчитанная толщина стенки</param>
        /// <param name="outDiam">Рассчитанный внешний диаметр</param>
        /// <param name="areaCalcThreshold">Порог для расчёта площади</param>
        /// <param name="areaCalcCorrection">Добавка для расчёта площади</param>
        void CalcDiamByArea(Mat thresholdedLayer, Point2f centerPoint, out double thickness, out double outDiam, double areaCalcThreshold, double areaCalcCorrection);

        /// <summary>
        /// Поиск эллипсов на изображении
        /// </summary>
        /// <param name="threshold">Порог бинаризации</param>
        /// <param name="thickness">Полученная толщина стенки</param>
        /// <param name="outDiam">Полученный внешний диаметр трубки</param>
        /// <param name="innEllipse">Величина рассчитанной эллипсности внутренного диаметра</param>
        /// <param name="outEllipse">Величина рассчитанной эллипсности внешнего диаметра</param>
        /// <param name="center">Центральная точка полученная на этом этапе</param>
        /// <param name="areaCalcThreshold">Порог для расчёта площади</param>
        /// <param name="ellipseMinLenOfContour">Минимальная длина контура эллипса</param>
        void DetectEllipses(Mat thresholdedLayer, double threshold, out double thickness, out double outDiam, out double innEllipse, out double outEllipse, out Point2f center, double areaCalcThreshold, int ellipseMinLenOfContour);
    }

    public class SideImageProcessing : ImageProcessingService, ISideImageProcessing
    {
        public SideImageProcessing(IFileSystemProvider fsProvider) : base(fsProvider) { }

        public ImageSource CalculateDiameters2(double threshold, int roiTop, int roiBottom, int roiLeft, int roiRight,
            double cannyThreshold, int minContourLen, out List<double> diams, out List<double> thicks, double coefmm)
        {
            var timer = new Stopwatch();
            timer.Start();

            diams = new List<double>();
            thicks = new List<double>();

            // 1. Ищем Bounding Box трубки
            var grayscale = RGBToGray(Layer0);
            ThresholdInv(grayscale, threshold);
            DilateGrayscale(grayscale, MorphShapes.Ellipse, new Size(15, 15));

            var boundingRect = FindThresholdedBoundingBox(grayscale, (roiLeft, roiRight), (roiTop, roiBottom));
            Cv2.Rectangle(Layer0, boundingRect, Scalar.Blue, 4);

            var outerDiam = (boundingRect.Width + boundingRect.Height) / 2.0;
            var centerPoint = new Point2f() { X = boundingRect.X + boundingRect.Width / 2, Y = boundingRect.Y + boundingRect.Height / 2 };

            double aspect = 0.0;
            if(boundingRect.Height != 0) aspect = (double)boundingRect.Width / boundingRect.Height;

            Debug.WriteLine($"aspect = {aspect}");

            if (!((aspect > 1.07) | (aspect < 0.93)))
            {
                diams.Add(outerDiam * coefmm);

                // 2. Ищем внутренний эллипс (внутренний диаметр - толщина стенки), у которого центр должен до какой-то заданной
                // степени совпадать с центром bounding box
                var tempOut = new Mat();
                Layer0.CopyTo(tempOut);

                Cv2.GaussianBlur(tempOut, tempOut, new Size(3.0, 3.0), 3.0, 3.0);
                Cv2.Threshold(tempOut, tempOut, threshold, 255.0, ThresholdTypes.Binary);

                var result = CalcInnerRadius(tempOut, boundingRect, centerPoint, 8, 4,
                    (point) =>
                    {
                        var ellipse = new RotatedRect(point, new Size2f(2.0f, 2.0f), 0.0f);
                        Cv2.Ellipse(Layer0, ellipse, Scalar.Blue, 2);
                    },
                    (point) =>
                    {
                        var ellipse = new RotatedRect(point, new Size2f(10.0f, 10.0f), 0.0f);
                        Cv2.Ellipse(Layer0, ellipse, Scalar.Blue, 4);
                    },
                    (p1, p2) =>
                    {
                        Cv2.Line(Layer0, p1, p2, Scalar.Green, 4);
                    });

                var wallThick = (outerDiam / 2.0 - result.radius) * coefmm;
                var ellipsePerc = 100.0 * result.elli / (result.radius * 2.0);

                Cv2.PutText(Layer0, wallThick.ToString("F2"), new Point(100, 200), HersheyFonts.HersheyPlain, 8.0, Scalar.Red, 4);
                Cv2.PutText(Layer0, (outerDiam * coefmm).ToString("F2"), new Point(100, 400), HersheyFonts.HersheyPlain, 8.0, Scalar.Red, 4);
                Cv2.PutText(Layer0, ellipsePerc.ToString("F1"), new Point(100, 600), HersheyFonts.HersheyPlain, 8.0, Scalar.Red, 4);

                thicks.Add(wallThick);
            }

            timer.Stop();
            Debug.WriteLine($"CalculateDiameters2 elapsed time {timer.ElapsedMilliseconds}ms");

            return PrepareSource(Layer0, (roiTop, roiBottom), (roiLeft, roiRight), true);
        }

        /// <summary>
        /// Расчёт внутреннего диаметра 
        /// </summary>
        /// <param name="mat">Слой на котором происходит поиск (бинаризованный)</param>
        /// <param name="bounds">Ограничивающий прямоугольник (Внешний диаметр)</param>
        /// <param name="center">Предполагаемый центр эллипса</param>
        /// <param name="beamCount">Количество лучей для расчёта</param>
        /// <param name="blackDepth">Глубина черноты для точного определения края стенки трубки</param>
        /// <param name="BlackDetected">Действие выполняемое, если мы нашли чёрненькое</param>
        /// <param name="PositionDetected">Действие выполняемое, если мы нашли точку внутренного эллипса</param>
        /// <returns>Кортеж внутреннего диаметра и процентного соотношения эллипсности</returns>
        public (double radius, double elli) CalcInnerRadius(Mat mat, Rect bounds, Point2f center, int beamCount, int blackDepth, Action<Point> BlackDetected, Action<Point> PositionDetected, Action<Point, Point> ShowLine)
        {
            var radiuses = new List<double>();
            double alpha = 180.0 / beamCount;

            var criticalAngle = GetCriticalAngle(bounds);

            var tasks = new List<Task<double>>();
            Func<object, double> taskAction = (object obj) =>
            {
                var a = (double)obj;
                double radius = 0.0;
                var endPoint = GetRectIntersectPoint(a, criticalAngle, bounds);
                var line = new LineIterator(mat, (Point)center, endPoint);

                int blacks = 0;
                var pos = new Point();

                ShowLine?.Invoke((Point)center, endPoint);

                foreach (var pixel in line)
                {
                    var intensity = pixel.GetValue<byte>();

                    if (intensity < 5)
                    {
                        if (blacks == 0) pos = pixel.Pos;
                        blacks++;
                    }
                    else blacks = 0;

                    if (blacks >= blackDepth)
                    {
                        radius = pos.DistanceTo((Point)center);
                        PositionDetected?.Invoke(pos);
                        break;
                    }
                }

                return radius;
            };

            var angle = 0.0;
            for (int beam = 0; beam < 2 * beamCount; beam++)
            {
                tasks.Add(Task<double>.Factory.StartNew(taskAction, angle));
                angle += alpha;
            }

            Task.WaitAll(tasks.ToArray());
            radiuses = new List<double>(tasks.Select((t) =>
            {
                return t.Result;
            }));

            // выбираем самое большое отклонение
            double elliptic = 0.0;
            foreach (var radius in radiuses)
            {
                foreach (var other in radiuses)
                {
                    var temp = Math.Abs(radius - other);
                    if (temp > elliptic) elliptic = temp;
                }
            }

            return (radiuses.Average(), elliptic);
        }

        public double GetCriticalAngle(Rect rect) => Math.Atan((double)rect.Height / rect.Width) * 180.0 / Math.PI;

        public Point GetRectIntersectPoint(double angle, double criticalAngle, Rect bounds)
        {
            var centerx = bounds.Left + bounds.Width / 2.0;
            var centery = bounds.Top + bounds.Height / 2.0;
            var halfw = bounds.Width / 2.0;
            var halfh = bounds.Height / 2.0;

            if ((angle <= criticalAngle) | (angle > 360.0 - criticalAngle))
            {
                // правая вертикальная
                return new Point(bounds.Right, centery - Math.Tan(angle * Math.PI / 180.0) * halfw);
            }
            else if ((angle > criticalAngle) & (angle <= 180.0 - criticalAngle))
            {
                // верхняя горизонтальная
                return new Point(centerx + halfh / Math.Tan(angle * Math.PI / 180.0), bounds.Top);
            }
            else if ((angle > 180.0 - criticalAngle) & (angle <= 180.0 + criticalAngle))
            {
                // левая вертикальная
                return new Point(bounds.Left, centery + Math.Tan(angle * Math.PI / 180.0) * halfw);
            }
            else
            {
                // нижняя горизонтальная
                return new Point(centerx - halfh / Math.Tan(angle * Math.PI / 180.0), bounds.Bottom);
            }
        }

        public ImageSource CalculateDiameters(double cannyThreshold, int roiTop, int roiBottom, int roiLeft, int roiRight,
            double threshold, double areaCalcCorrection, int minEllipseLen, out List<double> diams, out List<double> thicks, double coefmm)
        {
            var timer = new Stopwatch();
            timer.Start();

            double Thick1, OutDiam1, Thick2, OutDiam2, Thick3, OutDiam3, InnEllipse, OutEllipse, LRDeviation, Thick2Dev, OutDiam2Dev;
            Point2f CenterPoint;

            thicks = new List<double>();
            diams = new List<double>();

            // делаем бинаризованное изображение
            var tempOut = new Mat();
            Cv2.CvtColor(Layer0, tempOut, ColorConversionCodes.RGB2GRAY);
            Cv2.GaussianBlur(tempOut, tempOut, new Size(3.0, 3.0), 3.0, 3.0);
            Cv2.Threshold(tempOut, tempOut, threshold, 255.0, ThresholdTypes.Binary);

            // STAGE 1: Canny обнаружение краёв и вписание эллипса
            DetectEllipses(tempOut, cannyThreshold, out Thick1, out OutDiam1, out InnEllipse, out OutEllipse, out CenterPoint, threshold, minEllipseLen);

            if ((CenterPoint.X < Layer0.Width) && (CenterPoint.Y < Layer0.Height) && (CenterPoint.X > 0) && (CenterPoint.Y > 0))
            {
                // STAGE 2: Расчёт по прямым линиям наложенным на бинаризованное изображение
                CalcDiamByLinesApprox(CenterPoint, out Thick2, out OutDiam2, out Thick2Dev, out OutDiam2Dev, out LRDeviation, out var DevsList, threshold);

                // STAGE 3: Вычисление диаметра исходя из площади белых пикселей на бинаризованном изображении
                CalcDiamByArea(tempOut, CenterPoint, out Thick3, out OutDiam3, threshold, areaCalcCorrection);

                FilterResults(Thick1, OutDiam1, Thick2, OutDiam2, Thick3, OutDiam3, thicks, diams);

                // нарисовать средний результат сверху кадра
                var meanDiam = diams.Average();
                var meanThick = thicks.Average();
                Cv2.PutText(Layer0, (meanDiam * coefmm).ToString("F2"), new Point(100, 200), HersheyFonts.HersheyPlain, 8.0, Scalar.Blue, 4);
                Cv2.PutText(Layer0, (meanThick * coefmm).ToString("F2"), new Point(100, 400), HersheyFonts.HersheyPlain, 8.0, Scalar.Blue, 4);
            }

            timer.Stop();
            Debug.WriteLine($"CalculateDiameters elapsed time {timer.ElapsedMilliseconds}ms");

            return PrepareSource(Layer0, (roiTop, roiBottom), (roiLeft, roiRight), true);
        }

        public void CalcDiamByLinesApprox(Point2f centerPoint, out double thickness, out double outDiam, out double thickDeviation, out double outDeviation, out double lrDeviation, out List<double> LRDeviationList, double areaCalcThreshold)
        {
            var watch = new Stopwatch();
            watch.Start();

            var temp = new Mat();
            Layer0.CopyTo(temp);

            Cv2.GaussianBlur(temp, temp, new Size(3.0, 3.0), 3.0, 3.0);
            Cv2.Threshold(temp, temp, areaCalcThreshold, 255.0, ThresholdTypes.Binary);

            thickness = -1.0;
            outDiam = -1.0;

            var xs = new double[] { centerPoint.X, centerPoint.X - centerPoint.Y + temp.Size().Height, temp.Size().Width, centerPoint.X + centerPoint.Y };
            var ys = new double[] { temp.Size().Height, temp.Size().Height, centerPoint.Y, 0.0 };
            var xe = new double[] { centerPoint.X, centerPoint.X - centerPoint.Y, 0.0, centerPoint.X + centerPoint.Y - temp.Size().Height };
            var ye = new double[] { 0.0, 0.0, centerPoint.Y, temp.Size().Height };

            var Thicknesses = new List<double>();
            var OutDiams = new List<double>();
            LRDeviationList = new List<double>();

            // рисуем 4 прямые, проходящие через центр по которым будем считать
            for (int i = 0; i < 4; i++)
            {
                var p1 = new Point(xs[i], ys[i]);
                var p2 = new Point(xe[i], ye[i]);

                var it = new LineIterator(temp, p1, p2);
                var DotsList = new List<Point>();
                byte PrevVal = 255;
                var PrevCount = 0;

                foreach (var pixel in it)
                {
                    var intensity = pixel.GetValue<byte>();
                    if (PrevVal != intensity)
                    {
                        if ((PrevCount < 20) && (DotsList.Count > 0))
                        {
                            DotsList.RemoveAt(DotsList.Count - 1);
                        }
                        else PrevCount = 0;
                        DotsList.Add(pixel.Pos);
                        Cv2.Circle(Layer0, pixel.Pos, 25, new Scalar(0, 255.0, 0), 3);
                    }

                    PrevCount++;
                    PrevVal = intensity;
                }

                if (DotsList.Count == 4)
                {
                    var firstPoint = DotsList[0];
                    var lastPoint = DotsList[3];
                    var dist = GetDist(firstPoint, lastPoint);
                    OutDiams.Add(dist);
                    var left = GetDist(firstPoint, DotsList[1]);
                    Thicknesses.Add(left);
                    var right = GetDist(DotsList[2], lastPoint);
                    Thicknesses.Add(right);
                    LRDeviationList.Add(left - right);
                }

                Cv2.Line(Layer0, p1, p2, new Scalar(0, 0, 255), 5);
            }

            // вычисляем среднее квадратическое отклонение
            thickDeviation = GetStdDeviation(Thicknesses);
            outDeviation = GetStdDeviation(OutDiams);

            thickness = (Thicknesses.Count > 0) ? Thicknesses.Average() : 0.0;
            outDiam = (OutDiams.Count > 0) ? OutDiams.Average() : 0.0;

            lrDeviation = GetStdDeviation(LRDeviationList);

            watch.Stop();
            Debug.WriteLine($"CalcDiamByLinesApprox : {watch.ElapsedMilliseconds}ms");
        }

        public void CalcDiamByArea(Mat thresholdedLayer, Point2f centerPoint, out double thickness, out double outDiam, double areaCalcThreshold, double areaCalcCorrection)
        {
            var watch = new Stopwatch();
            watch.Start();

            var labels = new Mat();
            var stats = new Mat();
            var centroids = new Mat();

            // подсчёт площади белого поля вокруг центральной точки
            var nccomps = Cv2.ConnectedComponentsWithStats(thresholdedLayer, labels, stats, centroids);

            thickness = -1.0;
            outDiam = -1.0;
            var innDiam = -1.0;

            int TheMostArea = 0;

            for (int i = 0; i < nccomps; i++)
            {
                var S = stats.At<int>(i, (int)ConnectedComponentsTypes.Area);
                if (S < 10000) continue;
                var tiic = (labels.At<int>((int)centerPoint.Y, (int)centerPoint.X) == i);
                var d = Math.Sqrt(4 * S / Math.PI) + areaCalcCorrection;
                if (tiic)
                {
                    innDiam = d;
                }
                if (S > TheMostArea) TheMostArea = S;
            }

            if (TheMostArea > 10000)
            {
                var size = thresholdedLayer.Size();
                var S = size.Height * size.Width - TheMostArea;
                outDiam = Math.Sqrt(4 * S / Math.PI) + areaCalcCorrection;
            }

            if ((outDiam > 0) && (innDiam > 0)) thickness = (outDiam - innDiam) / 2.0;

            watch.Stop();
            Debug.WriteLine($"CalcDiamByArea : {watch.ElapsedMilliseconds}ms");
        }

        public void DetectEllipses(Mat thresholdedLayer, double cannyThreshold, out double thickness, out double outDiam, out double innEllipse, out double outEllipse, out Point2f center, double areaCalcThreshold, int ellipseMinLenOfContour)
        {
            var watch = new Stopwatch();
            watch.Start();

            Mat cannyOut = new Mat();
            Cv2.Canny(thresholdedLayer, cannyOut, cannyThreshold, cannyThreshold * 2, 3, true);

            Cv2.FindContours(cannyOut, out Point[][] contours, out HierarchyIndex[] hierarchy, RetrievalModes.Tree, ContourApproximationModes.ApproxSimple);

            var minRect = new List<RotatedRect>();
            var minEllipse = new List<RotatedRect>();
            var parents = new List<int>();
            for (int i = 0; i < contours.Length; i++)
            {
                if ((contours[i].Length > ellipseMinLenOfContour) && !parents.Contains(hierarchy[i].Parent))
                {
                    minEllipse.Add(Cv2.FitEllipse(contours[i]));
                    parents.Add(i);
                }
            }

            center = new Point2f(0.0f, 0.0f);
            foreach (RotatedRect ellipse in minEllipse)
            {
                Cv2.Ellipse(Layer0, ellipse, new Scalar(255.0, 0.0, 0.0), 3);

                center += ellipse.Center;
            }
            if (minEllipse.Count > 0) center = new Point2f(center.X / minEllipse.Count, center.Y / minEllipse.Count);

            if (minEllipse.Count == 2)
            {
                var abs = minEllipse[0].Size.Height - minEllipse[1].Size.Height;
                if (abs > 0)
                {
                    outDiam = minEllipse[0].Size.Height;
                    var innDiam = minEllipse[1].Size.Height;
                    thickness = (outDiam - innDiam) / 2.0;
                    innEllipse = 100.0 * (minEllipse[1].Size.Height / minEllipse[1].Size.Width);
                    if (innEllipse > 100.0) innEllipse = 1.0 / innEllipse;
                    outEllipse = 100.0 * (minEllipse[0].Size.Height / minEllipse[0].Size.Width);
                    if (outEllipse > 100.0) outEllipse = 1.0 / outEllipse;
                }
                else
                {
                    var innDiam = minEllipse[0].Size.Height;
                    outDiam = minEllipse[1].Size.Height;
                    thickness = (outDiam - innDiam) / 2.0;
                    innEllipse = 100.0 * (minEllipse[0].Size.Height / minEllipse[0].Size.Width);
                    if (innEllipse > 100.0) innEllipse = 1.0 / innEllipse;
                    outEllipse = 100.0 * (minEllipse[1].Size.Height / minEllipse[1].Size.Width);
                    if (outEllipse > 100.0) outEllipse = 1.0 / outEllipse;
                }
            }
            else
            {
                outDiam = -1.0;
                thickness = -1.0;
                innEllipse = 100.0;
                outEllipse = 100.0;
            }

            watch.Stop();
            Debug.WriteLine($"DetectEllipses : {watch.ElapsedMilliseconds}ms");
        }
    }
}
