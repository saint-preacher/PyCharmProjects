﻿using FiringCSWin.Models;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;

namespace FiringCSWin.Services
{
    /// <summary>
    /// Класс описывающий протокол общения с контроллером
    /// </summary>
    public static class CommProtocol
    {
        private const string GET_STATUS = "GS";
        private const string SET_TRANSPORTER_SPEED = "STS:";
        private const string SET_CASETTE_STEPS = "SSC:";
        private const string SET_CASETTE_DOWN_SPEED = "SCD:";
        private const string SET_DISC_SPEED = "SDS:";
        private const string SET_PNEUMO_DELAY = "SDD:";
        private const string SET_ROW_COUNT = "SRC:";
        private const string SET_PNEUMO_1 = "SVI:";
        private const string SET_PNEUMO_2 = "SVII:";
        private const string SET_PNEUMO_3 = "SVIII:";
        private const string SET_PNEUMO_4 = "SIV:";
        private const string SET_PNEUMO_5 = "SV:";
        private const string DRIVE_TRANSPORTER = "DTR:";
        private const string DRIVE_DISC = "DDI:";
        private const string DRIVE_CASETTE = "DCA:";
        private const string DIR_CASETTE = "DCD:";
        private const string MOVE_CASETTE = "DCP:";
        private const string SET_TRANSPORTER_ACCEL = "STA:";
        private const string SET_TRANSPORTER_DECEL = "STD:";
        private const string SET_DISC_ACCEL = "SRA:";
        private const string SET_DISC_DECEL = "SRD:";
        private const string SET_CASETTE_ACCEL = "SCSA:";
        private const string SET_CASETTE_DECEL = "SCSD:";
        private const string SET_CASETTE_UP_SPEED = "SCTS:";
        private const string CAS_ROW_MOVE = "CARM:";
        private const string CAS_PUSH_IN = "CAPI:";
        private const string CAS_NEXT_ROW = "CANR:";
        private const string CAS_CHANGE_CAS = "CACC:";
        private const string CAS_START_STOP = "CAST:";
        private const string CAS_ZERO_COUNTER = "CAZC:";
        private const string SET_FIRST_CASETTE_STEPS = "SFSC:";
        private const string SET_BEFORE_PUSHIN_DELAY = "SBPI:";
        private const string SET_REMOVER_DELAY = "SRED:";
        private const string SET_REMOVER_LENGTH = "SRPL:";
        private const string REMOVE1_START = "R1";
        private const string REMOVE2_START = "R2";
        private const string REMOVE3_START = "R3";
        private const string CAM1_REMDISTANCE = "DSA:";
        private const string CAM2_REMDISTANCE = "DSB:";
        private const string CAM3_REMDISTANCE = "DSC:";

        private const string ENABLE_SUFFIX = "1";
        private const string DISABLE_SUFFIX = "0";

        private static Dictionary<string, Action<string, ISensorsModel>> AtomicTokensDict = new Dictionary<string, Action<string, ISensorsModel>>()
        {
            {"S", TokenS}, {"TS", TokenTS}, {"FSC", TokenFSC}, {"CRC", TokenCRC}, {"SC", TokenSC},
            {"CD", TokenCD}, {"DS", TokenDS}, {"DD", TokenDD}, {"RC", TokenRC}, {"BPI", TokenBPI},
            { "CP", TokenCP}, {"AL", TokenAL}
        };

        private static string MakeUpCommand(string prefix, string suffix) => prefix + suffix + "\n";

        /// <summary>
        /// Команда получения состояния контроллера
        /// </summary>
        public static string GetStatus() => MakeUpCommand(GET_STATUS, string.Empty);

        /// <summary>
        /// Команда установки скорости транспортёра
        /// </summary>
        /// <param name="speed">Новая скорость</param>
        public static string SetTranSpeed(ushort speed)
        {
            return MakeUpCommand(SET_TRANSPORTER_SPEED, speed.ToString());
        }

        /// <summary>
        /// Установка количества шагов на опускание кассеты на один ряд
        /// </summary>
        /// <param name="steps">Количество шагов</param>
        public static string SetCasetteSteps(ushort steps)
        {
            return MakeUpCommand(SET_CASETTE_STEPS, steps.ToString());
        }

        /// <summary>
        /// Установка количества шагов на опускание кассеты в первом ряду
        /// </summary>
        /// <param name="steps">Количество шагов</param>
        public static string SetFirstCasetteSteps(ushort steps)
        {
            return MakeUpCommand(SET_FIRST_CASETTE_STEPS, steps.ToString());
        }

        /// <summary>
        /// Установка скорости перемещения кассеты вниз
        /// </summary>
        /// <param name="speed">Скорость</param>
        public static string SetCasetteDownSpeed(ushort speed)
        {
            return MakeUpCommand(SET_CASETTE_DOWN_SPEED, speed.ToString());
        }

        /// <summary>
        /// Установка скорости вращения диска оплавки
        /// </summary>
        /// <param name="speed">Скорость</param>
        public static string SetDiscSpeed(ushort speed)
        {
            return MakeUpCommand(SET_DISC_SPEED, speed.ToString());
        }

        /// <summary>
        /// Установка задержки пневмоцилиндра загрузки в кассету
        /// </summary>
        /// <param name="delay">Задержка в миллисекундах</param>
        public static string SetPneumoDelay(ushort delay)
        {
            return MakeUpCommand(SET_PNEUMO_DELAY, delay.ToString());
        }

        /// <summary>
        /// Установка задержки пневмоцилиндра перед загрузкой в кассету
        /// </summary>
        /// <param name="delay">Задержка в миллисекундах</param>
        public static string SetBeforePushInDelay(ushort delay)
        {
            return MakeUpCommand(SET_BEFORE_PUSHIN_DELAY, delay.ToString());
        }

        /// <summary>
        /// Задать количество рядов в кассете
        /// </summary>
        /// <param name="count">Количество рядов</param>
        public static string SetRowCount(ushort count)
        {
            return MakeUpCommand(SET_ROW_COUNT, count.ToString());
        }

        /// <summary>
        /// Задать задержу перед импульсом сдува (мс)
        /// </summary>
        /// <param name="ms">Количество миллисекунд</param>
        public static string SetRemoverDelay(ushort ms)
        {
            return MakeUpCommand(SET_REMOVER_DELAY, ms.ToString());
        }

        /// <summary>
        /// Задать длину импульса сдува (мс)
        /// </summary>
        /// <param name="ms">Количество миллисекунд</param>
        public static string SetRemoverLength(ushort ms)
        {
            return MakeUpCommand(SET_REMOVER_LENGTH, ms.ToString());
        }

        /// <summary>
        /// Запуск цикла сдува №1
        /// </summary>
        public static string StartRemover1Cycle => MakeUpCommand(REMOVE1_START, string.Empty);

        /// <summary>
        /// Запуск цикла сдува №2
        /// </summary>
        public static string StartRemover2Cycle => MakeUpCommand(REMOVE2_START, string.Empty);

        /// <summary>
        /// Запуск цикла сдува №3
        /// </summary>
        public static string StartRemover3Cycle => MakeUpCommand(REMOVE3_START, string.Empty);

        /// <summary>
        /// Задать дистанцию до сдува от первой камеры
        /// </summary>
        /// <param name="dist">Дистанция в ячейках ремня</param>
        public static string SetCamera1RemoveDistance(ushort dist) => MakeUpCommand(CAM1_REMDISTANCE, dist.ToString());

        /// <summary>
        /// Задать дистанцию до сдува от второй камеры
        /// </summary>
        /// <param name="dist">Дистанция в ячейках ремня</param>
        public static string SetCamera2RemoveDistance(ushort dist) => MakeUpCommand(CAM2_REMDISTANCE, dist.ToString());

        /// <summary>
        /// Задать дистанцию до сдува от третьей камеры
        /// </summary>
        /// <param name="dist">Дистанция в ячейках ремня</param>
        public static string SetCamera3RemoveDistance(ushort dist) => MakeUpCommand(CAM3_REMDISTANCE, dist.ToString());

        /// <summary>
        /// Включить пневмоцилиндр №1
        /// </summary>
        public static string EnablePneumo1 => MakeUpCommand(SET_PNEUMO_1, ENABLE_SUFFIX);

        /// <summary>
        /// Выключить пневмоцилиндр №1
        /// </summary>
        public static string DisablePneumo1 => MakeUpCommand(SET_PNEUMO_1, DISABLE_SUFFIX);

        /// <summary>
        /// Включить пневмоцилиндр №2
        /// </summary>
        public static string EnablePneumo2 => MakeUpCommand(SET_PNEUMO_2, ENABLE_SUFFIX);

        /// <summary>
        /// Выключить пневмоцилиндр №2
        /// </summary>
        public static string DisablePneumo2 => MakeUpCommand(SET_PNEUMO_2, DISABLE_SUFFIX);

        /// <summary>
        /// Включить пневмоцилиндр №3
        /// </summary>
        public static string EnablePneumo3 => MakeUpCommand(SET_PNEUMO_3, ENABLE_SUFFIX);

        /// <summary>
        /// Выключить пневмоцилиндр №3
        /// </summary>
        public static string DisablePneumo3 => MakeUpCommand(SET_PNEUMO_3, DISABLE_SUFFIX);

        /// <summary>
        /// Включить пневмоцилиндр №4
        /// </summary>
        public static string EnablePneumo4 => MakeUpCommand(SET_PNEUMO_4, ENABLE_SUFFIX);

        /// <summary>
        /// Выключить пневмоцилиндр №4
        /// </summary>
        public static string DisablePneumo4 => MakeUpCommand(SET_PNEUMO_4, DISABLE_SUFFIX);

        /// <summary>
        /// Включить пневмоцилиндр №5
        /// </summary>
        public static string EnablePneumo5 => MakeUpCommand(SET_PNEUMO_5, ENABLE_SUFFIX);

        /// <summary>
        /// Выключить пневмоцилиндр №5
        /// </summary>
        public static string DisablePneumo5 => MakeUpCommand(SET_PNEUMO_5, DISABLE_SUFFIX);

        /// <summary>
        /// Запуск транспортёра
        /// </summary>
        public static string StartTransporter => MakeUpCommand(DRIVE_TRANSPORTER, ENABLE_SUFFIX);

        /// <summary>
        /// Остановка транспортёра
        /// </summary>
        public static string StopTransporter => MakeUpCommand(DRIVE_TRANSPORTER, DISABLE_SUFFIX);

        /// <summary>
        /// Запуск диска оплавки
        /// </summary>
        public static string StartDisc => MakeUpCommand(DRIVE_DISC, ENABLE_SUFFIX);

        /// <summary>
        /// Остановка диска оплавки
        /// </summary>
        public static string StopDisc => MakeUpCommand(DRIVE_DISC, DISABLE_SUFFIX);

        /// <summary>
        /// Запуск кассеты вниз
        /// </summary>
        public static string StartCasette => MakeUpCommand(DRIVE_CASETTE, ENABLE_SUFFIX);

        /// <summary>
        /// Остановка движения кассеты
        /// </summary>
        public static string StopCasette => MakeUpCommand(DRIVE_CASETTE, DISABLE_SUFFIX);

        /// <summary>
        /// Изменение направления движения кассеты ВВЕРХ
        /// </summary>
        public static string CasetteDirectionUp => MakeUpCommand(DIR_CASETTE, ENABLE_SUFFIX);

        /// <summary>
        /// Изменение направления движения кассеты ВНИЗ
        /// </summary>
        public static string CasetteDirectionDown => MakeUpCommand(DIR_CASETTE, DISABLE_SUFFIX);

        /// <summary>
        /// Передвинуть кассету на конкретное число шагов
        /// </summary>
        /// <param name="steps">Количество шагов</param>
        public static string MoveCasetteBySteps(ushort steps)
        {
            return MakeUpCommand(MOVE_CASETTE, steps.ToString());
        }

        /// <summary>
        /// Задача ускорения траспортёра
        /// </summary>
        /// <param name="accel">Ускорение шагов/сек^2</param>
        public static string SetTransporterAccel(ushort accel)
        {
            return MakeUpCommand(SET_TRANSPORTER_ACCEL, accel.ToString());
        }

        /// <summary>
        /// Задача торможения транспортёра
        /// </summary>
        /// <param name="decel">Торможение шагов/сек^2</param>
        public static string SetTransporterDecel(ushort decel)
        {
            return MakeUpCommand(SET_TRANSPORTER_DECEL, decel.ToString());
        }

        /// <summary>
        /// Задача ускорения диска оплавки
        /// </summary>
        /// <param name="accel">Ускорение шагов/сек^2</param>
        public static string SetDiscAccel(ushort accel)
        {
            return MakeUpCommand(SET_DISC_ACCEL, accel.ToString());
        }

        /// <summary>
        /// Задача торможения диска оплавки
        /// </summary>
        /// <param name="decel">Торможение шагов/сек^2</param>
        /// <returns></returns>
        public static string SetDiscDecel(ushort decel)
        {
            return MakeUpCommand(SET_DISC_DECEL, decel.ToString());
        }

        /// <summary>
        /// Задача ускорения движения кассеты
        /// </summary>
        /// <param name="accel">Ускорение шагов/сек^2</param>
        public static string SetCasetteAccel(ushort accel)
        {
            return MakeUpCommand(SET_CASETTE_ACCEL, accel.ToString());
        }

        /// <summary>
        /// Задача торможения движения кассеты
        /// </summary>
        /// <param name="decel">Торможение шагов/сек^2</param>
        public static string SetCasetteDecel(ushort decel)
        {
            return MakeUpCommand(SET_CASETTE_DECEL, decel.ToString());
        }

        /// <summary>
        /// Задача скорости движения кассеты ВВЕРХ
        /// </summary>
        /// <param name="speed">Скорость</param>
        public static string SetCasetteUpSpeed(ushort speed)
        {
            return MakeUpCommand(SET_CASETTE_UP_SPEED, speed.ToString());
        }

        /// <summary>
        /// Запуск подпрограммы "Перемещение ряда изделий"
        /// </summary>
        /// <param name="reserved">Пока этот параметр не используется. Возможно пригодится дальше</param>
        public static string StartCasettingRowMove(ushort reserved)
        {
            return MakeUpCommand(CAS_ROW_MOVE, reserved.ToString());
        }

        /// <summary>
        /// Запуск подпрограммы "Загрузка в кассету"
        /// </summary>
        /// <param name="reserved">Пока этот параметр не используется. Возможно пригодится позже</param>
        public static string StartCasettingPushIn(ushort reserved)
        {
            return MakeUpCommand(CAS_PUSH_IN, reserved.ToString());
        }

        /// <summary>
        /// Запуск подпрограммы "Смена ряда кассеты"
        /// </summary>
        /// <param name="reserved">Пока этот параметр не используется. Возможно пригодится позже</param>
        public static string StartCasettingNextRow(ushort reserved)
        {
            return MakeUpCommand(CAS_NEXT_ROW, reserved.ToString());
        }

        /// <summary>
        /// Запуск подпрограммы "Смена кассеты"
        /// </summary>
        /// <param name="reserved">Пока этот параметр не используется. Возможно пригодится позже</param>
        public static string StartCasettingChange(ushort reserved)
        {
            return MakeUpCommand(CAS_CHANGE_CAS, reserved.ToString());
        }

        /// <summary>
        /// Включить автокасеттирование
        /// </summary>
        public static string EnableAutoCasetting => MakeUpCommand(CAS_START_STOP, ENABLE_SUFFIX);

        /// <summary>
        /// Выключить автокасеттирование
        /// </summary>
        public static string DisableAutoCasetting => MakeUpCommand(CAS_START_STOP, DISABLE_SUFFIX);

        /// <summary>
        /// Очистка счётчика рядов при автокассетировании
        /// Использовать с осторожностью
        /// </summary>
        public static string CasettingZeroCounter() => MakeUpCommand(CAS_ZERO_COUNTER, DISABLE_SUFFIX);

        /// <summary>
        /// Код команды опроса
        /// </summary>
        /// <param name="ComPort">Ссылка на открытый последовательный порт</param>
        /// <returns>Структуру с заполненым ответом</returns>
        /// <exception cref="FormatException"/>
        public static void PollCommand(SerialPort ComPort, ISensorsModel sensors)
        {
            ComPort.DiscardOutBuffer();
            ComPort.DiscardInBuffer();

            ComPort.Write(GET_STATUS + "\n");

            var line = string.Empty;

            Thread.Sleep(50);

            line = ComPort.ReadLine();

            // расшифровываем ответ
            ParseStatusAnswer(line, sensors);
        }

        /// <summary>
        /// Расшифровка ответа на команду запроса статуса
        /// </summary>
        /// <param name="answer">Строка с ответом</param>
        /// <returns>Структура с выходными данными</param>
        /// <exception cref="ArgumentException"/>
        public static void ParseStatusAnswer(string answer, ISensorsModel data)
        {
            const string WRONGFORMAT = "В ответе неверные данные.";

            var tokens = answer.Split(new char[] { ' ' });
            if (tokens.Length != AtomicTokensDict.Count) throw new ArgumentException(WRONGFORMAT);

            foreach (var token in tokens)
            {
                var atoms = token.Split(new char[] { ':' });
                if (atoms.Length != 2) throw new ArgumentException(WRONGFORMAT);
                AtomicTokensDict[atoms[0]](atoms[1], data);
            }
        }

        private static void TokenS(string value, ISensorsModel data)
        {
            var bitmap = ushort.Parse(value);
            data.RowSensor = (bitmap & 0b1) > 0;
            data.TubeSensor = (bitmap & 0b10) > 0;
            data.Valve1Sensor = (bitmap & 0b100) > 0;
            data.Valve2Sensor = (bitmap & 0b1000) > 0;
            data.Valve3Sensor = (bitmap & 0b10000) > 0;
            data.Valve4Sensor = (bitmap & 0b100000) > 0;
            data.Valve5Sensor = (bitmap & 0b1000000) > 0;
            data.CasetteReversing = (bitmap & 0b10000000) > 0;
            data.RowLimit = (bitmap & 0b100000000) > 0;
            data.PushLimit = (bitmap & 0b1000000000) > 0;
            data.AutomaticCasetting = (bitmap & 0b10000000000) > 0;
            data.ReservedLimit = (bitmap & 0b100000000000) > 0;
            data.FullCasette = (bitmap & 0b1000000000000) > 0;
            data.CasetteTopLimit = (bitmap & 0b10000000000000) > 0;
            data.CasetteBottomLimit = (bitmap & 0b100000000000000) > 0;
            data.EmptyCasette = (bitmap & 0b1000000000000000) > 0;
        }

        private static void TokenTS(string value, ISensorsModel data) => data.CurrentTransporterSpeed = ushort.Parse(value);

        private static void TokenFSC(string value, ISensorsModel data) => data.CasetteFirstStepsPerRow = ushort.Parse(value);

        private static void TokenCRC(string value, ISensorsModel data) => data.CurrentRowCount = ushort.Parse(value);

        private static void TokenSC(string value, ISensorsModel data) => data.CasetteStepsPerRow = ushort.Parse(value);

        private static void TokenCD(string value, ISensorsModel data) => data.CurrentCasetteSpeed = ushort.Parse(value);

        private static void TokenDS(string value, ISensorsModel data) => data.CurrentDiscSpeed = ushort.Parse(value);

        private static void TokenDD(string value, ISensorsModel data) => data.PushIntoCasetteDelay = ushort.Parse(value);

        private static void TokenRC(string value, ISensorsModel data) => data.RowCount = ushort.Parse(value);

        private static void TokenBPI(string value, ISensorsModel data) => data.BeforePushIntoCasetteDelay = ushort.Parse(value);

        private static void TokenCP(string value, ISensorsModel data) => data.CasettePosition = uint.Parse(value);

        private static void TokenAL(string value, ISensorsModel data) => data.AlarmCode = ushort.Parse(value);
    }
}