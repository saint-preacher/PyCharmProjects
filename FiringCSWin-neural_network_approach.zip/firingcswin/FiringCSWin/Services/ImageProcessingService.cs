﻿using FiringCSWin.BaseServices;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FiringCSWin.Services
{
    public interface IImageProcessingService
    {
        /// <summary>
        /// Получить BMP картинку текущего слоя
        /// </summary>
        Bitmap GetLayerBitmap();

        /// <summary>
        /// Загрузка кадра из файла
        /// </summary>
        /// <param name="filename">Имя файла</param>
        void LoadFromFile(string filename);

        /// <summary>
        /// Загрузка кадра из памяти (с камеры)
        /// </summary>
        /// <param name="framePtr">Указатель на данные кадра в памяти</param>
        /// <param name="width">Ширина кадра</param>
        /// <param name="height">Высота кадра</param>
        void LoadFromFrame(IntPtr framePtr, long width, long height);

        /// <summary>
        /// Сохранение кадра
        /// </summary>
        /// <param name="prefix">Префикс имени файла</param>
        /// <param name="suffix">Суффикс имени файла</param>
        void SaveToFile(string prefix, string suffix);

        /// <summary>
        /// Расчёт расстояния между двумя точками
        /// </summary>
        /// <param name="firstPoint">Первая точка</param>
        /// <param name="lastPoint">Вторая точка</param>
        double GetDist(OpenCvSharp.Point firstPoint, OpenCvSharp.Point lastPoint);

        /// <summary>
        /// Операция по выводу "Сырого" кадра
        /// </summary>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня</param>
        ImageSource GetInitialFrame((int, int) roi, (int, int) belt);
        
        /// <summary>
        /// Расчёт среднеквадратичного отклонения
        /// </summary>
        /// <param name="values">Значения функции</param>
        double GetStdDeviation(IEnumerable<double> values);

        /// <summary>
        /// Операция "Порог"
        /// </summary>
        /// <param name="val">Величина порога</param>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня</param>
        ImageSource Threshold(double val, (int,int) roi, (int,int) belt);   
                        
        /// <summary>
        /// Операция "Удаление фона"
        /// </summary>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня</param>
        ImageSource GetForegroundMask((int, int) roi, (int,int) belt);

        /// <summary>
        /// Инициализация удалятеля фона
        /// </summary>
        void InitBckgSubstractor();

        /// <summary>
        /// Операция "Выделение краёв (контуров)
        /// </summary>
        /// <param name="threshold">Порог</param>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня</param>
        ImageSource EdgesFind(double threshold, (int, int) roi, (int,int) belt);

        /// <summary>
        /// Удалятель фона проинициализированы
        /// </summary>
        bool BckgSubstractorInitialized { get; }        
    }

    public class ImageProcessingService : IImageProcessingService
    {        
        protected IFileSystemProvider FsProvider;

        protected Mat Layer0;

        protected Mat ForegroundMask;

        public bool BckgSubstractorInitialized { get; protected set; }
        
        public ImageProcessingService(IFileSystemProvider fsProvider) => FsProvider = fsProvider;

        public Bitmap GetLayerBitmap()
        {
            var size = Layer0.Size();
            return new Bitmap(size.Width, size.Height, (int)Layer0.Step1(), System.Drawing.Imaging.PixelFormat.Format24bppRgb, Layer0.Data);
        }

        /// <summary>
        /// Получить данные с "сырым" изображением для камер сбоку
        /// </summary>
        /// <param name="roi">Регион интереса</param>
        public ImageSource GetInitialFrame((int, int) roiX, (int, int) roiY) => PrepareSource(Layer0, roiY, roiX, false);

        /// <summary>
        /// Загрузить изображение из файла в слой 0
        /// </summary>
        /// <param name="filename">Имя файла</param>
        public void LoadFromFile(string filename)
        {
            var grayscale = new Mat(filename, ImreadModes.Grayscale);
            Layer0 = new Mat(grayscale.Size(), MatType.CV_8UC3);
            Cv2.CvtColor(grayscale, Layer0, ColorConversionCodes.GRAY2RGB);
        }

        /// <summary>
        /// Используем кадр с камеры, загрузить в слой 0
        /// </summary>
        public void LoadFromFrame(IntPtr framePtr, long width, long height)
        {
            var grayscale = new Mat((int)height, (int)width, MatType.CV_8UC1, framePtr);
            Layer0 = new Mat(grayscale.Size(), MatType.CV_8UC3);
            Cv2.CvtColor(grayscale, Layer0, ColorConversionCodes.GRAY2RGB);
        }

        public void SaveToFile(string prefix, string suffix)
        {
            var rootFolder = Path.Combine(new string[] { FsProvider.GetCurrentDirectory(), "SavedFrames" });
            if (!FsProvider.DirExists(rootFolder)) FsProvider.DirCreate(rootFolder);
            var path = Path.Combine(new string[] { rootFolder, $"{prefix}{DateTime.Now.ToString("HHmmssfff_ddMMyyyy")}{suffix}.png" });
            Layer0?.SaveImage(path);
        }

        /// <summary>
        /// Найти дистанцию между двумя точками
        /// </summary>
        /// <param name="firstPoint">Первая точка</param>
        /// <param name="lastPoint">Вторая точка</param>
        /// <returns>Расстояние между точками</returns>
        public double GetDist(OpenCvSharp.Point firstPoint, OpenCvSharp.Point lastPoint)
        {
            return Math.Sqrt(Math.Pow(firstPoint.X - lastPoint.X, 2.0) + Math.Pow(firstPoint.Y - lastPoint.Y, 2.0));
        }                        

        /// <summary>
        /// Конвертируем Mat в ImageSource для камер сверху
        /// </summary>
        /// <param name="image">Входной Mat</param>
        /// <param name="roiY">Регион интереса по высоте/param>
        /// <param name="roiX">Регион интереса по ширине</param>
        protected ImageSource PrepareSource(Mat image, (int,int) roiY, (int,int) roiX, bool showroi)
        {
            var dims = image.Size();

            if (showroi)
            {
                // отрисовка границ ремня
                Cv2.Line(image, new OpenCvSharp.Point(roiX.Item1, 0), new OpenCvSharp.Point(roiX.Item1, dims.Height), Scalar.Blue, 4);
                Cv2.Line(image, new OpenCvSharp.Point(roiX.Item2, 0), new OpenCvSharp.Point(roiX.Item2, dims.Height), Scalar.Blue, 4);

                // отрисовка ROI
                Cv2.Line(image, new OpenCvSharp.Point(0, roiY.Item1), new OpenCvSharp.Point(dims.Width, roiY.Item1), Scalar.Blue, 4);
                Cv2.Line(image, new OpenCvSharp.Point(0, roiY.Item2), new OpenCvSharp.Point(dims.Width, roiY.Item2), Scalar.Blue, 4);
            }

            return ToBitmapSource(image);
        }

        protected static ImageSource ToBitmapSource(Mat image)
        {
            var arrLen = image.Rows * (int)image.Step();
            var byteArray = new byte[arrLen];
            System.Runtime.InteropServices.Marshal.Copy(image.Data, byteArray, 0, arrLen);

            var bitmap = BitmapSource.Create(
                    image.Width,
                    image.Height,
                    96.0,
                    96.0,
                    PixelFormats.Rgb24,
                    null,
                    byteArray,
                    (int)image.Step1()
                );

            bitmap.Freeze();
            return bitmap;
        }

        /// <summary>
        /// Получение среднеквадратического отклонения по массиву
        /// </summary>
        /// <param name="values">Массив с double</param>
        /// <returns>Величина стандартной девиации</returns>
        public double GetStdDeviation(IEnumerable<double> values)
        {
            if (values.Count() == 0) return 0.0;
            double avg = values.Average();
            return Math.Sqrt(values.Average(v => Math.Pow(v - avg, 2)));
        }

        /// <summary>
        /// Сортировка слиянием массива кортежей, по последнему элементу кортежа
        /// </summary>
        /// <param name="inputData">Входной массив</param>
        /// <param name="start">Индекс первого элемента</param>
        /// <param name="length">Длина массива</param>
        /// <returns>Отсортированный массив</returns>
        public (int x, int y, int dx, int dy)[] MergeSort((int x, int y, int dx, int dy)[] inputData, int start, int length)
        {       
            if(length > 1)
            {
                var llength = length / 2;
                var rlength = length - llength;

                var lsorted = MergeSort(inputData, start, llength);
                var rsorted = MergeSort(inputData, start + llength, rlength);

                var index = 0;
                var rindex = 0;

                var outputData = new (int x, int y, int dx, int dy)[length];
                for(int lindex = 0; lindex < llength; lindex++)
                {
                    while((rindex < rlength) && (lsorted[lindex].dy > rsorted[rindex].dy))
                    {
                        outputData[index++] = rsorted[rindex++];
                    }

                    outputData[index++] = lsorted[lindex];
                }
                                
                while(rindex < rlength) outputData[index++] = rsorted[rindex++];

                return outputData;
            }

            return new (int x, int y, int dx, int dy)[1] { inputData[start] };
        }        

        protected void FilterResults(double Thickness1, double OutDiam1, double Thickness2, double OutDiam2, double Thickness3, double OutDiam3, List<double> thickList, List<double> outList)
        {
            // фильтруем отрицательные результаты
            var inArr = new double[] { Thickness1, Thickness2, Thickness3 };
            var outArr = new double[] { OutDiam1, OutDiam2, OutDiam3 };
            for (int i = 0; i < 3; i++)
            {
                if (inArr[i] > 0) thickList.Add(inArr[i]);
                if (outArr[i] > 0) outList.Add(outArr[i]);
            }
        }       

        /// <summary>
        /// Замер ширины белого поля между черными точками (в бинарном изображении)
        /// </summary>
        /// <param name="y">Высота прямой замера</param>
        /// <param name="thresholdLayer">Матрица с бинарным изображением результатом операции "Порог"</param>
        /// <returns>Кортеж с абсциссами начала и конца белого поля</returns>
        private (int,int) GetReferenceWidth(double y, Mat thresholdLayer)
        {
            var size = thresholdLayer.Size();
            thresholdLayer.GetArray(out byte[] imgArr);

            var minLX = 0;
            var minRX = 0;

            Func<int, int, bool> checkProc = (int point, int prevPoint) =>
            {
                var curlum = imgArr[point];
                var prevlum = imgArr[prevPoint];
                var dlum = curlum - prevlum;

                if (dlum == 255) return true;
                return false;
            };

            // с левого края
            var startPoint = (int)(size.Width * y);
            for(int p = startPoint + 1; p < startPoint + size.Width; p++)
            {
                if(checkProc(p, p - 1))
                {
                    minLX = p;
                    break;
                }
            }

            // c правого края 
            startPoint = (int)(size.Width * (y+1) - 1);
            for (int p = startPoint - 1; p > startPoint - size.Width; p--)
            {
                if(checkProc(p, p + 1))
                {
                    minRX = p;
                    break;
                }
            }

            return (minLX, minRX);
        }        
        
        /// <summary>
        /// Загрузка первой фоновой картинки
        /// </summary>
        public void InitBckgSubstractor()
        {
            ForegroundMask = new Mat(Layer0.Size(), MatType.CV_8UC1);
            Cv2.CvtColor(Layer0, ForegroundMask, ColorConversionCodes.RGB2GRAY);
            BckgSubstractorInitialized = true;
        }

        public Mat BckgSubstract()
        {
            var grayscale = new Mat(Layer0.Size(), MatType.CV_8UC1);
            Cv2.CvtColor(Layer0, grayscale, ColorConversionCodes.RGB2GRAY);
            return ForegroundMask - grayscale;
        }

        /// <summary>
        /// Загружаем файл фона и вычитаем его из текущего
        /// </summary>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня в кадре</param>
        public ImageSource GetForegroundMask((int,int) roi, (int,int) belt)
        {
            var tempMat = BckgSubstract();
            Cv2.CvtColor(tempMat, Layer0, ColorConversionCodes.GRAY2RGB);
            return PrepareSource(Layer0, roi, belt, true);
        }

        /// <summary>
        /// Получить изображение операции "Порог"
        /// </summary>
        /// <param name="val">Величина порога</param>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня в кадре</param>
        /// <returns>Бинарное изображение</returns>
        public ImageSource Threshold(double val, (int, int) roi, (int,int) belt)
        {
            var threshLayer = RGBToGray(Layer0);
            ThresholdGrayscale(threshLayer, val);
            Cv2.CvtColor(threshLayer, Layer0, ColorConversionCodes.GRAY2RGB);
            return PrepareSource(Layer0, roi, belt, true);
        }         

        /// <summary>
        /// Операция "Поиск краёв"
        /// </summary>
        /// <param name="roi">Регион интереса</param>
        /// <param name="belt">Координаты ремня в кадре</param>
        public ImageSource EdgesFind(double threshold, (int,int) roi, (int,int) belt)
        {
            var contoursLayer = new Mat(Layer0.Size(), MatType.CV_8UC3);
            var grayscale = RGBToGray(Layer0);
            ThresholdGrayscale(grayscale, threshold);
            GetContours(grayscale, contoursLayer);
            Cv2.AddWeighted(Layer0, 0.0, contoursLayer, 1.0, 0.0, Layer0);
            return PrepareSource(Layer0, roi, belt, true);
        }

        /// <summary>
        /// Применение методов обсчёта из библиотеки OpenCV
        /// </summary>
        /// <returns>Найденные контура</returns>
        protected OpenCvSharp.Point[][] GetContours(Mat thresholdLayer, Mat contoursLayer)
        {
            var tempcont = Cv2.FindContoursAsArray(thresholdLayer, RetrievalModes.Tree, ContourApproximationModes.ApproxTC89KCOS);

            // берём первые два самых больших контура
            var contours = tempcont.OrderByDescending((point) => point.Length).Take(2).ToArray();
            Cv2.DrawContours(contoursLayer, contours, -1, Scalar.Blue, 2);
            return contours;
        }

        protected Rect FindThresholdedBoundingBox(Mat thresholdedImage, (int, int) roix, (int,int) roiy)
        {
            var idx = new Mat();
            Cv2.FindNonZero(thresholdedImage, idx);
            var rect = Cv2.BoundingRect(idx);
            return rect;
        }

        protected Mat CannyGrayscale(Mat image, double threshold1, double threshold2)
        {
            var cannyLayer = new Mat();
            Cv2.Canny(image, cannyLayer, threshold1, threshold2);
            return cannyLayer;
        }

        /// <summary>
        /// Делаем из RGB изображения градации серого
        /// </summary>
        /// <param name="layer">Входное RGB изображение</param>
        /// <returns>Выходное в градациях серого</returns>
        protected Mat RGBToGray(Mat layer)
        {
            var grayscale = new Mat(Layer0.Size(), MatType.CV_8UC1);
            Cv2.CvtColor(Layer0, grayscale, ColorConversionCodes.RGB2GRAY);
            return grayscale;
        }

        /// <summary>
        /// Гауссово размытие
        /// </summary>
        /// <param name="grayscale">Входное изображение в формате grayscale</param>
        /// <param name="kernel">Ядро</param>
        /// <param name="sigmaX">Величина по Х</param>
        /// <param name="sigmaY">Величина по У</param>
        protected void ApplyGaussianBlurToGrayscale(Mat grayscale, OpenCvSharp.Size kernel, double sigmaX, double sigmaY)
        {
            Cv2.GaussianBlur(grayscale, grayscale, kernel, sigmaX, sigmaY);
        }

        /// <summary>
        /// Логика операции "Порог"
        /// </summary>
        /// <param name="threshold">Значение порогоа</param>
        /// <param name="threshLayer">Слой для работы</param>
        protected void ThresholdGrayscale(Mat grayscale, double threshold)
        {            
            Cv2.Threshold(grayscale, grayscale, threshold, 255.0, ThresholdTypes.Binary);
        }

        protected void ThresholdInv(Mat grayscale, double threshold)
        {
            Cv2.Threshold(grayscale, grayscale, threshold, 255.0, ThresholdTypes.BinaryInv);
        }

        protected void ErodeGrayscale(Mat grayscale, MorphShapes shape, OpenCvSharp.Size kernel)
        {
            Cv2.MorphologyEx(grayscale, grayscale, MorphTypes.Erode, Cv2.GetStructuringElement(shape, kernel));
        }

        protected void DilateGrayscale(Mat grayscale, MorphShapes shape, OpenCvSharp.Size kernel)
        {
            Cv2.MorphologyEx(grayscale, grayscale, MorphTypes.Dilate, Cv2.GetStructuringElement(shape, kernel));
        }
    }
}
