﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Media;
using FiringCSWin.BaseServices;
using OpenCvSharp;

namespace FiringCSWin.Services
{
    public interface IHeadUpImageProcessing : IImageProcessingService
    {
        /// <summary>
        /// Расчёт длины трубки
        /// </summary>
        /// <param name="threshold">Величина порога</param>
        /// <param name="roiTop">Верхний предел интереса</param>
        /// <param name="roiBottom">Нижний предел интереса</param>
        /// <param name="beltLeft">Левая координата ремня</param>
        /// <param name="beltRight">Правая координата ремня</param>
        /// <param name="mmcoef">Коэфициент перевода в миллиметры</param>
        /// <param name="tubelength">Выходная переменная с длиной трубки подсчитанной</param>
        ImageSource CalculateTubeLength(double threshold, int roiTop, int roiBottom, int beltLeft, int beltRight, double mmcoef, out double tubelength, bool debugEnabled);
    }

    public class HeadUpImageProcessing : ImageProcessingService, IHeadUpImageProcessing
    {
        public HeadUpImageProcessing(IFileSystemProvider fsProvider) : base(fsProvider){}

        /// <summary>
        /// Расчёт ширины трубки (с верхней камеры)
        /// </summary>
        /// <param name="threshold">Порог (0-255)</param>
        /// <param name="roiTop">Верхняя ордината региона интереса</param>
        /// <param name="roiBottom">Нижняя ордината региона интереса</param>
        /// <param name="beltLeft">Левая координата ремня в кадре</param>
        /// <param name="beltRight">Правая координата ремня в кадре</param>
        /// <param name="tubewidth">Расчитанная длина трубки. Выходная переменная. -1 если трубки на кадре не обнаружено</param>
        public ImageSource CalculateTubeLength(double threshold, int roiTop, int roiBottom, int beltLeft, int beltRight, double mmcoef, out double tubewidth, bool debugEnabled)
        {
            Mat saveZeroStep = new Mat();
            Mat saveFirstStep = new Mat();
            Mat saveSecondStep = new Mat();

            var timer = new Stopwatch();
            timer.Start();

            if (debugEnabled) Cv2.CopyTo(Layer0, saveZeroStep);

            if (threshold < 0) threshold = 0;
            if (threshold > 255) threshold = 255.0;

            var thresholdLayer = new Mat(Layer0.Size(), MatType.CV_8UC1);
            var contoursLayer = new Mat(Layer0.Size(), MatType.CV_8UC3);

            // получаем кадр фона
            var withoutBckg = BckgSubstract();

            if (debugEnabled) saveFirstStep = withoutBckg;

            // отрежем от кадра фона по ROI
            var mask = new Mat(Layer0.Size(), MatType.CV_8UC1);
            var width = Layer0.Size().Width;
            mask.Rectangle(new Rect(0, roiTop, beltLeft, roiBottom - roiTop), Scalar.White, -1);
            mask.Rectangle(new Rect(beltRight, roiTop, width - beltRight, roiBottom - roiTop), Scalar.White, -1);
            withoutBckg &= mask;

            Cv2.Threshold(withoutBckg, thresholdLayer, threshold, 255.0, ThresholdTypes.Binary);
            if (debugEnabled) saveSecondStep = thresholdLayer;

            //Cv2.MorphologyEx(thresholdLayer, thresholdLayer, MorphTypes.Erode, Cv2.GetStructuringElement(MorphShapes.Ellipse, new Size(3.0, 3.0)));
            //Cv2.MorphologyEx(thresholdLayer, thresholdLayer, MorphTypes.Dilate, Cv2.GetStructuringElement(MorphShapes.Ellipse, new Size(3.0, 3.0)));

            Cv2.CvtColor(thresholdLayer, Layer0, ColorConversionCodes.GRAY2RGB);

            var helpersLayer = new Mat(Layer0.Size(), MatType.CV_8UC3);

            // замер эталона
            //var m = GetReferenceWidth(refY, thresholdLayer);
            //Cv2.PutText(helpersLayer, (m.Item2 - m.Item1).ToString(), new Point(2448 / 2, 2000), HersheyFonts.HersheyPlain, 20.0, Scalar.Blue, 20);
            //Debug.WriteLine($"After reference found {timer.ElapsedMilliseconds}");

            // обработка
            var pointsL = SearchPoints(beltLeft - 1, (roiTop, roiBottom), out bool isfoundL, thresholdLayer);
            var pointsR = SearchPoints(beltRight + 1, (roiTop, roiBottom), out bool isfoundR, thresholdLayer);

            if (isfoundL && isfoundR)
            {
                // трубка найдена
                Debug.WriteLine("Tube found.");
                DrawTubeRest(pointsL, pointsR);
                var rect = FindRectangle(out double calc_width, threshold, mmcoef);
                DrawPolygon(rect, calc_width);
                tubewidth = calc_width;
            }
            else tubewidth = isfoundL | isfoundR ? tubewidth = 0.0 : tubewidth = -1.0;

            // рисование прямой эталона
            //Cv2.Line(helpersLayer, new Point(0.0, refY), new Point(2448.0, refY), Scalar.Blue, 3);

            timer.Stop();
            Debug.WriteLine($"Total {timer.ElapsedMilliseconds}");

            // совместить Layer0 и helpersLayer
            Cv2.AddWeighted(Layer0, 1.0, helpersLayer, 0.5, 0.0, Layer0);

            if (debugEnabled & (isfoundL && isfoundR))
            {
                saveZeroStep.SaveImage("raw.png");
                saveFirstStep.SaveImage("withoutBckg.png");
                saveSecondStep.SaveImage("thresholdLayer.png");
                Layer0.SaveImage("layer0.png");
            }

            return PrepareSource(Layer0, (roiTop, roiBottom), (beltLeft, beltRight), true);
        }

        /// <summary>
        /// Отрисовка невидимой части трубки
        /// </summary>
        /// <param name="pointsL">Точки слева</param>
        /// <param name="pointsR">Точки справа</param>
        protected void DrawTubeRest((int, int)[] pointsL, (int, int)[] pointsR)
        {
            var listpoints = new List<List<Point>>();
            listpoints.Add(new List<Point>() {
                new Point(pointsL[0].Item1, pointsL[0].Item2),
                new Point(pointsR[0].Item1, pointsR[0].Item2),
                new Point(pointsR[1].Item1, pointsR[1].Item2),
                new Point(pointsL[1].Item1, pointsL[1].Item2)
            });

            Cv2.FillPoly(Layer0, listpoints, Scalar.White);
        }

        /// <summary>
        /// Поиск прямоугольника трубки
        /// </summary>
        /// <returns>Точки прямоугольника</returns>
        protected List<(double, double)> FindRectangle(out double width, double threshold, double mmcoef)
        {
            var contoursLayer = new Mat(Layer0.Size(), MatType.CV_8UC3);
            var grayscale = RGBToGray(Layer0);
            // TODO если нужен гаусен брул воткнуть сюда
            ThresholdGrayscale(grayscale, threshold);
            var contours = GetContours(grayscale, contoursLayer);

            var rect = Cv2.MinAreaRect(contours[0]);
            width = (rect.Size.Width > rect.Size.Height) ? rect.Size.Width * mmcoef : rect.Size.Height * mmcoef;
            var points = Cv2.BoxPoints(rect);
            var list = new List<(double, double)>();
            foreach (var point in points) list.Add((point.X, point.Y));
            return list;
        }

        /// <summary>
        /// Поиск верхней и нижней точки трубки
        /// </summary>
        /// <param name="x">Координата по оси Х</param>
        /// <param name="roi">Ограничение по высоте</param>
        /// <param name="isfound">Выходная переменная - флаг найденной трубки</param>
        /// <param name="layer">Слой на котором ищем</param>
        /// <returns>Две точки: верхняя и нижняя</returns>
        protected (int, int)[] SearchPoints(int x, (int, int) roi, out bool isfound, Mat layer)
        {
            (int, int) topPoint = (-1, -1);
            (int, int) bottomPoint = (-1, -1);
            int isfoundCounter = 0;

            if (roi.Item1 >= roi.Item2) throw new ArgumentException("Первая координата ROI должна быть меньше второй.");

            // проходим по обработанной threshold картинке кочерыжек трубки
            var width = layer.Width;

            layer.GetArray(out byte[] data);
            
            bool bottomMode = false;
            int blackThick = 0;
            for (int y = roi.Item1; y < roi.Item2; y++)
            {
                var scalar = data[width * y + x];

                if (bottomMode)
                {
                    if (scalar == 0)
                    {
                        if (blackThick > 50)
                        {
                            bottomPoint = (x, y - 50);
                            isfoundCounter++;
                            break;
                        }
                        else blackThick++;
                    }
                    else
                    {
                        blackThick = 0;
                    }
                }
                else
                {
                    if (scalar == 255)
                    {
                        topPoint = (x, y);
                        bottomMode = true;
                        isfoundCounter++;
                    }
                }
            }

            isfound = (isfoundCounter == 2);

            return new (int, int)[] { topPoint, bottomPoint };
        }

        /// <summary>
        /// Отрисовка фигуры трубки
        /// </summary>
        /// <param name="rect">Список углов</param>
        /// <param name="width">Ширина</param>
        protected void DrawPolygon(List<(double, double)> rect, double width)
        {
            Point p1, p2;
            for (int i = 1; i < rect.Count; i++)
            {
                p1 = new Point(rect[i - 1].Item1, rect[i - 1].Item2);
                p2 = new Point(rect[i].Item1, rect[i].Item2);
                Cv2.Line(Layer0, p1, p2, Scalar.Blue, 4);
            }

            p1 = new Point(rect[rect.Count - 1].Item1, rect[rect.Count - 1].Item2);
            p2 = new Point(rect[0].Item1, rect[0].Item2);
            Cv2.Line(Layer0, p1, p2, Scalar.Blue, 4);

            Cv2.PutText(Layer0, width.ToString("F3"), new Point(100, 500), HersheyFonts.HersheyPlain, 36.0, Scalar.Blue, 20);
        }
    }
}
