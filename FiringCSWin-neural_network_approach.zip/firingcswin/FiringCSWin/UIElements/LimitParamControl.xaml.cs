﻿using System.Windows;
using System.Windows.Controls;

namespace FiringCSWin.UIElements
{
    /// <summary>
    /// Логика взаимодействия для LimitParamControl.xaml
    /// </summary>
    public partial class LimitParamControl : UserControl
    {
        public LimitParamControl()
        {
            InitializeComponent();
        }

        #region("LimitsString")
        public static readonly DependencyProperty LimitsStringProperty = DependencyProperty.Register(
              nameof(LimitsString),
              typeof(string),
              typeof(LimitParamControl),
              new PropertyMetadata(string.Empty)
            );

        public string LimitsString
        {
            get => (string)GetValue(LimitsStringProperty);
            set => SetValue(LimitsStringProperty, value);
        }
        #endregion

        #region("MinLimitString")
        public static readonly DependencyProperty MinLimitStringProperty = DependencyProperty.Register(
              nameof(MinLimitString),
              typeof(string),
              typeof(LimitParamControl),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Минимальное значение хорошего объекта
        /// </summary>
        public string MinLimitString
        {
            get => (string)GetValue(MinLimitStringProperty);
            set => SetValue(MinLimitStringProperty, value);
        }
        #endregion

        #region("MaxLimitString")
        public static readonly DependencyProperty MaxLimitStringProperty = DependencyProperty.Register(
              nameof(MaxLimitString),
              typeof(string),
              typeof(LimitParamControl),
              new PropertyMetadata(string.Empty)
            );

        /// <summary>
        /// Максимальное значение хорошего объекта
        /// </summary>
        public string MaxLimitString
        {
            get => (string)GetValue(MaxLimitStringProperty);
            set => SetValue(MaxLimitStringProperty, value);
        }
        #endregion
    }
}
