﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;

namespace FiringCSWin.UIElements
{
    /// <summary>
    /// Логика взаимодействия для RemoverControlBlock.xaml
    /// </summary>
    [ContentProperty("LimitParams")]
    public partial class RemoverControlBlock : UserControl
    {
        public RemoverControlBlock()
        {
            InitializeComponent();
            LimitParams = new ObservableCollection<LimitParamControl>();
        }

        #region("LimitParams")
        public static readonly DependencyProperty LimitParamsProperty = DependencyProperty.Register(
              nameof(LimitParams),
              typeof(ObservableCollection<LimitParamControl>),
              typeof(RemoverControlBlock),
              new PropertyMetadata(null, LimitParamsChanged)
            );

        private static void LimitParamsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var removerControlBlock = d as RemoverControlBlock;
            var newCollection = e.NewValue as ObservableCollection<LimitParamControl>;

            newCollection.CollectionChanged += (sender, args) =>
            {
                if(args.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
                {
                    var newControls = e.NewValue as Collection<LimitParamControl>;
                    foreach (var control in newControls)
                    {
                        var binding = new Binding()
                        {
                            Path = new PropertyPath("DataContext"),
                            Source = removerControlBlock,
                            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                            Mode = BindingMode.OneWay
                        };

                        BindingOperations.SetBinding(control, DataContextProperty, binding);
                    }
                }
            };
        }
        
        public ObservableCollection<LimitParamControl> LimitParams
        {
            get => (ObservableCollection<LimitParamControl>)GetValue(LimitParamsProperty);
            set => SetValue(LimitParamsProperty, value);
        }
        #endregion
        
        #region("NoRemoveRadioChecked")
        public static readonly DependencyProperty NoRemoveRadioCheckedProperty = DependencyProperty.Register(
              nameof(NoRemoveRadioChecked),
              typeof(bool),
              typeof(RemoverControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Состояние радиобаттона "Не сдувать"
        /// </summary>
        public bool NoRemoveRadioChecked
        {
            get => (bool)GetValue(NoRemoveRadioCheckedProperty);
            set => SetValue(NoRemoveRadioCheckedProperty, value);
        }
        #endregion        

        #region("RemoveBadRadioChecked")
        public static readonly DependencyProperty RemoveBadRadioCheckedProperty = DependencyProperty.Register(
              nameof(RemoveBadRadioChecked),
              typeof(bool),
              typeof(RemoverControlBlock),
              new PropertyMetadata(false)
            );

        /// <summary>
        /// Состояние радиобаттона "Сдувать брак"
        /// </summary>
        public bool RemoveBadRadioChecked
        {
            get => (bool)GetValue(RemoveBadRadioCheckedProperty);
            set => SetValue(RemoveBadRadioCheckedProperty, value);
        }
        #endregion        

        #region("ClearListsCommand")
        public static readonly DependencyProperty ClearListsCommandProperty = DependencyProperty.Register(
              nameof(ClearListsCommand),
              typeof(ICommand),
              typeof(RemoverControlBlock),
              new PropertyMetadata()
            );

        public ICommand ClearListsCommand
        {
            get => (ICommand)GetValue(ClearListsCommandProperty);
            set => SetValue(ClearListsCommandProperty, value);
        }
        #endregion

        #region("BadTubesCount")
        public static readonly DependencyProperty BadTubesCountProperty = DependencyProperty.Register(
              nameof(BadTubesCount),
              typeof(int),
              typeof(RemoverControlBlock),
              new PropertyMetadata(0)
            );

        public int BadTubesCount
        {
            get => (int)GetValue(BadTubesCountProperty);
            set => SetValue(BadTubesCountProperty, value);
        }
        #endregion

        #region("GoodTubesCount")
        public static readonly DependencyProperty GoodTubesCountProperty = DependencyProperty.Register(
              nameof(GoodTubesCount),
              typeof(int),
              typeof(RemoverControlBlock),
              new PropertyMetadata(0)
            );

        public int GoodTubesCount
        {
            get => (int)GetValue(GoodTubesCountProperty);
            set => SetValue(GoodTubesCountProperty, value);
        }
        #endregion

        #region("BadTubes")
        public static readonly DependencyProperty BadTubesProperty = DependencyProperty.Register(
              nameof(BadTubes),
              typeof(IEnumerable),
              typeof(RemoverControlBlock),
              new PropertyMetadata()
            );

        public IEnumerable BadTubes
        {
            get => (IEnumerable)GetValue(BadTubesProperty);
            set => SetValue(BadTubesProperty, value);
        }
        #endregion

        #region("GoodTubes")
        public static readonly DependencyProperty GoodTubesProperty = DependencyProperty.Register(
              nameof(GoodTubes),
              typeof(IEnumerable),
              typeof(RemoverControlBlock),
              new PropertyMetadata()
            );

        public IEnumerable GoodTubes
        {
            get => (IEnumerable)GetValue(GoodTubesProperty);
            set => SetValue(GoodTubesProperty, value);
        }
        #endregion
    }
}
